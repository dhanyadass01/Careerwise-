import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  Layers,
  Award,
  ExternalLink,
  Github,
  CheckCircle2,
  Share2,
  Lock,
  Globe,
  Sparkles,
  FileCheck2,
  Copy,
  BookOpen,
} from 'lucide-react';
import { CartoonAvatar } from './CartoonAvatar';

export const PortfolioView: React.FC = () => {
  const {
    currentUser,
    departments,
    skills,
    progressMap,
    projectSubmissions,
    projects,
    certificates,
    careerMissions,
    isPortfolioPublic,
    togglePortfolioPublic,
  } = useApp();

  const [copiedLink, setCopiedLink] = useState(false);
  const [showShareModal, setShowShareModal] = useState(false);

  if (!currentUser) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-20 text-center space-y-6">
        <div className="w-16 h-16 rounded-2xl bg-indigo-100 text-indigo-600 flex items-center justify-center mx-auto shadow-sm">
          <Layers className="w-8 h-8" />
        </div>
        <div className="space-y-2">
          <h2 className="text-2xl font-extrabold text-slate-900">Verifiable Graduate Skill Portfolio</h2>
          <p className="text-sm text-slate-600 leading-relaxed max-w-md mx-auto">
            Your portfolio displays verified skills, submitted GitHub repositories, and faculty reviews. Please log in or create an account to view and share your live portfolio link.
          </p>
        </div>
      </div>
    );
  }

  const currentDept = departments.find((d) => d.id === currentUser.department);

  // Completed skills with verified quizzes
  const completedSkills = skills.filter((s) => {
    const prog = progressMap[s.id];
    return prog?.isCompleted || (prog?.quizScore && prog.quizScore >= 70);
  });

  // Approved projects
  const approvedSubmissions = projectSubmissions.filter(
    (s) => s.studentId === currentUser.id && s.status === 'Approved'
  );

  // User earned certificates
  const userCertificates = certificates.filter(
    (c) =>
      c.studentId === currentUser.id ||
      (Boolean(currentUser.name) && c.studentName?.toLowerCase() === currentUser.name.toLowerCase())
  );

  const publicPortfolioUrl = `https://careerwise.edu/portfolio/${currentUser.id}`;

  const handleCopyLink = () => {
    navigator.clipboard?.writeText(publicPortfolioUrl);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header Banner */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="flex items-center gap-4">
            <CartoonAvatar
              name={currentUser.name}
              avatarId={currentUser.avatar}
              size="xl"
              className="ring-4 ring-blue-500/20"
            />
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-2xl font-extrabold text-slate-900">{currentUser.name}</h1>
                <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-md bg-blue-100 text-blue-800">
                  Verified Candidate
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                {currentDept?.name} • {currentUser.year}
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            {/* Privacy Toggle */}
            <button
              onClick={() => togglePortfolioPublic(!isPortfolioPublic)}
              className={`px-4 py-2 rounded-xl text-xs font-semibold border transition-all flex items-center gap-2 ${
                isPortfolioPublic
                  ? 'bg-emerald-50 text-emerald-800 border-emerald-300'
                  : 'bg-slate-100 text-slate-700 border-slate-300'
              }`}
            >
              {isPortfolioPublic ? <Globe className="w-4 h-4 text-emerald-600" /> : <Lock className="w-4 h-4 text-slate-500" />}
              <span>{isPortfolioPublic ? 'Publicly Visible' : 'Private Portfolio'}</span>
            </button>

            <button
              onClick={() => setShowShareModal(true)}
              className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold transition-colors flex items-center gap-1.5 shadow-xs"
            >
              <Share2 className="w-4 h-4" />
              <span>Share Portfolio Link</span>
            </button>
          </div>
        </div>
      </div>

      {/* Badges & Verifications Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-2xs flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center font-black">
            {completedSkills.length}
          </div>
          <div>
            <p className="text-xs font-bold text-slate-800">Verified Skills</p>
            <p className="text-[11px] text-slate-500">Coursework & quizzes passed</p>
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-2xs flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center font-black">
            {approvedSubmissions.length}
          </div>
          <div>
            <p className="text-xs font-bold text-slate-800">Faculty Approved Projects</p>
            <p className="text-[11px] text-slate-500">Peer & HOD evaluated</p>
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-2xs flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center font-black">
            {userCertificates.length}
          </div>
          <div>
            <p className="text-xs font-bold text-slate-800">Earned Certificates</p>
            <p className="text-[11px] text-slate-500">Official CareerWise credentials</p>
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-2xs flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center font-black">
            3
          </div>
          <div>
            <p className="text-xs font-bold text-slate-800">Career Missions</p>
            <p className="text-[11px] text-slate-500">Weekly milestones fulfilled</p>
          </div>
        </div>
      </div>

      {/* Approved Projects Showcase */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-6">
        <div>
          <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-emerald-600" />
            Verified Capstone Project Evidence
          </h2>
          <p className="text-xs text-slate-500">
            Real projects evaluated and approved by academic faculty with repository links and feedback.
          </p>
        </div>

        {approvedSubmissions.length === 0 ? (
          <p className="text-xs text-slate-500">No approved project submissions yet.</p>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {approvedSubmissions.map((sub) => {
              const pr = projects.find((p) => p.id === sub.projectId);
              return (
                <div
                  key={sub.id}
                  className="p-5 rounded-2xl border border-slate-200 bg-slate-50/50 space-y-3"
                >
                  <div className="flex items-start justify-between gap-2">
                    <h3 className="text-sm font-bold text-slate-900">{pr?.title || 'Capstone Project'}</h3>
                    <span className="text-xs font-black text-emerald-800 bg-emerald-100 px-2.5 py-0.5 rounded-full shrink-0">
                      {sub.gradeScore}/100
                    </span>
                  </div>

                  <p className="text-xs text-slate-600 leading-relaxed line-clamp-2">
                    {sub.reportNotes}
                  </p>

                  <div className="flex flex-wrap items-center gap-3 pt-2 text-xs">
                    {sub.githubUrl && (
                      <a
                        href={sub.githubUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-blue-600 hover:underline flex items-center gap-1 font-semibold"
                      >
                        <Github className="w-3.5 h-3.5" />
                        <span>View Source Code</span>
                      </a>
                    )}
                    {sub.liveUrl && (
                      <a
                        href={sub.liveUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-purple-600 hover:underline flex items-center gap-1 font-semibold"
                      >
                        <ExternalLink className="w-3.5 h-3.5" />
                        <span>Live Preview</span>
                      </a>
                    )}
                  </div>

                  {sub.feedback && (
                    <div className="mt-3 p-3 rounded-xl bg-white border border-slate-200 text-xs text-slate-700">
                      <span className="font-bold text-slate-800">Faculty Review: </span>
                      "{sub.feedback}"
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Verified Skills Catalog */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-6">
        <div>
          <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-blue-600" />
            Demonstrated Academic Competencies
          </h2>
          <p className="text-xs text-slate-500">
            Skills with validated quiz performance and module completion records.
          </p>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
          {completedSkills.map((sk) => {
            const prog = progressMap[sk.id];
            return (
              <div
                key={sk.id}
                className="p-3.5 rounded-xl border border-slate-200 bg-slate-50/60"
              >
                <div className="flex items-center justify-between text-[10px] text-slate-500 mb-1">
                  <span className="font-bold uppercase text-blue-600">{sk.category}</span>
                  {prog?.quizScore && (
                    <span className="font-bold text-emerald-700">{prog.quizScore}%</span>
                  )}
                </div>
                <h4 className="text-xs font-bold text-slate-800 truncate">{sk.title}</h4>
                <p className="text-[10px] text-slate-500 mt-1">{sk.difficulty} • {sk.estimatedHours} hrs</p>
              </div>
            );
          })}
        </div>
      </div>

      {/* Shareable Link Modal */}
      {showShareModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-md p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-slate-900">Share Public Skill Portfolio</h3>
              <button
                onClick={() => setShowShareModal(false)}
                className="text-slate-400 hover:text-slate-600"
              >
                ✕
              </button>
            </div>

            <p className="text-xs text-slate-600 leading-relaxed">
              Recruiters and hiring managers can access your verified skills, project repositories, and credentials.
              Private student records, email, and register numbers are strictly scrubbed.
            </p>

            <div className="flex items-center gap-2">
              <input
                type="text"
                readOnly
                value={publicPortfolioUrl}
                className="w-full px-3 py-2 text-xs rounded-xl bg-slate-100 border border-slate-300 font-mono text-slate-700"
              />
              <button
                onClick={handleCopyLink}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-semibold shrink-0 transition-colors flex items-center gap-1.5"
              >
                <Copy className="w-3.5 h-3.5" />
                <span>{copiedLink ? 'Copied! ✓' : 'Copy'}</span>
              </button>
            </div>

            <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 text-[11px] text-slate-500">
              🔒 Safe Sharing Guarantee: Only approved projects, verified quiz badges, and official certificates are displayed.
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
