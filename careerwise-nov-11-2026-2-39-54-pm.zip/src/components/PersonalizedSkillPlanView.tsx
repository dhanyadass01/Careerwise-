import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { StudentSkillEntry, SkillLevel } from '../types';
import {
  Sparkles,
  CheckCircle2,
  Circle,
  FolderKanban,
  Target,
  Lightbulb,
  Edit3,
  Plus,
  Trash2,
  Layers,
  ArrowRight,
  Clock,
  Award,
  Zap,
  BookOpen,
  Filter,
  CheckSquare,
  ShieldCheck,
  Building2,
  Calendar,
  X,
} from 'lucide-react';

interface PersonalizedSkillPlanViewProps {
  onNavigateToProjects?: () => void;
  onNavigateToSkills?: () => void;
  onNavigateToRoadmap?: () => void;
  onNavigateToLogin?: () => void;
}

export const PersonalizedSkillPlanView: React.FC<PersonalizedSkillPlanViewProps> = ({
  onNavigateToProjects,
  onNavigateToSkills,
  onNavigateToRoadmap,
  onNavigateToLogin,
}) => {
  const {
    currentUser,
    customSkillPlan,
    completedCustomTaskIds,
    toggleCustomTask,
    updateCurrentUserSkills,
    departments,
  } = useApp();

  // Skill Editor modal/state
  const [isEditingSkills, setIsEditingSkills] = useState(false);
  const [editSkillName, setEditSkillName] = useState('');
  const [editSkillLevel, setEditSkillLevel] = useState<SkillLevel>('Intermediate');
  const [taskFilter, setTaskFilter] = useState<'all' | 'pending' | 'completed'>('all');

  if (!currentUser) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-20 text-center space-y-6">
        <div className="w-16 h-16 rounded-2xl bg-blue-100 text-blue-600 flex items-center justify-center mx-auto shadow-sm">
          <Sparkles className="w-8 h-8" />
        </div>
        <div className="space-y-2">
          <h2 className="text-2xl font-extrabold text-slate-900">Personalized Skill Plan & Custom Tasks</h2>
          <p className="text-sm text-slate-600 leading-relaxed max-w-md mx-auto">
            Create an account and enter your department and known skills. Our recommendation engine will generate distinctive project architectures, step-by-step tasks, and skill suggestions tailored specifically for you.
          </p>
        </div>
        <div className="pt-2">
          <button
            onClick={onNavigateToLogin}
            className="px-6 py-3 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-bold text-sm shadow-md transition-all inline-flex items-center gap-2"
          >
            <Sparkles className="w-4 h-4 text-amber-300" />
            <span>Create Account & Start Learning</span>
          </button>
        </div>
      </div>
    );
  }

  const currentDept = departments.find((d) => d.id === currentUser.department);
  const enteredSkills = currentUser.enteredSkills || [];

  // Completed custom tasks stats
  const totalTasks = customSkillPlan?.customTasks.length || 0;
  const completedCount = customSkillPlan?.customTasks.filter((t) =>
    completedCustomTaskIds.includes(t.id)
  ).length || 0;
  const progressPct = totalTasks > 0 ? Math.round((completedCount / totalTasks) * 100) : 0;

  // Filter tasks
  const filteredTasks = (customSkillPlan?.customTasks || []).filter((task) => {
    const isCompleted = completedCustomTaskIds.includes(task.id);
    if (taskFilter === 'pending') return !isCompleted;
    if (taskFilter === 'completed') return isCompleted;
    return true;
  });

  // Handle adding skill from inline editor
  const handleAddEditorSkill = () => {
    const trimmed = editSkillName.trim();
    if (!trimmed) return;
    if (enteredSkills.some((s) => (s.name || s.skillName || '').toLowerCase() === trimmed.toLowerCase())) {
      return;
    }
    const newEntry: StudentSkillEntry = {
      name: trimmed,
      proficiency: editSkillLevel,
      skillName: trimmed,
      level: editSkillLevel,
      category: 'Technical',
    };
    const updated = [...enteredSkills, newEntry];
    updateCurrentUserSkills(updated);
    setEditSkillName('');
  };

  const handleRemoveEditorSkill = (name: string) => {
    const updated = enteredSkills.filter((s) => (s.name || s.skillName) !== name);
    updateCurrentUserSkills(updated);
  };

  const handleCycleEditorSkillLevel = (name: string) => {
    const updated = enteredSkills.map((s) => {
      const curName = s.name || s.skillName;
      if (curName !== name) return s;
      const curLevel = s.proficiency || s.level || 'Intermediate';
      const next: SkillLevel =
        curLevel === 'Beginner' ? 'Intermediate' : curLevel === 'Intermediate' ? 'Advanced' : 'Beginner';
      return { ...s, proficiency: next, level: next };
    });
    updateCurrentUserSkills(updated);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 animate-in fade-in duration-300">
      {/* Top Banner: Student Identity & Active Skills */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-blue-900 rounded-3xl p-6 sm:p-8 text-white shadow-xl relative overflow-hidden border border-slate-800">
        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-3 max-w-3xl">
            <div className="flex flex-wrap items-center gap-2">
              <span className="px-3 py-1 rounded-full bg-blue-500/20 border border-blue-400/30 text-blue-200 text-xs font-semibold uppercase tracking-wider flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-blue-300" />
                <span>Tailored Learning Architecture</span>
              </span>
              <span className="px-2.5 py-0.5 rounded-full bg-white/10 text-xs font-medium">
                {currentDept?.name || 'Department Stream'}
              </span>
              <span className="px-2.5 py-0.5 rounded-full bg-white/10 text-xs font-medium">
                {currentUser.year || '3rd Year'}
              </span>
              {currentUser.registerNumber && (
                <span className="text-xs text-slate-300 font-mono">
                  Reg: {currentUser.registerNumber}
                </span>
              )}
            </div>

            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
              Personalized Plan for {currentUser.name}
            </h1>

            <p className="text-sm text-slate-300 leading-relaxed">
              {customSkillPlan?.summary ||
                'Unique project roadmaps, targeted practice tasks, and bridge suggestions generated specifically based on your entered skills.'}
            </p>

            {/* Active Skills tags */}
            <div className="pt-2">
              <div className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2 flex items-center justify-between">
                <span>Your Evaluated Skills ({enteredSkills.length}):</span>
                <button
                  onClick={() => setIsEditingSkills(!isEditingSkills)}
                  className="text-blue-300 hover:text-white flex items-center gap-1 text-xs font-semibold lowercase transition-colors"
                >
                  <Edit3 className="w-3.5 h-3.5" />
                  <span>{isEditingSkills ? 'done editing' : 'edit skills'}</span>
                </button>
              </div>

              <div className="flex flex-wrap gap-2">
                {enteredSkills.map((sk) => {
                  const badgeColor =
                    sk.level === 'Advanced'
                      ? 'bg-purple-500/20 text-purple-300 border-purple-400/30'
                      : sk.level === 'Intermediate'
                      ? 'bg-blue-500/20 text-blue-300 border-blue-400/30'
                      : 'bg-emerald-500/20 text-emerald-300 border-emerald-400/30';
                  return (
                    <span
                      key={sk.skillName}
                      className="px-3 py-1 rounded-xl bg-slate-800/80 border border-slate-700 text-xs font-semibold text-slate-200 flex items-center gap-1.5 shadow-xs"
                    >
                      <span>{sk.skillName}</span>
                      <span className={`text-[10px] px-1.5 py-0.2 rounded font-bold border ${badgeColor}`}>
                        {sk.level}
                      </span>
                    </span>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Progress Card */}
          <div className="bg-white/10 backdrop-blur-md rounded-2xl p-5 border border-white/15 min-w-[260px] space-y-3">
            <div className="flex items-center justify-between text-xs font-medium text-slate-200">
              <span>Custom Tasks Completed</span>
              <span className="font-bold text-white text-sm">
                {completedCount} / {totalTasks}
              </span>
            </div>
            <div className="w-full bg-slate-800 rounded-full h-2.5 overflow-hidden">
              <div
                className="bg-gradient-to-r from-blue-400 to-emerald-400 h-2.5 rounded-full transition-all duration-500"
                style={{ width: `${progressPct}%` }}
              ></div>
            </div>
            <div className="text-[11px] text-slate-300 flex items-center justify-between pt-1">
              <span>Progress: {progressPct}%</span>
              <span>{totalTasks - completedCount} tasks remaining</span>
            </div>
          </div>
        </div>
      </div>

      {/* Inline Skills Editor Modal / Expander */}
      {isEditingSkills && (
        <div className="bg-white p-6 rounded-3xl border border-blue-200 shadow-md space-y-4 animate-in slide-in-from-top-2 duration-200">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Edit3 className="w-5 h-5 text-blue-600" />
              <h3 className="text-base font-bold text-slate-900">Manage Your Entered Skills</h3>
            </div>
            <button
              onClick={() => setIsEditingSkills(false)}
              className="text-slate-400 hover:text-slate-600 p-1"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
          <p className="text-xs text-slate-500">
            Add or remove skills, or click the level badge to cycle between Beginner, Intermediate, and Advanced.
            Your tailored project ideas, tasks, and suggestions will adapt in real-time.
          </p>

          <div className="flex flex-wrap gap-2.5 pt-1">
            {enteredSkills.map((sk) => {
              const skillDisplayName = sk.name || sk.skillName || '';
              return (
                <div
                  key={skillDisplayName}
                  className="px-3 py-1.5 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold text-slate-800 flex items-center gap-2"
                >
                  <span>{skillDisplayName}</span>
                  <button
                    onClick={() => handleCycleEditorSkillLevel(skillDisplayName)}
                    title="Click to toggle level"
                    className="text-[10px] px-2 py-0.5 rounded font-bold bg-blue-100 text-blue-700 hover:bg-blue-200 transition-colors"
                  >
                    {sk.proficiency || sk.level || 'Intermediate'}
                  </button>
                  <button
                    onClick={() => handleRemoveEditorSkill(skillDisplayName)}
                    className="text-slate-400 hover:text-rose-600 p-0.5"
                    title="Remove skill"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              );
            })}
          </div>

          <div className="flex flex-col sm:flex-row gap-2.5 pt-2">
            <input
              type="text"
              value={editSkillName}
              onChange={(e) => setEditSkillName(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  e.preventDefault();
                  handleAddEditorSkill();
                }
              }}
              placeholder="Add another skill (e.g. Docker, SQL, Spring Boot, Figma...)"
              className="flex-1 px-3.5 py-2 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            <select
              value={editSkillLevel}
              onChange={(e) => setEditSkillLevel(e.target.value as SkillLevel)}
              className="px-3 py-2 rounded-xl border border-slate-200 text-sm bg-white"
            >
              <option value="Beginner">Beginner</option>
              <option value="Intermediate">Intermediate</option>
              <option value="Advanced">Advanced</option>
            </select>
            <button
              onClick={handleAddEditorSkill}
              className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs flex items-center justify-center gap-1.5"
            >
              <Plus className="w-4 h-4" />
              <span>Add Skill</span>
            </button>
          </div>
        </div>
      )}

      {/* Grid: 3 Main Pillars (Projects, Tasks, Bridge Suggestions) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Column (lg:col-span-7): Tailored Project Ideas */}
        <div className="lg:col-span-7 space-y-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-blue-100 text-blue-700 flex items-center justify-center font-bold">
                <FolderKanban className="w-4 h-4" />
              </div>
              <div>
                <h2 className="text-lg font-bold text-slate-900">
                  Tailored Project Ideas ({customSkillPlan?.projectIdeas.length || 0})
                </h2>
                <p className="text-xs text-slate-500">
                  Customized specifically to utilize and push your entered skills.
                </p>
              </div>
            </div>
            {onNavigateToProjects && (
              <button
                onClick={onNavigateToProjects}
                className="text-xs font-semibold text-blue-600 hover:text-blue-800 flex items-center gap-1"
              >
                <span>Full Bridge</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          <div className="space-y-4">
            {customSkillPlan?.projectIdeas.map((project, idx) => {
              const difficultyBadge =
                project.difficulty === 'Advanced'
                  ? 'bg-purple-100 text-purple-700 border-purple-200'
                  : project.difficulty === 'Intermediate'
                  ? 'bg-blue-100 text-blue-700 border-blue-200'
                  : 'bg-emerald-100 text-emerald-700 border-emerald-200';

              return (
                <div
                  key={project.id}
                  className="bg-white rounded-2xl p-6 border border-slate-200/90 shadow-xs hover:shadow-md transition-all space-y-4"
                >
                  <div className="flex flex-wrap items-start justify-between gap-2">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-slate-400">#0{idx + 1}</span>
                        <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-slate-100 text-slate-700">
                          {project.domain}
                        </span>
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md border ${difficultyBadge}`}>
                          {project.difficulty}
                        </span>
                      </div>
                      <h3 className="text-base font-bold text-slate-900">{project.title}</h3>
                    </div>
                    <div className="flex items-center gap-1 text-xs text-slate-500 font-medium">
                      <Clock className="w-3.5 h-3.5 text-slate-400" />
                      <span>{project.estimatedTime}</span>
                    </div>
                  </div>

                  <p className="text-xs text-slate-600 leading-relaxed">{project.description}</p>

                  {/* Why this fits your skills banner */}
                  <div className="p-3 rounded-xl bg-blue-50/80 border border-blue-100 text-xs text-blue-900 space-y-1">
                    <div className="font-bold flex items-center gap-1 text-blue-800">
                      <Sparkles className="w-3 h-3 text-blue-600" />
                      <span>Why This Fits Your Skills:</span>
                    </div>
                    <p className="text-[11px] text-blue-800 leading-relaxed">{project.whyThisProject}</p>
                  </div>

                  {/* Key implementation steps */}
                  <div className="space-y-1.5 pt-1">
                    <div className="text-[11px] font-bold uppercase tracking-wider text-slate-500">
                      Key Milestone Steps:
                    </div>
                    <ul className="space-y-1 text-xs text-slate-700">
                      {project.steps.map((st, sIdx) => (
                        <li key={sIdx} className="flex items-start gap-2">
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 shrink-0 mt-0.5" />
                          <span>{st}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Target skill tags */}
                  <div className="flex flex-wrap items-center gap-1.5 pt-2 border-t border-slate-100">
                    <span className="text-[11px] text-slate-400 font-medium mr-1">Skills Exercised:</span>
                    {(project.targetSkills || project.techStack || []).map((sk) => (
                      <span
                        key={sk}
                        className="text-[11px] px-2 py-0.5 rounded-md bg-slate-100 text-slate-700 font-medium"
                      >
                        {sk}
                      </span>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Column (lg:col-span-5): Tasks & Suggestions */}
        <div className="lg:col-span-5 space-y-8">
          {/* Section: Actionable Improvement Tasks */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold">
                  <CheckSquare className="w-4 h-4" />
                </div>
                <div>
                  <h2 className="text-lg font-bold text-slate-900">Targeted Tasks</h2>
                  <p className="text-xs text-slate-500">Prioritized for your current skills</p>
                </div>
              </div>

              {/* Filter tabs */}
              <div className="flex items-center bg-slate-100 p-0.5 rounded-lg text-xs font-semibold text-slate-600">
                <button
                  onClick={() => setTaskFilter('all')}
                  className={`px-2 py-1 rounded-md transition-colors ${
                    taskFilter === 'all' ? 'bg-white text-slate-900 shadow-xs' : 'hover:text-slate-900'
                  }`}
                >
                  All
                </button>
                <button
                  onClick={() => setTaskFilter('pending')}
                  className={`px-2 py-1 rounded-md transition-colors ${
                    taskFilter === 'pending' ? 'bg-white text-slate-900 shadow-xs' : 'hover:text-slate-900'
                  }`}
                >
                  Pending
                </button>
                <button
                  onClick={() => setTaskFilter('completed')}
                  className={`px-2 py-1 rounded-md transition-colors ${
                    taskFilter === 'completed' ? 'bg-white text-slate-900 shadow-xs' : 'hover:text-slate-900'
                  }`}
                >
                  Done
                </button>
              </div>
            </div>

            <div className="space-y-2.5">
              {filteredTasks.length === 0 ? (
                <div className="p-6 text-center bg-white rounded-2xl border border-slate-200 text-xs text-slate-500">
                  No tasks match this filter.
                </div>
              ) : (
                filteredTasks.map((task) => {
                  const isDone = completedCustomTaskIds.includes(task.id);
                  const priorityColor =
                    task.priority === 'High'
                      ? 'text-rose-600 bg-rose-50 border-rose-200'
                      : task.priority === 'Medium'
                      ? 'text-amber-600 bg-amber-50 border-amber-200'
                      : 'text-slate-600 bg-slate-50 border-slate-200';

                  return (
                    <div
                      key={task.id}
                      onClick={() => toggleCustomTask(task.id)}
                      className={`p-4 rounded-2xl border transition-all cursor-pointer select-none space-y-2 ${
                        isDone
                          ? 'bg-slate-50/70 border-slate-200 opacity-80'
                          : 'bg-white border-slate-200 shadow-xs hover:border-blue-300 hover:shadow-sm'
                      }`}
                    >
                      <div className="flex items-start gap-3">
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            toggleCustomTask(task.id);
                          }}
                          className="mt-0.5 text-blue-600 hover:text-blue-800 transition-colors"
                        >
                          {isDone ? (
                            <CheckCircle2 className="w-5 h-5 text-emerald-600 fill-emerald-100" />
                          ) : (
                            <Circle className="w-5 h-5 text-slate-400" />
                          )}
                        </button>
                        <div className="flex-1 space-y-1">
                          <div className="flex items-center justify-between gap-2">
                            <span
                              className={`text-xs font-bold ${
                                isDone ? 'line-through text-slate-400' : 'text-slate-800'
                              }`}
                            >
                              {task.title}
                            </span>
                            <span
                              className={`text-[9px] font-bold px-1.5 py-0.5 rounded border uppercase tracking-wider ${priorityColor}`}
                            >
                              {task.priority}
                            </span>
                          </div>
                          <p className={`text-[11px] leading-relaxed ${isDone ? 'text-slate-400' : 'text-slate-600'}`}>
                            {task.actionableOutcome}
                          </p>
                          <div className="flex items-center justify-between pt-1 text-[10px] text-slate-400">
                            <span className="font-semibold text-slate-500">{task.category}</span>
                            <span className="flex items-center gap-1">
                              <Clock className="w-3 h-3" />
                              <span>{task.estimatedHours}h est.</span>
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>

          {/* Section: Strategic Skill Bridge Suggestions */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-amber-100 text-amber-700 flex items-center justify-center font-bold">
                <Lightbulb className="w-4 h-4" />
              </div>
              <div>
                <h2 className="text-lg font-bold text-slate-900">Skill Bridge Suggestions</h2>
                <p className="text-xs text-slate-500">Recommended complementary next steps</p>
              </div>
            </div>

            <div className="space-y-3">
              {customSkillPlan?.suggestions.map((sugg) => (
                <div
                  key={sugg.id}
                  className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs space-y-2.5"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <span className="text-[10px] font-bold uppercase tracking-wider text-amber-600 bg-amber-50 px-2 py-0.5 rounded-full border border-amber-200">
                        {sugg.targetCategory}
                      </span>
                      <h4 className="text-sm font-bold text-slate-900 mt-1">
                        Recommended Next: {sugg.recommendedSkill}
                      </h4>
                    </div>
                    <span className="text-[10px] font-bold text-slate-500 bg-slate-100 px-2 py-0.5 rounded">
                      {sugg.expectedTimeline}
                    </span>
                  </div>

                  <p className="text-xs text-slate-600 leading-relaxed">{sugg.rationale}</p>

                  <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-100 text-[11px] text-slate-700 space-y-0.5">
                    <span className="font-bold text-slate-800">Action to Take: </span>
                    <span>{sugg.practiceAction}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
