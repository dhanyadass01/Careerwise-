import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { GitBranch, CheckCircle2, Lock, ArrowRight, Sparkles, HelpCircle, AlertCircle } from 'lucide-react';

interface PrereqNode {
  id: string;
  title: string;
  category: string;
  status: 'Completed' | 'In Progress' | 'Recommended Next' | 'Locked';
  missingPrereqs?: string[];
  unlocks: string[];
  description: string;
}

interface TrackChain {
  id: string;
  name: string;
  description: string;
  nodes: PrereqNode[];
}

export const SkillDependencyMapView: React.FC = () => {
  const { progressMap } = useApp();

  const isSkillDone = (id: string) => Boolean(progressMap[id]?.isCompleted || (progressMap[id]?.quizScore && progressMap[id].quizScore! >= 70));
  const isSkillActive = (id: string) => Boolean(progressMap[id] && !isSkillDone(id));

  const [activeTrack, setActiveTrack] = useState<string>('frontend');
  const [selectedNode, setSelectedNode] = useState<PrereqNode | null>(null);

  const chains: TrackChain[] = [
    {
      id: 'frontend',
      name: 'Full Stack & Web Development Track',
      description: 'Progression from markup and styles to modern reactive interfaces and full-stack API integration.',
      nodes: [
        {
          id: 'cs_html_css',
          title: 'HTML5 & Modern CSS',
          category: 'Markup & Layout',
          status: isSkillDone('cs_html_css') ? 'Completed' : isSkillActive('cs_html_css') ? 'In Progress' : 'Recommended Next',
          unlocks: ['Modern JavaScript (ES6+)'],
          description: 'Semantic markup, Flexbox and CSS Grid responsive layouts.',
        },
        {
          id: 'cs_c_python',
          title: 'Programming Logic (JS/Python)',
          category: 'Logic Fundamentals',
          status: isSkillDone('cs_c_python') ? 'Completed' : 'In Progress',
          unlocks: ['React & Component Architecture'],
          description: 'Data types, control structures, functions, and algorithmic operations.',
        },
        {
          id: 'cs_web_dev',
          title: 'React & Component Architecture',
          category: 'Frontend Framework',
          status: isSkillDone('cs_web_dev') ? 'Completed' : isSkillDone('cs_html_css') ? 'In Progress' : 'Locked',
          missingPrereqs: !isSkillDone('cs_html_css') ? ['HTML5 & Modern CSS'] : undefined,
          unlocks: ['Full Stack Backend & Relational APIs'],
          description: 'Functional components, hooks (useState, useEffect), props, and single-page apps.',
        },
        {
          id: 'cs_sql',
          title: 'SQL & Relational Databases',
          category: 'Database & Persistence',
          status: isSkillDone('cs_sql') ? 'Completed' : 'Recommended Next',
          unlocks: ['Full Stack Backend & Relational APIs'],
          description: 'ER modeling, normalization, joins, and transactions.',
        },
        {
          id: 'cs_full_stack',
          title: 'Full Stack Backend & Relational APIs',
          category: 'Full Stack Engineering',
          status: isSkillDone('cs_full_stack') ? 'Completed' : isSkillDone('cs_web_dev') && isSkillDone('cs_sql') ? 'In Progress' : 'Locked',
          missingPrereqs: [
            ...(!isSkillDone('cs_web_dev') ? ['React & Component Architecture'] : []),
            ...(!isSkillDone('cs_sql') ? ['SQL & Relational Databases'] : []),
          ],
          unlocks: ['Campus Capstone Project'],
          description: 'Express REST architecture, PostgreSQL ORM, authentication security, and deployments.',
        },
        {
          id: 'proj_cs_1',
          title: 'Campus Capstone Project',
          category: 'Capstone Proof-of-Work',
          status: isSkillDone('cs_full_stack') ? 'Recommended Next' : 'Locked',
          missingPrereqs: !isSkillDone('cs_full_stack') ? ['Full Stack Backend & Relational APIs'] : undefined,
          unlocks: ['Recruitment Shortlist'],
          description: 'Production-ready deployed portal with peer reviews and automated analytics.',
        },
      ],
    },
    {
      id: 'aiml',
      name: 'AI & Machine Learning Track',
      description: 'Progression from computational mathematics and data handling to deep generative networks.',
      nodes: [
        {
          id: 'cs_c_python',
          title: 'Python Core Scripting',
          category: 'Language Core',
          status: isSkillDone('cs_c_python') ? 'Completed' : 'In Progress',
          unlocks: ['NumPy & Pandas Tabular Analysis'],
          description: 'List comprehensions, dict lookups, functions, and standard libraries.',
        },
        {
          id: 'aiml_python_data',
          title: 'NumPy & Pandas Tabular Analysis',
          category: 'Vector Computing',
          status: isSkillDone('aiml_python_data') ? 'Completed' : isSkillDone('cs_c_python') ? 'In Progress' : 'Locked',
          missingPrereqs: !isSkillDone('cs_c_python') ? ['Python Core Scripting'] : undefined,
          unlocks: ['Machine Learning Algorithms'],
          description: 'Vectorized arrays, DataFrames, data cleaning, and statistical visualizations.',
        },
        {
          id: 'aiml_ml_fund',
          title: 'Machine Learning Algorithms',
          category: 'Supervised & Unsupervised',
          status: isSkillDone('aiml_ml_fund') ? 'Completed' : isSkillDone('aiml_python_data') ? 'In Progress' : 'Locked',
          missingPrereqs: !isSkillDone('aiml_python_data') ? ['NumPy & Pandas Tabular Analysis'] : undefined,
          unlocks: ['Deep Learning & Generative AI'],
          description: 'Regression, Classification, Cross-Validation, and Pipelines.',
        },
        {
          id: 'aiml_deep_learning',
          title: 'Deep Learning & Generative AI',
          category: 'Advanced Neural Nets',
          status: isSkillDone('aiml_deep_learning') ? 'Completed' : isSkillDone('aiml_ml_fund') ? 'Recommended Next' : 'Locked',
          missingPrereqs: !isSkillDone('aiml_ml_fund') ? ['Machine Learning Algorithms'] : undefined,
          unlocks: ['AI Capstone Engineering'],
          description: 'CNNs, Transformers, Vector Embeddings, and RAG systems.',
        },
      ],
    },
    {
      id: 'commerce',
      name: 'Commerce & Financial Analysis Track',
      description: 'Progression from double-entry accounting and taxation to corporate financial modeling and Power BI.',
      nodes: [
        {
          id: 'bcom_accounting_fund',
          title: 'Accounting Fundamentals',
          category: 'Core Principles',
          status: isSkillDone('bcom_accounting_fund') ? 'Completed' : 'In Progress',
          unlocks: ['Advanced Excel for Finance', 'Tally Prime & GST'],
          description: 'Golden rules of accounting, journal entries, ledger balancing, and final statements.',
        },
        {
          id: 'bcom_tally',
          title: 'Tally Prime & GST Compliance',
          category: 'Taxation & Books',
          status: isSkillDone('bcom_tally') ? 'Completed' : isSkillDone('bcom_accounting_fund') ? 'In Progress' : 'Locked',
          missingPrereqs: !isSkillDone('bcom_accounting_fund') ? ['Accounting Fundamentals'] : undefined,
          unlocks: ['Financial Analysis & Power BI'],
          description: 'Voucher accounting, GST tax ledgers, and e-way billing audit returns.',
        },
        {
          id: 'bcom_adv_excel',
          title: 'Advanced Excel Financial Modeling',
          category: 'Spreadsheet Engineering',
          status: isSkillDone('bcom_adv_excel') ? 'Completed' : isSkillDone('bcom_accounting_fund') ? 'In Progress' : 'Locked',
          missingPrereqs: !isSkillDone('bcom_accounting_fund') ? ['Accounting Fundamentals'] : undefined,
          unlocks: ['Financial Analysis & Power BI'],
          description: 'XLOOKUP, Pivot Tables, NPV/IRR formulas, and dynamic financial statements.',
        },
        {
          id: 'bcom_fin_analysis',
          title: 'Financial Analysis & Power BI',
          category: 'Executive Business Intelligence',
          status: isSkillDone('bcom_fin_analysis') ? 'Completed' : isSkillDone('bcom_adv_excel') ? 'Recommended Next' : 'Locked',
          missingPrereqs: !isSkillDone('bcom_adv_excel') ? ['Advanced Excel Financial Modeling'] : undefined,
          unlocks: ['Financial Capstone Audit'],
          description: 'Ratio analysis, DuPont decomposition, Power BI data models, and executive DAX cards.',
        },
      ],
    },
    {
      id: 'business',
      name: 'Business Strategy & Marketing Track',
      description: 'Progression from management fundamentals to digital funnels, CRM selling, and brand campaigns.',
      nodes: [
        {
          id: 'bba_mgmt_fund',
          title: 'Management Fundamentals & SWOT',
          category: 'Strategic Foundations',
          status: isSkillDone('bba_mgmt_fund') ? 'Completed' : 'In Progress',
          unlocks: ['Digital Marketing & Analytics'],
          description: 'Fayol principles, organizational hierarchies, and competitive SWOT frameworks.',
        },
        {
          id: 'bba_digital_mktg',
          title: 'Digital Marketing & Consumer Behaviour',
          category: 'Paid & Organic Growth',
          status: isSkillDone('bba_digital_mktg') ? 'Completed' : isSkillDone('bba_mgmt_fund') ? 'In Progress' : 'Locked',
          missingPrereqs: !isSkillDone('bba_mgmt_fund') ? ['Management Fundamentals & SWOT'] : undefined,
          unlocks: ['Consultative Sales & CRM Pipelines'],
          description: 'SEO, Google/Meta Ads campaigns, buyer psychology, CAC and ROAS metrics.',
        },
        {
          id: 'bba_sales_bizdev',
          title: 'Consultative Sales & CRM Pipelines',
          category: 'Commercial Execution',
          status: isSkillDone('bba_sales_bizdev') ? 'Completed' : isSkillDone('bba_digital_mktg') ? 'Recommended Next' : 'Locked',
          missingPrereqs: !isSkillDone('bba_digital_mktg') ? ['Digital Marketing & Consumer Behaviour'] : undefined,
          unlocks: ['D2C Pitch Capstone'],
          description: 'SPIN selling, objection handling, enterprise negotiation, and CRM pipelines.',
        },
      ],
    },
  ];

  const currentChain = chains.find((c) => c.id === activeTrack) || chains[0];

  const getNodeColor = (status: string) => {
    switch (status) {
      case 'Completed':
        return 'bg-emerald-50 border-emerald-400 text-emerald-950';
      case 'In Progress':
        return 'bg-blue-50 border-blue-400 text-blue-950';
      case 'Recommended Next':
        return 'bg-purple-50 border-purple-400 text-purple-950 ring-2 ring-purple-300';
      default:
        return 'bg-slate-50 border-slate-300 text-slate-500 opacity-80';
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2">
              <span className="p-2 rounded-xl bg-purple-50 text-purple-600">
                <GitBranch className="w-6 h-6" />
              </span>
              <div>
                <h1 className="text-2xl font-extrabold text-slate-900">
                  Interactive Skill Dependency Map
                </h1>
                <p className="text-xs text-slate-500">
                  Prerequisite verification graph ensuring rigorous mastery before advancing to specialized modules
                </p>
              </div>
            </div>
          </div>

          {/* Legend */}
          <div className="flex flex-wrap items-center gap-2 text-xs">
            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-emerald-50 text-emerald-800 border border-emerald-200 font-semibold">
              <span className="w-2 h-2 rounded-full bg-emerald-500"></span> Completed
            </span>
            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-blue-50 text-blue-800 border border-blue-200 font-semibold">
              <span className="w-2 h-2 rounded-full bg-blue-500"></span> In Progress
            </span>
            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-purple-50 text-purple-800 border border-purple-200 font-semibold">
              <span className="w-2 h-2 rounded-full bg-purple-500"></span> Recommended Next
            </span>
            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-100 text-slate-600 border border-slate-200 font-semibold">
              <Lock className="w-3 h-3 text-slate-400" /> Locked Prereq
            </span>
          </div>
        </div>

        {/* Track Switcher */}
        <div className="mt-8 border-t border-slate-100 pt-6">
          <p className="text-xs font-semibold text-slate-500 mb-2">Select Prerequisite Pathway:</p>
          <div className="flex flex-wrap gap-2">
            {chains.map((chain) => (
              <button
                key={chain.id}
                onClick={() => {
                  setActiveTrack(chain.id);
                  setSelectedNode(null);
                }}
                className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all ${
                  activeTrack === chain.id
                    ? 'bg-purple-600 text-white shadow-sm shadow-purple-500/20'
                    : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                }`}
              >
                {chain.name}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Main Flow Map Canvas */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs">
        <div className="mb-6">
          <h2 className="text-base font-bold text-slate-900">{currentChain.name}</h2>
          <p className="text-xs text-slate-500 mt-0.5">{currentChain.description}</p>
        </div>

        {/* Node Graph Flow */}
        <div className="relative">
          <div className="space-y-4">
            {currentChain.nodes.map((node, index) => {
              const isLocked = node.status === 'Locked';
              const isSelected = selectedNode?.id === node.id;

              return (
                <div key={node.id} className="relative">
                  {/* Vertical connecting line */}
                  {index < currentChain.nodes.length - 1 && (
                    <div className="absolute left-6 top-14 w-0.5 h-8 bg-slate-200 z-0 hidden sm:block"></div>
                  )}

                  <div
                    onClick={() => setSelectedNode(node)}
                    className={`p-5 rounded-2xl border-2 transition-all cursor-pointer relative z-10 ${getNodeColor(
                      node.status
                    )} ${isSelected ? 'ring-2 ring-blue-500 shadow-md' : 'hover:shadow-xs'}`}
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                      <div className="flex items-start gap-3">
                        <div className="w-8 h-8 rounded-xl bg-white border border-slate-200 flex items-center justify-center font-bold text-xs shrink-0 mt-0.5 shadow-2xs">
                          {isLocked ? (
                            <Lock className="w-4 h-4 text-slate-400" />
                          ) : node.status === 'Completed' ? (
                            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                          ) : (
                            <span className="text-slate-700">{index + 1}</span>
                          )}
                        </div>

                        <div>
                          <div className="flex flex-wrap items-center gap-2">
                            <h3 className="text-sm font-extrabold">{node.title}</h3>
                            <span className="text-[10px] font-semibold px-2 py-0.5 rounded-md bg-white/80 border border-slate-200">
                              {node.category}
                            </span>
                          </div>
                          <p className="text-xs mt-1 opacity-90 leading-relaxed">{node.description}</p>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 self-start sm:self-center shrink-0">
                        <span className="text-[11px] font-bold uppercase tracking-wider px-2.5 py-1 rounded-full bg-white/90 border border-slate-200">
                          {node.status}
                        </span>
                      </div>
                    </div>

                    {/* Missing Prerequisites Warning if Locked */}
                    {isLocked && node.missingPrereqs && (
                      <div className="mt-3 p-2.5 rounded-xl bg-amber-100/70 border border-amber-300 text-amber-900 text-xs flex items-center gap-2">
                        <AlertCircle className="w-4 h-4 text-amber-700 shrink-0" />
                        <span>
                          <strong>Missing Prerequisite:</strong> You must first complete{' '}
                          {node.missingPrereqs.join(' & ')} before starting this milestone.
                        </span>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Selected Node Details Drawer */}
        {selectedNode && (
          <div className="mt-8 p-6 rounded-2xl bg-slate-50 border border-slate-200 animate-in fade-in duration-200">
            <div className="flex items-start justify-between gap-4">
              <div>
                <span className="text-[10px] font-bold uppercase text-blue-600 bg-blue-100 px-2 py-0.5 rounded">
                  Inspected Node
                </span>
                <h4 className="text-base font-bold text-slate-900 mt-1">{selectedNode.title}</h4>
                <p className="text-xs text-slate-600 mt-1">{selectedNode.description}</p>
              </div>
              <button
                onClick={() => setSelectedNode(null)}
                className="text-xs text-slate-400 hover:text-slate-600"
              >
                Close ✕
              </button>
            </div>

            <div className="mt-4 pt-4 border-t border-slate-200 grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div>
                <span className="font-bold text-slate-700">Skills Unlocked Upon Completion:</span>
                <ul className="mt-1 space-y-1">
                  {selectedNode.unlocks.map((u, i) => (
                    <li key={i} className="text-slate-600 flex items-center gap-1.5">
                      <Sparkles className="w-3.5 h-3.5 text-purple-600" />
                      <span>{u}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div>
                <span className="font-bold text-slate-700">Prerequisite Requirements:</span>
                <p className="mt-1 text-slate-600">
                  {selectedNode.missingPrereqs
                    ? `Requires: ${selectedNode.missingPrereqs.join(', ')}`
                    : 'All foundational prerequisites satisfied!'}
                </p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
