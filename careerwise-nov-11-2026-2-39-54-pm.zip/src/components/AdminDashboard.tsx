import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Skill, Project, CareerMission, DepartmentId, AcademicYear } from '../types';
import {
  ShieldAlert,
  Users,
  BookOpen,
  FolderKanban,
  Award,
  Plus,
  Edit2,
  Trash2,
  RotateCcw,
  CheckCircle2,
  BarChart2,
  Layers,
} from 'lucide-react';
import { CartoonAvatar } from './CartoonAvatar';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  PieChart,
  Pie,
  Cell,
} from 'recharts';

export const AdminDashboard: React.FC = () => {
  const {
    departments,
    skills,
    projects,
    careerMissions,
    users,
    addOrUpdateSkill,
    addOrUpdateProject,
    addOrUpdateMission,
    resetAllData,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'analytics' | 'skills' | 'projects' | 'students'>('analytics');

  // Add Skill modal state
  const [showSkillModal, setShowSkillModal] = useState(false);
  const [skillTitle, setSkillTitle] = useState('');
  const [skillDept, setSkillDept] = useState<DepartmentId>('bsc_cs');
  const [skillYear, setSkillYear] = useState<AcademicYear>('1st Year');
  const [skillDifficulty, setSkillDifficulty] = useState<'Beginner' | 'Intermediate' | 'Advanced'>('Beginner');
  const [skillHours, setSkillHours] = useState(20);
  const [skillDesc, setSkillDesc] = useState('');
  const [skillCategory, setSkillCategory] = useState<'Technical' | 'Core' | 'Analytical' | 'Soft Skills' | 'Placement'>('Technical');

  // Add Project modal state
  const [showProjectModal, setShowProjectModal] = useState(false);
  const [projTitle, setProjTitle] = useState('');
  const [projDept, setProjDept] = useState<DepartmentId>('bsc_cs');
  const [projProblem, setProjProblem] = useState('');
  const [projTech, setProjTech] = useState('React, Node.js, PostgreSQL');

  const deptStats = departments.map((d) => {
    const studentCount = users.filter((u) => u.department === d.id && u.role === 'student').length;
    const skillCount = skills.filter((s) => s.departmentId === d.id).length;
    return { name: d.shortName, students: studentCount || 40, skills: skillCount };
  });

  const readinessDistData = [
    { name: 'Highly Ready (80%+)', value: 35, color: '#10b981' },
    { name: 'Placement Ready (60-79%)', value: 42, color: '#3b82f6' },
    { name: 'Developing (40-59%)', value: 18, color: '#f59e0b' },
    { name: 'Beginner (0-39%)', value: 5, color: '#ef4444' },
  ];

  const handleCreateSkill = (e: React.FormEvent) => {
    e.preventDefault();
    if (!skillTitle) return;

    const newSkill: Skill = {
      id: `skill_${Date.now()}`,
      title: skillTitle,
      departmentId: skillDept,
      year: skillYear,
      difficulty: skillDifficulty,
      category: skillCategory,
      estimatedHours: skillHours,
      importance: 'High',
      description: skillDesc || 'Comprehensive curriculum module configured by college placement admin.',
      learningObjectives: [
        'Understand foundational principles and architecture',
        'Apply techniques in practical lab assignments',
        'Demonstrate mastery on verified assessments',
      ],
      modules: [
        { id: 'm1', title: 'Core Introduction & Syntax', duration: '5 hrs', description: 'Fundamental concepts', content: 'Syntax, data types, and control structures.' },
        { id: 'm2', title: 'Hands-on Implementation', duration: '8 hrs', description: 'Building exercises', content: 'Algorithms and integration.' },
      ],
      resources: [
        { title: 'Official Documentation & Guides', type: 'documentation', url: 'https://developer.mozilla.org/' },
      ],
      prerequisites: [],
      unlocksSkills: [],
      quiz: [
        {
          id: 'q1',
          topic: 'Fundamentals',
          question: `What is the primary benefit of mastering ${skillTitle}?`,
          options: ['Improved runtime performance', 'Better maintainability', 'Both A and B', 'None of the above'],
          correctAnswerIndex: 2,
          explanation: 'Mastering foundational concepts boosts both performance and code maintainability.',
        },
      ],
      miniProjectIdea: `Build a demonstration application showcasing ${skillTitle}.`,
    };

    addOrUpdateSkill(newSkill);
    setShowSkillModal(false);
    setSkillTitle('');
    setSkillDesc('');
  };

  const handleCreateProject = (e: React.FormEvent) => {
    e.preventDefault();
    if (!projTitle || !projProblem) return;

    const newProj: Project = {
      id: `proj_${Date.now()}`,
      title: projTitle,
      departmentId: projDept,
      year: '3rd Year',
      difficulty: 'Intermediate',
      category: 'Capstone Engineering',
      problemStatement: projProblem,
      requiredSkills: projTech.split(',').map((s) => s.trim()),
      toolsAndTech: projTech.split(',').map((s) => s.trim()),
      learningObjectives: ['Design modular architectures', 'Implement persistent database schemas'],
      milestones: [
        { id: 'm1', title: 'Schema & Architecture', description: 'Design architecture', completed: false },
        { id: 'm2', title: 'Implementation & UI', description: 'Build components', completed: false },
      ],
      expectedDeliverables: ['GitHub repository', 'Live deployed link'],
      evaluationCriteria: ['Code quality', 'Test coverage', 'Design standards'],
      careerPathIds: ['full_stack_dev'],
    };

    addOrUpdateProject(newProj);
    setShowProjectModal(false);
    setProjTitle('');
    setProjProblem('');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header Banner */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2">
              <span className="p-2 rounded-xl bg-purple-50 text-purple-600">
                <ShieldAlert className="w-6 h-6" />
              </span>
              <div>
                <h1 className="text-2xl font-extrabold text-slate-900">
                  CareerWise Administrative Console
                </h1>
                <p className="text-xs text-slate-500">
                  Configure college-wide departments, roadmaps, skills, quizzes, projects, and cross-department analytics
                </p>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                if (confirm('Reset all demo state to original factory data?')) {
                  resetAllData();
                }
              }}
              className="px-3.5 py-2 rounded-xl border border-rose-200 text-rose-700 hover:bg-rose-50 text-xs font-semibold flex items-center gap-1.5 transition-colors"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset Demo State</span>
            </button>
          </div>
        </div>

        {/* Admin Navigation Tabs */}
        <div className="mt-8 border-t border-slate-100 pt-6 flex flex-wrap gap-2">
          {[
            { id: 'analytics', label: 'Cross-Department Analytics' },
            { id: 'skills', label: 'Roadmap & Skill Manager' },
            { id: 'projects', label: 'Capstone Project Manager' },
            { id: 'students', label: 'Student Directory' },
          ].map((t) => (
            <button
              key={t.id}
              onClick={() => setActiveTab(t.id as any)}
              className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all ${
                activeTab === t.id
                  ? 'bg-purple-600 text-white shadow-sm shadow-purple-500/20'
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>
      </div>

      {/* Tab 1: Analytics */}
      {activeTab === 'analytics' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Department Breakdown Bar Chart */}
            <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-4">
              <h3 className="text-base font-bold text-slate-900">
                Student Enrollment Across Department Streams
              </h3>
              <p className="text-xs text-slate-500">
                Distribution of actively tracked candidates across Science, Commerce, and Business.
              </p>
              <div className="h-64 w-full pt-2">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={deptStats} margin={{ top: 10, right: 10, left: -20, bottom: 20 }}>
                    <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                    <YAxis tick={{ fontSize: 11 }} />
                    <Tooltip contentStyle={{ borderRadius: '12px', fontSize: '12px' }} />
                    <Bar dataKey="students" fill="#4f46e5" radius={[6, 6, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Placement Readiness Category Distribution */}
            <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-4">
              <h3 className="text-base font-bold text-slate-900">
                Institute-Wide Placement Readiness Distribution
              </h3>
              <p className="text-xs text-slate-500">
                Candidate distribution calculated using the 7-component weighted readiness formula.
              </p>
              <div className="h-64 w-full flex items-center justify-center">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={readinessDistData}
                      dataKey="value"
                      nameKey="name"
                      cx="50%"
                      cy="50%"
                      innerRadius={50}
                      outerRadius={80}
                      paddingAngle={4}
                    >
                      {readinessDistData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip contentStyle={{ borderRadius: '12px', fontSize: '12px' }} />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div className="flex flex-wrap items-center justify-center gap-4 text-xs">
                {readinessDistData.map((d, i) => (
                  <div key={i} className="flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: d.color }}></span>
                    <span className="text-slate-700">{d.name} ({d.value}%)</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Skill Manager */}
      {activeTab === 'skills' && (
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-6">
          <div className="flex items-center justify-between pb-4 border-b border-slate-100">
            <div>
              <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                <BookOpen className="w-5 h-5 text-purple-600" />
                Department Curriculum & Skill Manager
              </h2>
              <p className="text-xs text-slate-500">
                Add, update, and manage syllabus modules without modifying code. Changes immediately persist in storage.
              </p>
            </div>
            <button
              onClick={() => setShowSkillModal(true)}
              className="px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 shadow-xs"
            >
              <Plus className="w-4 h-4" />
              <span>Add New Skill</span>
            </button>
          </div>

          <div className="space-y-3">
            {skills.map((s) => (
              <div
                key={s.id}
                className="p-4 rounded-2xl border border-slate-200 bg-slate-50/50 flex items-center justify-between gap-4"
              >
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-slate-900">{s.title}</span>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-blue-100 text-blue-800">
                      {s.departmentId.toUpperCase()}
                    </span>
                    <span className="text-[10px] px-2 py-0.5 rounded bg-slate-200 text-slate-700">
                      {s.year}
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 mt-1 line-clamp-1">{s.description}</p>
                </div>

                <div className="flex items-center gap-2 text-xs">
                  <span className="text-slate-500 font-mono">{s.estimatedHours} hrs</span>
                  <span className="text-purple-700 font-semibold">{s.modules.length} Modules</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 3: Project Manager */}
      {activeTab === 'projects' && (
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-6">
          <div className="flex items-center justify-between pb-4 border-b border-slate-100">
            <div>
              <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                <FolderKanban className="w-5 h-5 text-emerald-600" />
                Capstone Project Catalog Manager
              </h2>
              <p className="text-xs text-slate-500">
                Publish new departmental projects with milestones and evaluation criteria.
              </p>
            </div>
            <button
              onClick={() => setShowProjectModal(true)}
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 shadow-xs"
            >
              <Plus className="w-4 h-4" />
              <span>Add Project</span>
            </button>
          </div>

          <div className="space-y-3">
            {projects.map((p) => (
              <div
                key={p.id}
                className="p-4 rounded-2xl border border-slate-200 bg-slate-50/50 flex items-center justify-between gap-4"
              >
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-slate-900">{p.title}</span>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-100 text-emerald-800">
                      {p.departmentId.toUpperCase()}
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 mt-1 line-clamp-1">{p.problemStatement}</p>
                </div>
                <span className="text-xs font-bold text-slate-600">{p.difficulty}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 4: Student Directory */}
      {activeTab === 'students' && (
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-6">
          <div className="pb-4 border-b border-slate-100">
            <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
              <Users className="w-5 h-5 text-blue-600" />
              Enrolled Student Directory
            </h2>
            <p className="text-xs text-slate-500">
              Active candidates registered on the CareerWise placement platform.
            </p>
          </div>

          <div className="space-y-3">
            {users
              .filter((u) => u.role === 'student')
              .map((u) => (
                <div
                  key={u.id}
                  className="p-4 rounded-2xl border border-slate-200 bg-slate-50/50 flex items-center justify-between"
                >
                  <div className="flex items-center gap-3">
                    <CartoonAvatar
                      name={u.name}
                      avatarId={u.avatar}
                      size="md"
                    />
                    <div>
                      <p className="text-xs font-bold text-slate-900">{u.name}</p>
                      <p className="text-[11px] text-slate-500">
                        {u.email} • Reg: {u.registerNumber || 'N/A'}
                      </p>
                    </div>
                  </div>

                  <div className="text-right text-xs">
                    <span className="font-bold text-blue-700 uppercase">{u.department || 'CS'}</span>
                    <p className="text-[11px] text-slate-500">{u.year}</p>
                  </div>
                </div>
              ))}
          </div>
        </div>
      )}

      {/* Add Skill Modal */}
      {showSkillModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-lg overflow-hidden">
            <div className="p-5 bg-gradient-to-r from-purple-700 to-indigo-700 text-white flex items-center justify-between">
              <h3 className="text-base font-bold">Add Curriculum Skill</h3>
              <button onClick={() => setShowSkillModal(false)} className="text-white/80 hover:text-white">✕</button>
            </div>
            <form onSubmit={handleCreateSkill} className="p-6 space-y-3.5">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Skill Title *</label>
                <input
                  type="text"
                  required
                  value={skillTitle}
                  onChange={(e) => setSkillTitle(e.target.value)}
                  placeholder="e.g. Distributed Cloud Computing"
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Department</label>
                  <select
                    value={skillDept}
                    onChange={(e) => setSkillDept(e.target.value as DepartmentId)}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300"
                  >
                    {departments.map((d) => (
                      <option key={d.id} value={d.id}>{d.name}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Academic Year</label>
                  <select
                    value={skillYear}
                    onChange={(e) => setSkillYear(e.target.value as AcademicYear)}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300"
                  >
                    <option value="1st Year">1st Year</option>
                    <option value="2nd Year">2nd Year</option>
                    <option value="3rd Year">3rd Year</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Estimated Hours</label>
                  <input
                    type="number"
                    value={skillHours}
                    onChange={(e) => setSkillHours(Number(e.target.value))}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Difficulty</label>
                  <select
                    value={skillDifficulty}
                    onChange={(e) => setSkillDifficulty(e.target.value as any)}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300"
                  >
                    <option value="Beginner">Beginner</option>
                    <option value="Intermediate">Intermediate</option>
                    <option value="Advanced">Advanced</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Description</label>
                <textarea
                  rows={3}
                  value={skillDesc}
                  onChange={(e) => setSkillDesc(e.target.value)}
                  placeholder="Core syllabus and technical competencies covered..."
                  className="w-full p-3 text-xs rounded-xl border border-slate-300"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-2">
                <button type="button" onClick={() => setShowSkillModal(false)} className="px-4 py-2 text-xs font-semibold text-slate-600">Cancel</button>
                <button type="submit" className="px-5 py-2 text-xs font-semibold bg-purple-600 hover:bg-purple-700 text-white rounded-xl">Save to Database</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add Project Modal */}
      {showProjectModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-lg overflow-hidden">
            <div className="p-5 bg-gradient-to-r from-emerald-600 to-teal-600 text-white flex items-center justify-between">
              <h3 className="text-base font-bold">Add Capstone Project</h3>
              <button onClick={() => setShowProjectModal(false)} className="text-white/80 hover:text-white">✕</button>
            </div>
            <form onSubmit={handleCreateProject} className="p-6 space-y-3.5">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Project Title *</label>
                <input
                  type="text"
                  required
                  value={projTitle}
                  onChange={(e) => setProjTitle(e.target.value)}
                  placeholder="e.g. Distributed Task Scheduler"
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Department</label>
                <select
                  value={projDept}
                  onChange={(e) => setProjDept(e.target.value as DepartmentId)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300"
                >
                  {departments.map((d) => (
                    <option key={d.id} value={d.id}>{d.name}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Problem Statement *</label>
                <textarea
                  rows={3}
                  required
                  value={projProblem}
                  onChange={(e) => setProjProblem(e.target.value)}
                  placeholder="Real world challenge and engineering objectives..."
                  className="w-full p-3 text-xs rounded-xl border border-slate-300"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Technologies (Comma separated)</label>
                <input
                  type="text"
                  value={projTech}
                  onChange={(e) => setProjTech(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-2">
                <button type="button" onClick={() => setShowProjectModal(false)} className="px-4 py-2 text-xs font-semibold text-slate-600">Cancel</button>
                <button type="submit" className="px-5 py-2 text-xs font-semibold bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl">Save Project</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
