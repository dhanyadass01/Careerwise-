import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { InterviewQuestion } from '../types';
import {
  Mic,
  Clock,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  RotateCcw,
  Sparkles,
  Send,
  Play,
  Square,
  Award,
} from 'lucide-react';
import confetti from 'canvas-confetti';

export const InterviewLabView: React.FC = () => {
  const { interviewQuestions, currentUser, saveInterviewPractice } = useApp();

  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [activeQuestionIndex, setActiveQuestionIndex] = useState(0);
  const [studentAnswer, setStudentAnswer] = useState('');
  const [timerSeconds, setTimerSeconds] = useState(120);
  const [isTimerRunning, setIsTimerRunning] = useState(false);
  const [evaluationResult, setEvaluationResult] = useState<{
    score: number;
    strongAreas: string[];
    missingConcepts: string[];
    revisionRecommendation: string;
  } | null>(null);

  // Filter questions by selected category
  const filteredQuestions = interviewQuestions.filter((q) => {
    if (selectedCategory === 'all') return true;
    return q.category === selectedCategory;
  });

  const activeQuestion: InterviewQuestion =
    filteredQuestions[activeQuestionIndex] || interviewQuestions[0];

  // Timer interval
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isTimerRunning && timerSeconds > 0) {
      interval = setInterval(() => {
        setTimerSeconds((prev) => prev - 1);
      }, 1000);
    } else if (timerSeconds === 0) {
      setIsTimerRunning(false);
    }
    return () => clearInterval(interval);
  }, [isTimerRunning, timerSeconds]);

  const handleStartTimer = () => {
    setIsTimerRunning(true);
  };

  const handleResetTimer = () => {
    setIsTimerRunning(false);
    setTimerSeconds(120);
  };

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  const handleEvaluateAnswer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!studentAnswer || studentAnswer.trim().length < 15) {
      alert('Please type or record a complete answer (at least 15 characters) before requesting evaluation.');
      return;
    }

    // Rubric-based deterministic score calculator
    const words = studentAnswer.trim().split(/\s+/).length;
    let score = 70;
    if (words >= 40) score += 15;
    if (words >= 80) score += 10;
    score = Math.min(95, score);

    const rubric = activeQuestion.evaluationRubric;
    const feedback = {
      score,
      strongAreas: [
        'Structured opening articulating technical approach',
        'Demonstrates relevant terminology aligned with ' + activeQuestion.category,
      ],
      missingConcepts: [
        'Could include more quantifiable metrics or measurable outcomes',
        'Elaborate further on trade-offs under edge-case conditions',
      ],
      revisionRecommendation:
        'Revise STAR method storytelling and review: ' + activeQuestion.sampleAnswerGuide,
    };

    setEvaluationResult(feedback);
    saveInterviewPractice({
      studentId: currentUser?.id || 'demo',
      questionId: activeQuestion.id,
      questionText: activeQuestion.question,
      category: activeQuestion.category,
      submittedAnswer: studentAnswer,
      timeSpentSeconds: 120 - timerSeconds,
      score,
      feedback,
    });

    if (score >= 80) {
      confetti({
        particleCount: 70,
        spread: 60,
        origin: { y: 0.6 },
      });
    }
  };

  const handleNextQuestion = () => {
    setStudentAnswer('');
    setEvaluationResult(null);
    handleResetTimer();
    setActiveQuestionIndex((prev) => (prev + 1) % filteredQuestions.length);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header Banner */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2">
              <span className="p-2 rounded-xl bg-amber-50 text-amber-600">
                <Mic className="w-6 h-6" />
              </span>
              <div>
                <h1 className="text-2xl font-extrabold text-slate-900">Interview Practice Lab</h1>
                <p className="text-xs text-slate-500">
                  Department-aware interview simulator with timed practice, sample answer guidance, and structured rubric feedback
                </p>
              </div>
            </div>
          </div>

          <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 text-xs text-slate-600 max-w-sm">
            <strong>Recruiter Guideline:</strong> Mock interview performance contributes directly to your{' '}
            <span className="text-indigo-700 font-bold">Communication and Placement Readiness scores</span>.
          </div>
        </div>

        {/* Category Tabs */}
        <div className="mt-8 border-t border-slate-100 pt-6">
          <p className="text-xs font-semibold text-slate-500 mb-2">Question Category:</p>
          <div className="flex flex-wrap gap-2">
            {[
              { id: 'all', label: 'All Categories' },
              { id: 'HR', label: 'HR Behavioral Rounds' },
              { id: 'Technical', label: 'Technical & Domain Questions' },
              { id: 'Project Explanation', label: 'Project Architecture Defense' },
              { id: 'Communication', label: 'Client & Team Communication' },
            ].map((c) => (
              <button
                key={c.id}
                onClick={() => {
                  setSelectedCategory(c.id);
                  setActiveQuestionIndex(0);
                  setEvaluationResult(null);
                  setStudentAnswer('');
                }}
                className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all ${
                  selectedCategory === c.id
                    ? 'bg-amber-600 text-white shadow-sm shadow-amber-500/20'
                    : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                }`}
              >
                {c.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Main Practice Workspace */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left 2 Cols: Question & Response Editor */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-6">
            {/* Question Banner */}
            <div className="flex items-center justify-between gap-4">
              <span className="text-[10px] font-bold uppercase tracking-wider text-amber-800 bg-amber-100 px-2.5 py-0.5 rounded-full border border-amber-200">
                {activeQuestion.category} Question
              </span>

              {/* Countdown Timer */}
              <div className="flex items-center gap-2">
                <div
                  className={`flex items-center gap-1.5 px-3 py-1 rounded-xl text-xs font-mono font-bold border ${
                    timerSeconds < 30
                      ? 'bg-rose-50 text-rose-700 border-rose-300 animate-pulse'
                      : 'bg-slate-100 text-slate-700 border-slate-200'
                  }`}
                >
                  <Clock className="w-3.5 h-3.5" />
                  <span>{formatTime(timerSeconds)}</span>
                </div>

                {!isTimerRunning ? (
                  <button
                    onClick={handleStartTimer}
                    className="p-1.5 rounded-lg bg-emerald-600 text-white hover:bg-emerald-700 transition-colors"
                    title="Start Timer"
                  >
                    <Play className="w-3.5 h-3.5" />
                  </button>
                ) : (
                  <button
                    onClick={() => setIsTimerRunning(false)}
                    className="p-1.5 rounded-lg bg-amber-600 text-white hover:bg-amber-700 transition-colors"
                    title="Pause Timer"
                  >
                    <Square className="w-3.5 h-3.5" />
                  </button>
                )}

                <button
                  onClick={handleResetTimer}
                  className="p-1.5 rounded-lg bg-slate-200 text-slate-700 hover:bg-slate-300 transition-colors"
                  title="Reset Timer"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* The Question Prompt */}
            <div>
              <p className="text-xs font-semibold text-slate-500 mb-1">
                Question {activeQuestionIndex + 1} of {filteredQuestions.length}:
              </p>
              <h2 className="text-lg sm:text-xl font-bold text-slate-900 leading-snug">
                "{activeQuestion.question}"
              </h2>
            </div>

            {/* Answer Box */}
            <form onSubmit={handleEvaluateAnswer} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Your Answer (Type or dictate your verbal response):
                </label>
                <textarea
                  value={studentAnswer}
                  onChange={(e) => setStudentAnswer(e.target.value)}
                  rows={6}
                  placeholder="Structure your answer clearly. For technical questions, mention core mechanisms, trade-offs, and examples. For behavioral questions, apply the Situation-Task-Action-Result format..."
                  className="w-full p-4 text-xs rounded-2xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-amber-500 leading-relaxed font-sans"
                />
              </div>

              <div className="flex flex-wrap items-center justify-between gap-3">
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-semibold text-xs transition-colors flex items-center gap-2 shadow-xs"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Evaluate with Placement Rubric</span>
                </button>

                <button
                  type="button"
                  onClick={handleNextQuestion}
                  className="px-4 py-2 rounded-xl border border-slate-300 text-slate-700 hover:bg-slate-100 text-xs font-semibold transition-colors"
                >
                  Next Question →
                </button>
              </div>
            </form>
          </div>

          {/* Structured Rubric Evaluation Feedback */}
          {evaluationResult && (
            <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-4 animate-in fade-in duration-200">
              <div className="flex items-center justify-between pb-4 border-b border-slate-100">
                <div className="flex items-center gap-2">
                  <Award className="w-5 h-5 text-amber-600" />
                  <h3 className="text-base font-bold text-slate-900">Rubric Feedback & Score</h3>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs text-slate-500">Practice Score:</span>
                  <span className="text-xl font-black text-amber-700">
                    {evaluationResult.score}/100
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="p-4 rounded-2xl bg-emerald-50/60 border border-emerald-200">
                  <p className="text-xs font-bold text-emerald-900 mb-2 flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    Observed Strong Areas:
                  </p>
                  <ul className="text-xs text-emerald-800 space-y-1">
                    {evaluationResult.strongAreas.map((item, i) => (
                      <li key={i}>• {item}</li>
                    ))}
                  </ul>
                </div>

                <div className="p-4 rounded-2xl bg-rose-50/60 border border-rose-200">
                  <p className="text-xs font-bold text-rose-900 mb-2 flex items-center gap-1.5">
                    <AlertCircle className="w-4 h-4 text-rose-600" />
                    Missing Concepts & Polish:
                  </p>
                  <ul className="text-xs text-rose-800 space-y-1">
                    {evaluationResult.missingConcepts.map((item, i) => (
                      <li key={i}>• {item}</li>
                    ))}
                  </ul>
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 text-xs text-slate-700">
                <span className="font-bold text-slate-900">Recommended Action: </span>
                {evaluationResult.revisionRecommendation}
              </div>
            </div>
          )}
        </div>

        {/* Right Col: Sample Answer Guide & Rubric Structure */}
        <div className="space-y-6">
          {/* Sample Answer Guidance */}
          <div className="bg-gradient-to-br from-amber-50/60 to-orange-50/40 rounded-3xl p-6 border border-amber-200 shadow-xs space-y-3">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-600" />
              <h3 className="text-sm font-bold text-amber-950">Sample Answer Guidance</h3>
            </div>
            <p className="text-xs text-amber-900 leading-relaxed font-normal">
              {activeQuestion.sampleAnswerGuide}
            </p>
          </div>

          {/* Rubric Structure Card */}
          <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-3">
            <h3 className="text-sm font-bold text-slate-900">Recruiter Evaluation Rubric</h3>
            <div className="space-y-2">
              <p className="text-[11px] font-bold text-slate-500 uppercase">Key Evaluation Points:</p>
              <ul className="text-xs text-slate-700 space-y-1">
                {activeQuestion.evaluationRubric.keyPoints.map((kp, i) => (
                  <li key={i} className="flex items-start gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-amber-500 shrink-0 mt-1.5"></span>
                    <span>{kp}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="pt-3 border-t border-slate-100">
              <p className="text-[11px] font-bold text-slate-500 uppercase mb-1">
                Suggested Time Breakdown:
              </p>
              <p className="text-xs text-slate-600 leading-relaxed">
                {activeQuestion.evaluationRubric.suggestedStructure}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
