import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { ResumeData } from '../types';
import { evaluateResume } from '../utils/resumeScorer';
import {
  FileText,
  Calculator,
  MessageSquare,
  Code,
  CheckCircle2,
  AlertCircle,
  Download,
  Sparkles,
  Award,
  ChevronRight,
  Plus,
  Trash2,
  Printer,
} from 'lucide-react';
import confetti from 'canvas-confetti';

export const PlacementZoneView: React.FC = () => {
  const { resumeData, updateResumeData, currentUser } = useApp();
  const [activeTab, setActiveTab] = useState<'resume' | 'aptitude' | 'communication' | 'domain'>('resume');

  // Local resume state
  const [resume, setResume] = useState<ResumeData>(
    resumeData || {
      fullName: currentUser?.name || 'Aarav Sharma',
      email: currentUser?.email || 'student@careerwise.edu',
      phone: currentUser?.phone || '+91 98765 43210',
      linkedin: 'https://linkedin.com/in/student',
      githubOrPortfolio: 'https://github.com/student',
      summary: 'Dedicated student aiming to leverage strong core fundamentals in full-stack engineering and problem solving.',
      education: {
        degree: 'B.Sc Computer Science',
        department: 'Computer Science',
        college: 'National College of Engineering',
        year: '3rd Year',
        cgpa: '8.8 / 10',
      },
      skills: ['Python', 'SQL', 'React', 'TypeScript', 'Git', 'Data Structures'],
      projects: [
        {
          title: 'Campus Readiness & Placement Portal',
          technologies: 'React, Node.js, Express, PostgreSQL',
          description: 'Engineered a normalized database platform with automated placement readiness scoring and role-based access control.',
          link: 'https://github.com/student/portal',
        },
      ],
      experienceOrInternships: [
        {
          role: 'Full Stack Engineering Intern',
          company: 'Tech Solutions Inc.',
          duration: 'Summer 2025',
          details: 'Built REST APIs and optimized query indices, cutting response latencies by 25%.',
        },
      ],
      certifications: ['CareerWise Web Engineering Specialization'],
    }
  );

  const [savedSuccess, setSavedSuccess] = useState(false);

  // Aptitude test simulator state
  const [aptitudeScore, setAptitudeScore] = useState<number | null>(null);
  const [aptitudeAnswers, setAptitudeAnswers] = useState<Record<number, number>>({});

  const aptitudeQuestions = [
    {
      q: 'A train 240 m in length crosses a telegraph post in 16 seconds. What is the speed of the train in km/hr?',
      options: ['45 km/hr', '54 km/hr', '60 km/hr', '72 km/hr'],
      correct: 1,
      exp: 'Speed = 240/16 = 15 m/s. In km/hr: 15 * (18/5) = 54 km/hr.',
    },
    {
      q: 'In a code, "ROAD" is written as "URDG". How will "SWAN" be written in that code?',
      options: ['VZDQ', 'VXDO', 'VZDQ', 'UXDQ'],
      correct: 0,
      exp: 'Each letter is shifted +3 positions: R(+3)=U, O(+3)=R, A(+3)=D, D(+3)=G. S(+3)=V, W(+3)=Z, A(+3)=D, N(+3)=Q -> VZDQ.',
    },
    {
      q: 'Find the odd one out from the given group: 27, 64, 125, 144, 216',
      options: ['27', '64', '144', '216'],
      correct: 2,
      exp: '144 is 12^2 (not a perfect cube), whereas 27=3^3, 64=4^3, 125=5^3, 216=6^3.',
    },
  ];

  const handleAptitudeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    let correct = 0;
    aptitudeQuestions.forEach((q, idx) => {
      if (aptitudeAnswers[idx] === q.correct) correct++;
    });
    const scorePct = Math.round((correct / aptitudeQuestions.length) * 100);
    setAptitudeScore(scorePct);
    if (scorePct >= 70) {
      confetti({ particleCount: 70, spread: 50, origin: { y: 0.6 } });
    }
  };

  const resumeEval = evaluateResume(resume);

  const handleSaveResume = () => {
    updateResumeData(resume);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2000);
  };

  const handlePrintResume = () => {
    window.print();
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2">
              <span className="p-2 rounded-xl bg-blue-50 text-blue-600">
                <FileText className="w-6 h-6" />
              </span>
              <div>
                <h1 className="text-2xl font-extrabold text-slate-900">Placement Preparation Zone</h1>
                <p className="text-xs text-slate-500">
                  Comprehensive grooming across Resume Building, Aptitude, Communication, and Technical Rounds
                </p>
              </div>
            </div>
          </div>

          {/* Quick Tabs */}
          <div className="flex flex-wrap gap-2">
            {[
              { id: 'resume', label: 'Resume Builder & Score' },
              { id: 'aptitude', label: 'Aptitude Practice' },
              { id: 'communication', label: 'Communication & GD' },
              { id: 'domain', label: 'Domain Coding & Prep' },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all ${
                  activeTab === tab.id
                    ? 'bg-blue-600 text-white shadow-sm shadow-blue-500/20'
                    : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Tab 1: Resume Builder & Completeness Checklist */}
      {activeTab === 'resume' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left 2 Cols: Interactive Editor Form */}
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-6">
              <div className="flex items-center justify-between pb-4 border-b border-slate-100">
                <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                  <FileText className="w-5 h-5 text-blue-600" />
                  Structured Resume Editor
                </h2>
                <div className="flex items-center gap-2">
                  <button
                    onClick={handlePrintResume}
                    className="px-3 py-1.5 rounded-xl border border-slate-200 hover:bg-slate-50 text-slate-700 text-xs font-semibold flex items-center gap-1.5 transition-colors"
                  >
                    <Printer className="w-3.5 h-3.5" />
                    <span>Print / PDF</span>
                  </button>
                  <button
                    onClick={handleSaveResume}
                    className="px-4 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold transition-colors shadow-2xs"
                  >
                    {savedSuccess ? 'Saved! ✓' : 'Save Resume'}
                  </button>
                </div>
              </div>

              {/* Personal Info */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Full Legal Name</label>
                  <input
                    type="text"
                    value={resume.fullName}
                    onChange={(e) => setResume({ ...resume, fullName: e.target.value })}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Professional Email</label>
                  <input
                    type="email"
                    value={resume.email}
                    onChange={(e) => setResume({ ...resume, email: e.target.value })}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Phone Number</label>
                  <input
                    type="text"
                    value={resume.phone}
                    onChange={(e) => setResume({ ...resume, phone: e.target.value })}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">LinkedIn Profile</label>
                  <input
                    type="url"
                    value={resume.linkedin}
                    onChange={(e) => setResume({ ...resume, linkedin: e.target.value })}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>

              {/* Summary */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Professional Objective / Summary (Target 40+ words)
                </label>
                <textarea
                  rows={3}
                  value={resume.summary}
                  onChange={(e) => setResume({ ...resume, summary: e.target.value })}
                  className="w-full p-3 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              {/* Education */}
              <div className="pt-4 border-t border-slate-100">
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-3">Education</h3>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">Degree & Branch</label>
                    <input
                      type="text"
                      value={resume.education.degree}
                      onChange={(e) =>
                        setResume({
                          ...resume,
                          education: { ...resume.education, degree: e.target.value },
                        })
                      }
                      className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">College Name</label>
                    <input
                      type="text"
                      value={resume.education.college}
                      onChange={(e) =>
                        setResume({
                          ...resume,
                          education: { ...resume.education, college: e.target.value },
                        })
                      }
                      className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">Current CGPA</label>
                    <input
                      type="text"
                      value={resume.education.cgpa}
                      onChange={(e) =>
                        setResume({
                          ...resume,
                          education: { ...resume.education, cgpa: e.target.value },
                        })
                      }
                      className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                </div>
              </div>

              {/* Skills */}
              <div className="pt-4 border-t border-slate-100">
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-1">
                  Core Skills (Comma separated, at least 5)
                </label>
                <input
                  type="text"
                  value={resume.skills.join(', ')}
                  onChange={(e) =>
                    setResume({
                      ...resume,
                      skills: e.target.value.split(',').map((s) => s.trim()).filter(Boolean),
                    })
                  }
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              {/* Clean Resume Preview Document */}
              <div className="pt-6 border-t border-slate-100">
                <p className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-3">
                  Formatted Document Preview:
                </p>
                <div className="p-6 rounded-2xl bg-slate-50 border border-slate-200 text-slate-800 space-y-4 font-serif text-xs">
                  <div className="text-center pb-3 border-b border-slate-300">
                    <h3 className="text-lg font-bold text-slate-900 font-sans tracking-wide">
                      {resume.fullName || 'Candidate Name'}
                    </h3>
                    <p className="text-[11px] text-slate-600 font-sans mt-0.5">
                      {resume.email} • {resume.phone} • {resume.linkedin}
                    </p>
                  </div>

                  <div>
                    <h4 className="font-bold text-xs uppercase font-sans text-slate-900 tracking-wider border-b border-slate-200 pb-0.5 mb-1">
                      Professional Summary
                    </h4>
                    <p className="text-slate-700 leading-relaxed font-sans text-[11px]">{resume.summary}</p>
                  </div>

                  <div>
                    <h4 className="font-bold text-xs uppercase font-sans text-slate-900 tracking-wider border-b border-slate-200 pb-0.5 mb-1">
                      Education
                    </h4>
                    <p className="font-sans font-semibold text-slate-800 text-[11px]">
                      {resume.education.degree} — {resume.education.college} ({resume.education.cgpa})
                    </p>
                  </div>

                  <div>
                    <h4 className="font-bold text-xs uppercase font-sans text-slate-900 tracking-wider border-b border-slate-200 pb-0.5 mb-1">
                      Key Competencies
                    </h4>
                    <p className="font-sans text-[11px] text-slate-700">{resume.skills.join(' • ')}</p>
                  </div>

                  <div>
                    <h4 className="font-bold text-xs uppercase font-sans text-slate-900 tracking-wider border-b border-slate-200 pb-0.5 mb-1">
                      Practical Projects
                    </h4>
                    {resume.projects.map((p, i) => (
                      <div key={i} className="mb-2 font-sans text-[11px]">
                        <p className="font-bold text-slate-800">{p.title} ({p.technologies})</p>
                        <p className="text-slate-600 leading-relaxed">{p.description}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Right Col: Transparent Resume Completeness Score & Checklist */}
          <div className="space-y-6">
            <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-slate-900">Resume Completeness Score</h3>
                  <p className="text-xs text-slate-500">Based on transparent 10-point criteria</p>
                </div>
                <div className="text-right">
                  <span className="text-3xl font-black text-blue-700">{resumeEval.score}</span>
                  <span className="text-xs text-slate-400 font-bold">/100</span>
                </div>
              </div>

              <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                <div
                  className="bg-gradient-to-r from-blue-600 to-indigo-600 h-full rounded-full transition-all duration-300"
                  style={{ width: `${resumeEval.score}%` }}
                />
              </div>

              <p className="text-xs text-slate-600">
                {resumeEval.score >= 80
                  ? 'Excellent! Your resume satisfies corporate ATS formatting benchmarks.'
                  : 'Needs improvement. Complete remaining checklist items to ensure recruiters can assess your credentials.'}
              </p>

              {/* Checklist */}
              <div className="pt-4 border-t border-slate-100 space-y-2">
                <div className="flex items-center justify-between text-xs font-bold text-slate-600 mb-1">
                  <span>Audit Checklist</span>
                  <span>{resumeEval.checklistCompletedCount} / {resumeEval.totalChecklistCount} Complete</span>
                </div>

                <div className="space-y-2 max-h-96 overflow-y-auto pr-1">
                  {resumeEval.items.map((item) => (
                    <div
                      key={item.id}
                      className={`p-2.5 rounded-xl border text-xs flex items-start gap-2.5 ${
                        item.isComplete
                          ? 'bg-emerald-50/50 border-emerald-200 text-slate-700'
                          : 'bg-slate-50 border-slate-200 text-slate-500'
                      }`}
                    >
                      <CheckCircle2
                        className={`w-4 h-4 shrink-0 mt-0.5 ${
                          item.isComplete ? 'text-emerald-600' : 'text-slate-300'
                        }`}
                      />
                      <div>
                        <p className={`font-semibold ${item.isComplete ? 'text-slate-900' : 'text-slate-600'}`}>
                          {item.label} (+{item.weight} pts)
                        </p>
                        {!item.isComplete && (
                          <p className="text-[11px] text-rose-600 mt-0.5">{item.suggestion}</p>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Aptitude Practice */}
      {activeTab === 'aptitude' && (
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-6">
          <div className="flex items-center justify-between pb-4 border-b border-slate-100">
            <div>
              <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                <Calculator className="w-5 h-5 text-blue-600" />
                Aptitude & Reasoning Simulator
              </h2>
              <p className="text-xs text-slate-500">
                Quantitative aptitude, logical reasoning, and pattern recognition questions modeled after campus screening exams.
              </p>
            </div>
            {aptitudeScore !== null && (
              <span className="text-xs font-bold px-3 py-1 bg-blue-100 text-blue-800 rounded-full">
                Score: {aptitudeScore}%
              </span>
            )}
          </div>

          <form onSubmit={handleAptitudeSubmit} className="space-y-6">
            {aptitudeQuestions.map((q, qIndex) => {
              const selectedOpt = aptitudeAnswers[qIndex];
              const isSubmitted = aptitudeScore !== null;
              const isCorrect = selectedOpt === q.correct;

              return (
                <div key={qIndex} className="p-5 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
                  <div className="flex items-center justify-between">
                    <p className="text-xs font-bold text-slate-500">Question {qIndex + 1}</p>
                    {isSubmitted && (
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${isCorrect ? 'bg-emerald-600 text-white' : 'bg-rose-600 text-white'}`}>
                        {isCorrect ? 'Correct' : 'Incorrect'}
                      </span>
                    )}
                  </div>
                  <p className="text-sm font-semibold text-slate-900">{q.q}</p>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {q.options.map((opt, optIndex) => (
                      <button
                        key={optIndex}
                        type="button"
                        onClick={() => {
                          if (aptitudeScore === null) {
                            setAptitudeAnswers((prev) => ({ ...prev, [qIndex]: optIndex }));
                          }
                        }}
                        className={`p-3 text-left rounded-xl border text-xs transition-colors ${
                          selectedOpt === optIndex
                            ? 'bg-blue-600 text-white font-semibold border-blue-600'
                            : 'bg-white hover:bg-slate-100 border-slate-200 text-slate-800'
                        }`}
                      >
                        {opt}
                      </button>
                    ))}
                  </div>

                  {isSubmitted && (
                    <div className="p-3 bg-white rounded-xl border border-slate-200 text-xs text-slate-700">
                      <strong>Solution:</strong> {q.exp}
                    </div>
                  )}
                </div>
              );
            })}

            <button
              type="submit"
              disabled={Object.keys(aptitudeAnswers).length < aptitudeQuestions.length}
              className="px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white font-semibold text-xs transition-colors shadow-xs"
            >
              Submit & Check Aptitude Score
            </button>
          </form>
        </div>
      )}

      {/* Tab 3: Communication & Group Discussion */}
      {activeTab === 'communication' && (
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-6">
          <div>
            <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
              <MessageSquare className="w-5 h-5 text-indigo-600" />
              Communication & Group Discussion (GD) Masterclass
            </h2>
            <p className="text-xs text-slate-500">
              High-impact frameworks for group discussions, professional articulation, and corporate presentation.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="p-5 rounded-2xl bg-indigo-50/50 border border-indigo-100 space-y-2">
              <h3 className="text-sm font-bold text-indigo-950">1. Initiating the GD</h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Define the scope and frame the problem statement cleanly without being overly aggressive. Use phrases like:
                <em> "Let us examine this issue from three angles: economic impact, social feasibility, and technological readiness."</em>
              </p>
            </div>

            <div className="p-5 rounded-2xl bg-purple-50/50 border border-purple-100 space-y-2">
              <h3 className="text-sm font-bold text-purple-950">2. Polite Interventions</h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Build upon prior points rather than cutting speakers off.
                <em> "Adding to what Priya mentioned, we should also consider how this influences operating cash flow..."</em>
              </p>
            </div>

            <div className="p-5 rounded-2xl bg-emerald-50/50 border border-emerald-100 space-y-2">
              <h3 className="text-sm font-bold text-emerald-950">3. Synthesizing & Concluding</h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                When time is winding down, summarize convergent opinions and acknowledge lingering trade-offs. Recruiters value active listeners who moderate consensus.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Tab 4: Domain Coding & Prep */}
      {activeTab === 'domain' && (
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-6">
          <div>
            <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
              <Code className="w-5 h-5 text-blue-600" />
              Department Domain Practice Round
            </h2>
            <p className="text-xs text-slate-500">
              Targeted for {currentUser?.department ? currentUser.department.toUpperCase() : 'your enrolled department'}:
            </p>
          </div>

          <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
            <h3 className="text-sm font-bold text-slate-900">
              {currentUser?.department?.startsWith('bsc')
                ? 'Technical Coding Challenge: Two Sum & Hash Lookups'
                : 'Commerce/Business Case Study: Working Capital Liquidity Crunch'}
            </h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              {currentUser?.department?.startsWith('bsc')
                ? 'Given an array of integers nums and an integer target, return indices of the two numbers such that they add up to target in O(N) linear time using a Hash Map.'
                : 'Analyze a retail company facing rapid sales growth but negative operating cash flow. Diagnose why trade receivables are trapping liquid working capital.'}
            </p>
            <div className="p-3 bg-white rounded-xl border border-slate-200 text-xs font-mono text-slate-700">
              {currentUser?.department?.startsWith('bsc')
                ? 'def twoSum(nums: List[int], target: int) -> List[int]:\n    seen = {}\n    for i, num in enumerate(nums):\n        diff = target - num\n        if diff in seen:\n            return [seen[diff], i]\n        seen[num] = i'
                : 'Quick Ratio = (Cash + Marketable Securities + Receivables) / Current Liabilities\nCash Conversion Cycle (CCC) = DIO + DSO - DPO'}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
