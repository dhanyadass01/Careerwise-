import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { DepartmentId, AcademicYear, StudentSkillEntry, SkillLevel } from '../types';
import {
  GraduationCap,
  Sparkles,
  User,
  Building2,
  Calendar,
  Hash,
  Mail,
  Lock,
  Plus,
  Trash2,
  ArrowRight,
  CheckCircle2,
  Lightbulb,
  ShieldCheck,
  UserPlus,
  LogIn,
  AlertCircle,
} from 'lucide-react';
import { CartoonAvatar, CARTOON_AVATAR_OPTIONS, CartoonAvatarStyle } from './CartoonAvatar';

interface LoginPageProps {
  onSuccessNavigate?: (tab: string) => void;
  initialMode?: 'login' | 'register';
}

// Recommended quick-select skills per department
const DEPARTMENT_SKILL_SUGGESTIONS: Record<DepartmentId, { name: string; category: string }[]> = {
  bsc_cs: [
    { name: 'React', category: 'Frontend' },
    { name: 'TypeScript', category: 'Language' },
    { name: 'Node.js', category: 'Backend' },
    { name: 'Python', category: 'Language' },
    { name: 'SQL & PostgreSQL', category: 'Database' },
    { name: 'Tailwind CSS', category: 'Styling' },
    { name: 'Docker', category: 'DevOps' },
    { name: 'Data Structures & Algorithms', category: 'CS Fundamentals' },
  ],
  bcom: [
    { name: 'Advanced Excel', category: 'Spreadsheets' },
    { name: 'TallyPrime', category: 'Accounting ERP' },
    { name: 'Financial Accounting', category: 'Finance' },
    { name: 'GST & Corporate Taxation', category: 'Taxation' },
    { name: 'Auditing Practices', category: 'Audit' },
    { name: 'Financial Modeling', category: 'Valuation' },
    { name: 'Power BI', category: 'Analytics' },
    { name: 'Cost Accounting', category: 'Finance' },
  ],
  bba: [
    { name: 'Digital Marketing & SEO', category: 'Marketing' },
    { name: 'Business Analytics', category: 'Data Analysis' },
    { name: 'Financial Modeling', category: 'Finance' },
    { name: 'B2B Sales & Negotiation', category: 'Sales' },
    { name: 'Product Management', category: 'Product' },
    { name: 'Supply Chain Operations', category: 'Operations' },
    { name: 'Pitch Decks & Presentations', category: 'Communication' },
    { name: 'Market Research', category: 'Strategy' },
  ],
  bsc_aiml: [
    { name: 'Python', category: 'Language' },
    { name: 'Machine Learning (Scikit-Learn)', category: 'AI/ML' },
    { name: 'Pandas & NumPy', category: 'Data Science' },
    { name: 'Deep Learning (PyTorch)', category: 'Deep Learning' },
    { name: 'SQL & Data Warehousing', category: 'Data Engineering' },
    { name: 'FastAPI / Flask', category: 'API Serving' },
    { name: 'Data Visualization (Matplotlib)', category: 'Analytics' },
    { name: 'Natural Language Processing', category: 'AI/ML' },
  ],
  bsc_it: [
    { name: 'JavaScript & React', category: 'Frontend' },
    { name: 'Java & Spring Boot', category: 'Backend' },
    { name: 'Cloud Computing (AWS)', category: 'Cloud' },
    { name: 'SQL & MySQL', category: 'Database' },
    { name: 'Linux System Administration', category: 'SysAdmin' },
    { name: 'Computer Networking', category: 'Infrastructure' },
    { name: 'Cybersecurity Fundamentals', category: 'Security' },
    { name: 'Git & GitHub', category: 'DevOps' },
  ],
};

export const LoginPage: React.FC<LoginPageProps> = ({ onSuccessNavigate, initialMode = 'register' }) => {
  const { loginWithSkills, login, departments, users } = useApp();

  const [authMode, setAuthMode] = useState<'login' | 'register'>(initialMode);

  // Login form state
  const [loginIdentifier, setLoginIdentifier] = useState('');
  const [loginPassword, setLoginPassword] = useState('');

  // Register form state
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [department, setDepartment] = useState<DepartmentId>('bsc_cs');
  const [year, setYear] = useState<AcademicYear>('3rd Year');
  const [registerNumber, setRegisterNumber] = useState('');
  const [selectedAvatarId, setSelectedAvatarId] = useState<CartoonAvatarStyle>('coder-headphones');

  // Skills state for new user
  const [enteredSkills, setEnteredSkills] = useState<StudentSkillEntry[]>([
    { name: 'React', proficiency: 'Intermediate', skillName: 'React', level: 'Intermediate', category: 'Frontend' },
    { name: 'TypeScript', proficiency: 'Beginner', skillName: 'TypeScript', level: 'Beginner', category: 'Frontend' },
  ]);

  // New skill input
  const [customSkillName, setCustomSkillName] = useState('');
  const [customSkillLevel, setCustomSkillLevel] = useState<SkillLevel>('Intermediate');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Quick department suggestions
  const deptSuggestions = DEPARTMENT_SKILL_SUGGESTIONS[department] || DEPARTMENT_SKILL_SUGGESTIONS.bsc_cs;

  // Add custom skill
  const handleAddSkill = (skillNameToAdd?: string, defaultCat?: string) => {
    const targetName = (skillNameToAdd || customSkillName).trim();
    if (!targetName) return;

    if (
      enteredSkills.some(
        (s) => (s.name || s.skillName || '').toLowerCase() === targetName.toLowerCase()
      )
    ) {
      setErrorMsg(`Skill "${targetName}" is already in your skills list.`);
      return;
    }

    const newSkill: StudentSkillEntry = {
      name: targetName,
      proficiency: customSkillLevel,
      skillName: targetName,
      level: customSkillLevel,
      category: defaultCat || 'Custom Skill',
    };

    setEnteredSkills((prev) => [...prev, newSkill]);
    setCustomSkillName('');
    setErrorMsg(null);
  };

  // Remove skill
  const handleRemoveSkill = (skillNameToRemove: string) => {
    setEnteredSkills((prev) =>
      prev.filter((s) => (s.name || s.skillName) !== skillNameToRemove)
    );
  };

  // Toggle level
  const handleCycleLevel = (skillName: string) => {
    setEnteredSkills((prev) =>
      prev.map((s) => {
        const curName = s.name || s.skillName;
        if (curName !== skillName) return s;
        const curLevel = s.proficiency || s.level || 'Intermediate';
        const nextLevel: SkillLevel =
          curLevel === 'Beginner' ? 'Intermediate' : curLevel === 'Intermediate' ? 'Advanced' : 'Beginner';
        return { ...s, proficiency: nextLevel, level: nextLevel };
      })
    );
  };

  // Handle department change
  const handleDepartmentChange = (newDept: DepartmentId) => {
    setDepartment(newDept);
    const suggestions = DEPARTMENT_SKILL_SUGGESTIONS[newDept] || [];
    if (suggestions.length >= 2) {
      setEnteredSkills([
        {
          name: suggestions[0].name,
          proficiency: 'Intermediate',
          skillName: suggestions[0].name,
          level: 'Intermediate',
          category: suggestions[0].category,
        },
        {
          name: suggestions[1].name,
          proficiency: 'Beginner',
          skillName: suggestions[1].name,
          level: 'Beginner',
          category: suggestions[1].category,
        },
      ]);
    }
  };

  // Handle Existing User Login
  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);

    if (!loginIdentifier.trim()) {
      setErrorMsg('Please enter your email or register number.');
      return;
    }

    setIsSubmitting(true);
    const res = login(loginIdentifier.trim(), loginPassword);
    setIsSubmitting(false);

    if (res.success) {
      setSuccessMsg('Login successful! Launching your learning dashboard...');
      setTimeout(() => {
        if (onSuccessNavigate) {
          onSuccessNavigate('dashboard');
        }
      }, 500);
    } else {
      setErrorMsg(res.error || 'User not found. Please create an account.');
    }
  };

  // Handle New User Account Creation
  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);

    if (!name.trim()) {
      setErrorMsg('Please enter your full name.');
      return;
    }

    if (!email.trim() || !email.includes('@')) {
      setErrorMsg('Please enter a valid email address.');
      return;
    }

    if (!password || password.length < 6) {
      setErrorMsg('Please provide a password with at least 6 characters.');
      return;
    }

    if (enteredSkills.length === 0) {
      setErrorMsg('Please select or enter at least 1 known skill to generate your customized plan.');
      return;
    }

    setIsSubmitting(true);

    try {
      const res = loginWithSkills({
        name: name.trim(),
        department,
        year,
        skills: enteredSkills,
        email: email.trim(),
        registerNumber: registerNumber.trim() || undefined,
        avatar: selectedAvatarId,
      });

      if (res.success) {
        setIsSubmitting(false);
        setSuccessMsg(`Welcome ${name.trim()}! Your tailored skill architecture is ready.`);
        setTimeout(() => {
          if (onSuccessNavigate) {
            onSuccessNavigate('custom-plan');
          }
        }, 500);
      }
    } catch {
      setIsSubmitting(false);
      setErrorMsg('An error occurred during account creation. Please try again.');
    }
  };

  return (
    <div className="min-h-[85vh] py-10 px-4 sm:px-6 lg:px-8 max-w-4xl mx-auto space-y-8 animate-in fade-in duration-300">
      {/* Header section */}
      <div className="text-center space-y-3">
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-blue-100 text-blue-700 text-xs font-semibold uppercase tracking-wider shadow-xs">
          <GraduationCap className="w-4 h-4 text-blue-600" />
          <span>Student Access Portal</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
          {authMode === 'register' ? 'Create Your Student Account' : 'Log In to CareerWise'}
        </h1>
        <p className="max-w-2xl mx-auto text-sm sm:text-base text-slate-600">
          {authMode === 'register'
            ? 'Enter your academic credentials and your current known skills. Our recommendation engine will generate distinctive project ideas, priority tasks, and skill suggestions tailored to you.'
            : 'Enter your registered email address or college register number to resume your personalized placement roadmap.'}
        </p>

        {/* Tab Switcher */}
        <div className="flex justify-center pt-2">
          <div className="inline-flex p-1 rounded-2xl bg-slate-200/80 border border-slate-300">
            <button
              type="button"
              onClick={() => {
                setAuthMode('register');
                setErrorMsg(null);
              }}
              className={`px-5 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all flex items-center gap-2 ${
                authMode === 'register'
                  ? 'bg-white text-blue-700 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <UserPlus className="w-4 h-4" />
              <span>Create Account</span>
            </button>
            <button
              type="button"
              onClick={() => {
                setAuthMode('login');
                setErrorMsg(null);
              }}
              className={`px-5 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all flex items-center gap-2 ${
                authMode === 'login'
                  ? 'bg-white text-blue-700 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <LogIn className="w-4 h-4" />
              <span>Log In</span>
            </button>
          </div>
        </div>
      </div>

      {/* Global Alerts */}
      {errorMsg && (
        <div className="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-semibold flex items-center gap-2.5 animate-in fade-in duration-200">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{errorMsg}</span>
        </div>
      )}

      {successMsg && (
        <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-700 text-xs font-semibold flex items-center gap-2.5 animate-in fade-in duration-200">
          <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600" />
          <span>{successMsg}</span>
        </div>
      )}

      {/* MODE 1: LOG IN FORM */}
      {authMode === 'login' ? (
        <div className="bg-white rounded-3xl shadow-xl border border-slate-200 p-6 sm:p-10 max-w-xl mx-auto space-y-6">
          <div className="flex flex-col items-center justify-center text-center gap-2 pt-1">
            <CartoonAvatar name={loginIdentifier || 'Student'} size="xl" />
            <div>
              <h3 className="text-base font-bold text-slate-800">Welcome Back!</h3>
              <p className="text-xs text-slate-500">Sign in with your registered college details</p>
            </div>
          </div>

          <form onSubmit={handleLoginSubmit} className="space-y-5">
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-700 flex items-center gap-1.5">
                <Mail className="w-4 h-4 text-blue-600" />
                <span>Email Address or Register Number</span>
                <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                required
                value={loginIdentifier}
                onChange={(e) => setLoginIdentifier(e.target.value)}
                placeholder="e.g. rahul@ncet.edu or 24CS101"
                className="w-full px-4 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm font-medium text-slate-900 placeholder:text-slate-400"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-700 flex items-center gap-1.5">
                <Lock className="w-4 h-4 text-blue-600" />
                <span>Password</span>
                <span className="text-rose-500">*</span>
              </label>
              <input
                type="password"
                required
                value={loginPassword}
                onChange={(e) => setLoginPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full px-4 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm font-medium text-slate-900 placeholder:text-slate-400"
              />
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-bold text-sm shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-2 disabled:opacity-50"
            >
              <LogIn className="w-4 h-4" />
              <span>{isSubmitting ? 'Verifying...' : 'Log In to Account'}</span>
            </button>
          </form>

          {users.length === 0 && (
            <div className="p-4 rounded-xl bg-blue-50/70 border border-blue-200 text-center space-y-2">
              <p className="text-xs text-blue-800 font-medium">
                No registered accounts found yet.
              </p>
              <button
                type="button"
                onClick={() => setAuthMode('register')}
                className="text-xs font-bold text-blue-700 hover:underline inline-flex items-center gap-1"
              >
                <span>Click here to Create Account</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          )}

          <div className="text-center pt-2 border-t border-slate-100">
            <p className="text-xs text-slate-500">
              Don't have an account yet?{' '}
              <button
                type="button"
                onClick={() => setAuthMode('register')}
                className="font-bold text-blue-600 hover:underline"
              >
                Create Account & Start Learning
              </button>
            </p>
          </div>
        </div>
      ) : (
        /* MODE 2: CREATE ACCOUNT FORM */
        <form
          onSubmit={handleRegisterSubmit}
          className="bg-white rounded-3xl shadow-xl border border-slate-200 overflow-hidden divide-y divide-slate-100"
        >
          {/* Section 1: Academic Identity */}
          <div className="p-6 sm:p-8 space-y-6">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center font-bold">
                1
              </div>
              <div>
                <h2 className="text-lg font-bold text-slate-900">Student & Academic Profile</h2>
                <p className="text-xs text-slate-500">
                  Select your department stream and current year so the curriculum aligns with your college goals.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              {/* Student Name */}
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-700 flex items-center gap-1.5">
                  <User className="w-3.5 h-3.5 text-blue-600" />
                  <span>Full Name</span>
                  <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Ramesh Kumar, Priya Sen..."
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm font-medium text-slate-900 placeholder:text-slate-400"
                />
              </div>

              {/* Email */}
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-700 flex items-center gap-1.5">
                  <Mail className="w-3.5 h-3.5 text-blue-600" />
                  <span>Email Address</span>
                  <span className="text-rose-500">*</span>
                </label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="student@college.edu"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm font-medium text-slate-900 placeholder:text-slate-400"
                />
              </div>

              {/* Password */}
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-700 flex items-center gap-1.5">
                  <Lock className="w-3.5 h-3.5 text-blue-600" />
                  <span>Account Password</span>
                  <span className="text-rose-500">*</span>
                </label>
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Min 6 characters"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm font-medium text-slate-900 placeholder:text-slate-400"
                />
              </div>

              {/* Register / Roll Number */}
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-700 flex items-center gap-1.5">
                  <Hash className="w-3.5 h-3.5 text-slate-500" />
                  <span>College Register / Roll Number</span>
                  <span className="text-slate-400 text-[10px]">(Optional)</span>
                </label>
                <input
                  type="text"
                  value={registerNumber}
                  onChange={(e) => setRegisterNumber(e.target.value)}
                  placeholder="e.g. 24CS108 or NCET-449"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm font-medium text-slate-900 placeholder:text-slate-400"
                />
              </div>

              {/* Department */}
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-700 flex items-center gap-1.5">
                  <Building2 className="w-3.5 h-3.5 text-blue-600" />
                  <span>Department (Stream)</span>
                  <span className="text-rose-500">*</span>
                </label>
                <select
                  value={department}
                  onChange={(e) => handleDepartmentChange(e.target.value as DepartmentId)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm font-medium text-slate-900 bg-white"
                >
                  {departments.map((dept) => (
                    <option key={dept.id} value={dept.id}>
                      {dept.name} ({dept.shortName})
                    </option>
                  ))}
                </select>
              </div>

              {/* Academic Year */}
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-700 flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5 text-blue-600" />
                  <span>Academic Year</span>
                  <span className="text-rose-500">*</span>
                </label>
                <select
                  value={year}
                  onChange={(e) => setYear(e.target.value as AcademicYear)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm font-medium text-slate-900 bg-white"
                >
                  <option value="1st Year">1st Year (Foundations & Basics)</option>
                  <option value="2nd Year">2nd Year (Core Competencies & Intermediate)</option>
                  <option value="3rd Year">3rd Year (Placement & Capstone Ready)</option>
                </select>
              </div>
            </div>

            {/* Cartoon Avatar Picker */}
            <div className="pt-5 border-t border-slate-100 space-y-3">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div>
                  <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5 uppercase tracking-wide">
                    <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                    <span>Choose Your Cartoon Avatar</span>
                  </label>
                  <p className="text-[11px] text-slate-500">Pick an illustrated character for your student profile, badges & portfolio</p>
                </div>
                <div className="flex items-center gap-2 self-start sm:self-auto">
                  <span className="text-xs text-slate-500 hidden sm:inline">Selected:</span>
                  <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-blue-50 border border-blue-200">
                    <CartoonAvatar avatarId={selectedAvatarId} name={name || 'Student'} size="xs" />
                    <span className="text-xs font-bold text-blue-700">
                      {CARTOON_AVATAR_OPTIONS.find((o) => o.id === selectedAvatarId)?.name}
                    </span>
                    <span className="text-[10px] text-blue-500 font-medium hidden xs:inline">
                      ({CARTOON_AVATAR_OPTIONS.find((o) => o.id === selectedAvatarId)?.badge})
                    </span>
                  </div>
                </div>
              </div>

              {/* Grid of Cartoon Avatars */}
              <div className="grid grid-cols-4 sm:grid-cols-8 gap-2.5">
                {CARTOON_AVATAR_OPTIONS.map((opt) => {
                  const isSelected = selectedAvatarId === opt.id;
                  return (
                    <button
                      key={opt.id}
                      type="button"
                      onClick={() => setSelectedAvatarId(opt.id)}
                      title={`${opt.name} - ${opt.description}`}
                      className={`relative flex flex-col items-center p-2 rounded-2xl border-2 transition-all ${
                        isSelected
                          ? 'border-blue-600 bg-blue-50/80 shadow-md ring-2 ring-blue-500/20 scale-105'
                          : 'border-slate-200 hover:border-slate-300 bg-white hover:bg-slate-50/80'
                      }`}
                    >
                      {isSelected && (
                        <div className="absolute -top-1.5 -right-1.5 w-4 h-4 rounded-full bg-blue-600 text-white flex items-center justify-center text-[10px] font-bold shadow-xs">
                          ✓
                        </div>
                      )}
                      <CartoonAvatar avatarId={opt.id} size="md" />
                      <span className="text-[11px] font-bold text-slate-800 mt-1.5 truncate max-w-full">
                        {opt.name}
                      </span>
                      <span className="text-[9px] text-slate-500 truncate max-w-full">
                        {opt.badge}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Section 2: Skill Assessment & Entry Form */}
          <div className="p-6 sm:p-8 space-y-6 bg-slate-50/50">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold">
                  2
                </div>
                <div>
                  <h2 className="text-lg font-bold text-slate-900">Your Current Skills & Knowledge</h2>
                  <p className="text-xs text-slate-500">
                    Add tools, programming languages, software, or concepts you currently know.
                  </p>
                </div>
              </div>
              <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-indigo-100 text-indigo-700">
                {enteredSkills.length} skills added
              </span>
            </div>

            {/* Quick-add suggestions for selected department */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-slate-600 uppercase tracking-wider flex items-center gap-1.5">
                  <Lightbulb className="w-3.5 h-3.5 text-amber-500" />
                  <span>Suggested Skills for {departments.find((d) => d.id === department)?.name}:</span>
                </label>
                <span className="text-[11px] text-slate-400">Click to add with 1 click</span>
              </div>
              <div className="flex flex-wrap gap-2">
                {deptSuggestions.map((item) => {
                  const isAlreadyAdded = enteredSkills.some(
                    (s) => (s.name || s.skillName || '').toLowerCase() === item.name.toLowerCase()
                  );
                  return (
                    <button
                      key={item.name}
                      type="button"
                      onClick={() => {
                        if (isAlreadyAdded) {
                          handleRemoveSkill(item.name);
                        } else {
                          handleAddSkill(item.name, item.category);
                        }
                      }}
                      className={`text-xs px-3 py-1.5 rounded-lg font-medium transition-all flex items-center gap-1.5 ${
                        isAlreadyAdded
                          ? 'bg-indigo-600 text-white shadow-xs'
                          : 'bg-white hover:bg-indigo-50 border border-slate-200 text-slate-700 hover:border-indigo-300'
                      }`}
                    >
                      <span>{item.name}</span>
                      {isAlreadyAdded ? (
                        <CheckCircle2 className="w-3.5 h-3.5 text-white" />
                      ) : (
                        <Plus className="w-3 h-3 text-slate-400" />
                      )}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Custom Skill Input Form */}
            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-3">
              <label className="text-xs font-semibold text-slate-700 block">
                Add Any Other Skill, Tool, Framework or Concept:
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-12 gap-2.5">
                <div className="sm:col-span-6">
                  <input
                    type="text"
                    value={customSkillName}
                    onChange={(e) => setCustomSkillName(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        handleAddSkill();
                      }
                    }}
                    placeholder="e.g. PostgreSQL, Excel, Figma, Flutter, PyTorch, Docker..."
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm font-medium text-slate-900 placeholder:text-slate-400"
                  />
                </div>

                <div className="sm:col-span-4">
                  <select
                    value={customSkillLevel}
                    onChange={(e) => setCustomSkillLevel(e.target.value as SkillLevel)}
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm font-medium text-slate-900 bg-white"
                  >
                    <option value="Beginner">Level: Beginner (Basics & syntax)</option>
                    <option value="Intermediate">Level: Intermediate (Built small projects)</option>
                    <option value="Advanced">Level: Advanced (Production & in-depth)</option>
                  </select>
                </div>

                <div className="sm:col-span-2">
                  <button
                    type="button"
                    onClick={() => handleAddSkill()}
                    className="w-full h-full py-2 px-3 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add</span>
                  </button>
                </div>
              </div>
            </div>

            {/* Active Skills List Chips */}
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs text-slate-600">
                <span className="font-semibold">Your Selected Skills (click level badge to cycle proficiency):</span>
                <span className="text-[11px] text-slate-400">Total: {enteredSkills.length}</span>
              </div>

              {enteredSkills.length === 0 ? (
                <div className="text-center py-6 border-2 border-dashed border-slate-200 rounded-2xl bg-white text-slate-500 text-xs">
                  No skills entered yet. Click the recommended chips above or type a skill to add.
                </div>
              ) : (
                <div className="flex flex-wrap gap-2.5">
                  {enteredSkills.map((sk) => {
                    const skillDisplayName = sk.name || sk.skillName || '';
                    const levelBadgeStyle =
                      sk.level === 'Advanced'
                        ? 'bg-purple-100 text-purple-700 border-purple-200'
                        : sk.level === 'Intermediate'
                        ? 'bg-blue-100 text-blue-700 border-blue-200'
                        : 'bg-emerald-100 text-emerald-700 border-emerald-200';

                    return (
                      <div
                        key={skillDisplayName}
                        className="bg-white pl-3 pr-2 py-1.5 rounded-xl border border-slate-200 shadow-xs flex items-center gap-2 text-xs font-semibold text-slate-800 hover:border-slate-300 transition-colors"
                      >
                        <span>{skillDisplayName}</span>
                        <button
                          type="button"
                          onClick={() => handleCycleLevel(skillDisplayName)}
                          title="Click to toggle level (Beginner / Intermediate / Advanced)"
                          className={`text-[10px] px-2 py-0.5 rounded-md font-bold border transition-colors ${levelBadgeStyle}`}
                        >
                          {sk.level}
                        </button>
                        <button
                          type="button"
                          onClick={() => handleRemoveSkill(skillDisplayName)}
                          className="text-slate-400 hover:text-rose-500 p-0.5 rounded-md transition-colors"
                          title="Remove skill"
                        >
                          <Trash2 className="w-3 h-3" />
                        </button>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>

          {/* Section 3: Summary & Submission */}
          <div className="p-6 sm:p-8 bg-white space-y-5">
            <div className="p-4 rounded-2xl bg-gradient-to-r from-blue-50 via-indigo-50 to-purple-50 border border-blue-100 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="space-y-1">
                <div className="text-xs font-bold text-slate-900 flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-blue-600" />
                  <span>Real-Time Plan Personalization Engine</span>
                </div>
                <p className="text-xs text-slate-600">
                  Creating your account with these {enteredSkills.length} skills will immediately calibrate customized project
                  architectures, prioritized tasks, and bridging suggestions for{' '}
                  <strong className="text-slate-800">{name || 'your profile'}</strong>.
                </p>
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="px-6 py-3 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-bold text-sm shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-2 whitespace-nowrap disabled:opacity-50"
              >
                <span>{isSubmitting ? 'Analyzing & Personalizing...' : 'Create Account & Start Learning'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>

            <div className="text-center">
              <p className="text-xs text-slate-500">
                Already have an account?{' '}
                <button
                  type="button"
                  onClick={() => setAuthMode('login')}
                  className="font-bold text-blue-600 hover:underline"
                >
                  Log In here
                </button>
              </p>
            </div>
          </div>
        </form>
      )}
    </div>
  );
};
