import React from 'react';
import { useApp } from '../context/AppContext';
import {
  GraduationCap,
  Sparkles,
  Target,
  ArrowRight,
  TrendingUp,
  Award,
  BookOpen,
  FolderKanban,
  CheckCircle2,
  AlertTriangle,
  FileCheck2,
  Clock,
  ChevronRight,
  HelpCircle,
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
} from 'recharts';

interface StudentDashboardProps {
  onNavigate: (tab: string, contextId?: string) => void;
}

export const StudentDashboard: React.FC<StudentDashboardProps> = ({ onNavigate }) => {
  const {
    currentUser,
    readinessResult,
    skills,
    progressMap,
    careerMissions,
    projectSubmissions,
    projects,
    departments,
    certificates,
    customSkillPlan,
    completedCustomTaskIds,
    toggleCustomTask,
  } = useApp();

  if (!currentUser) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-20 text-center space-y-6">
        <div className="w-16 h-16 rounded-2xl bg-blue-100 text-blue-600 flex items-center justify-center mx-auto shadow-sm">
          <GraduationCap className="w-8 h-8" />
        </div>
        <div className="space-y-2">
          <h2 className="text-2xl font-extrabold text-slate-900">Student Placement Dashboard</h2>
          <p className="text-sm text-slate-600 leading-relaxed max-w-md mx-auto">
            Please log in or create your student account to access your personalized placement readiness radar, skill completion tracker, and verified milestones.
          </p>
        </div>
        <div className="flex justify-center gap-3 pt-2">
          <button
            onClick={() => onNavigate('login')}
            className="px-6 py-3 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-bold text-sm shadow-md transition-all inline-flex items-center gap-2"
          >
            <Sparkles className="w-4 h-4 text-amber-300" />
            <span>Start Learning & Register</span>
          </button>
        </div>
      </div>
    );
  }

  const currentDept = departments.find((d) => d.id === currentUser.department);
  const deptSkills = skills.filter((s) => s.departmentId === currentUser.department);

  // In-progress or continue learning skills
  const continueLearningSkills = deptSkills.slice(0, 3);

  // Active mission
  const activeMission = careerMissions.find((m) => m.departmentId === currentUser.department) || careerMissions[0];

  // Component readiness radar/bar data
  const readinessChartData = [
    { subject: 'Skills (25%)', score: readinessResult.components.skillCompletion.score, fullMark: 100 },
    { subject: 'Assess (20%)', score: readinessResult.components.assessmentScore.score, fullMark: 100 },
    { subject: 'Projects (20%)', score: readinessResult.components.projectScore.score, fullMark: 100 },
    { subject: 'Aptitude (15%)', score: readinessResult.components.aptitudeScore.score, fullMark: 100 },
    { subject: 'Comm (10%)', score: readinessResult.components.communicationScore.score, fullMark: 100 },
    { subject: 'Resume (5%)', score: readinessResult.components.resumeScore.score, fullMark: 100 },
    { subject: 'Interview (5%)', score: readinessResult.components.interviewScore.score, fullMark: 100 },
  ];

  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-emerald-600 bg-emerald-50 border-emerald-200';
    if (score >= 60) return 'text-blue-600 bg-blue-50 border-blue-200';
    if (score >= 40) return 'text-amber-600 bg-amber-50 border-amber-200';
    return 'text-rose-600 bg-rose-50 border-rose-200';
  };

  const approvedProjectsCount = projectSubmissions.filter(
    (s) => s.studentId === currentUser.id && s.status === 'Approved'
  ).length;

  const userCertificatesCount = certificates.filter(
    (c) =>
      c.studentId === currentUser.id ||
      (Boolean(currentUser.name) && c.studentName?.toLowerCase() === currentUser.name.toLowerCase())
  ).length;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Welcome Banner */}
      <div className="bg-gradient-to-r from-blue-700 via-indigo-700 to-purple-800 rounded-3xl p-6 sm:p-8 text-white shadow-xl relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="flex flex-wrap items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full bg-white/20 backdrop-blur text-xs font-semibold uppercase tracking-wider">
                {currentDept?.name || 'Department Stream'}
              </span>
              <span className="px-2.5 py-0.5 rounded-full bg-blue-500/40 text-xs font-medium">
                {currentUser.year || '3rd Year'}
              </span>
              {currentUser.registerNumber && (
                <span className="text-xs text-blue-200 font-mono">
                  Reg: {currentUser.registerNumber}
                </span>
              )}
            </div>

            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
              Welcome back, {currentUser.name}! 👋
            </h1>

            <p className="text-xs sm:text-sm text-blue-100 font-normal leading-relaxed">
              Your academic roadmap is configured for{' '}
              <strong className="text-white">{currentDept?.shortName}</strong>. Focus on closing
              flagged skill gaps and completing practical capstone projects to maximize campus placement readiness.
            </p>

            {currentUser.careerInterests && currentUser.careerInterests.length > 0 && (
              <div className="flex flex-wrap items-center gap-1.5 pt-1">
                <span className="text-[11px] text-blue-200">Target Interests:</span>
                {currentUser.careerInterests.map((interest, i) => (
                  <span
                    key={i}
                    className="text-[11px] px-2 py-0.5 rounded-md bg-white/15 text-white font-medium"
                  >
                    {interest}
                  </span>
                ))}
              </div>
            )}
          </div>

          {/* Quick Metrics Pills */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 shrink-0">
            <div className="bg-white/10 backdrop-blur rounded-2xl p-3 border border-white/10 text-center">
              <p className="text-2xl font-black text-white">{readinessResult.overallScore}%</p>
              <p className="text-[10px] text-blue-200 uppercase font-semibold">Placement Score</p>
            </div>
            <div className="bg-white/10 backdrop-blur rounded-2xl p-3 border border-white/10 text-center">
              <p className="text-2xl font-black text-white">{approvedProjectsCount}</p>
              <p className="text-[10px] text-blue-200 uppercase font-semibold">Approved Projects</p>
            </div>
            <div className="bg-white/10 backdrop-blur rounded-2xl p-3 border border-white/10 text-center col-span-2 sm:col-span-1">
              <p className="text-2xl font-black text-white">{userCertificatesCount}</p>
              <p className="text-[10px] text-blue-200 uppercase font-semibold">Certificates</p>
            </div>
          </div>
        </div>
      </div>

      {/* Tailored Skill Architecture & Custom Tasks Card */}
      {customSkillPlan && (
        <div className="bg-gradient-to-r from-slate-900 to-indigo-950 rounded-3xl p-6 sm:p-7 text-white shadow-lg border border-slate-800 space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <span className="p-1.5 rounded-lg bg-blue-500/20 text-blue-300">
                  <Sparkles className="w-4 h-4 text-blue-400" />
                </span>
                <span className="text-xs font-bold uppercase tracking-wider text-blue-300">
                  Tailored To Your Evaluated Skills ({currentUser.enteredSkills?.length || 0})
                </span>
              </div>
              <h2 className="text-xl font-extrabold text-white">Your Custom Projects & Priority Tasks</h2>
              <p className="text-xs text-slate-300 max-w-2xl">{customSkillPlan.summary}</p>
            </div>

            <div className="flex items-center gap-2.5 shrink-0">
              <button
                onClick={() => onNavigate('login')}
                className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-200 border border-slate-700 transition-colors"
              >
                Re-assess Skills
              </button>
              <button
                onClick={() => onNavigate('custom-plan')}
                className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-xs font-bold text-white transition-all shadow-md flex items-center gap-1.5"
              >
                <span>View Full Plan</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-1">
            {/* Top Project Preview */}
            {customSkillPlan.projectIdeas[0] && (
              <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="px-2 py-0.5 rounded bg-blue-500/20 text-blue-300 font-semibold text-[10px]">
                    TOP RECOMMENDED PROJECT
                  </span>
                  <span className="text-slate-400 text-[11px]">
                    {customSkillPlan.projectIdeas[0].estimatedTime}
                  </span>
                </div>
                <h3 className="text-sm font-bold text-white">
                  {customSkillPlan.projectIdeas[0].title}
                </h3>
                <p className="text-xs text-slate-300 line-clamp-2">
                  {customSkillPlan.projectIdeas[0].description}
                </p>
                <div className="text-[11px] text-blue-200 bg-blue-950/40 p-2 rounded-lg border border-blue-800/50">
                  <span className="font-semibold text-blue-300">Why for your skills: </span>
                  {customSkillPlan.projectIdeas[0].whyThisProject}
                </div>
              </div>
            )}

            {/* Top 2 Tasks Preview with direct toggle */}
            <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-2.5">
              <div className="flex items-center justify-between text-xs">
                <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-semibold text-[10px]">
                  PRIORITY ACTIONABLE TASKS
                </span>
                <span className="text-slate-400 text-[11px]">
                  {customSkillPlan.customTasks.filter((t) => completedCustomTaskIds.includes(t.id)).length} of{' '}
                  {customSkillPlan.customTasks.length} done
                </span>
              </div>

              <div className="space-y-2">
                {customSkillPlan.customTasks.slice(0, 2).map((task) => {
                  const isDone = completedCustomTaskIds.includes(task.id);
                  return (
                    <div
                      key={task.id}
                      onClick={() => toggleCustomTask(task.id)}
                      className={`p-2.5 rounded-xl border text-xs cursor-pointer flex items-start gap-2.5 transition-all ${
                        isDone
                          ? 'bg-slate-800/40 border-slate-700/50 text-slate-400 line-through'
                          : 'bg-white/10 border-white/15 text-white hover:bg-white/15'
                      }`}
                    >
                      <CheckCircle2
                        className={`w-4 h-4 shrink-0 mt-0.5 ${
                          isDone ? 'text-emerald-400' : 'text-slate-400'
                        }`}
                      />
                      <div className="flex-1">
                        <div className="font-semibold">{task.title}</div>
                        <div className="text-[10px] text-slate-300 font-normal line-clamp-1">
                          {task.actionableOutcome}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Placement Readiness Hero Card */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs">
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6 pb-6 border-b border-slate-100">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <TrendingUp className="w-5 h-5 text-blue-600" />
              <h2 className="text-xl font-bold text-slate-900">Placement Readiness Index</h2>
              <span className={`text-xs px-2.5 py-1 rounded-full font-bold border ${getScoreColor(readinessResult.overallScore)}`}>
                {readinessResult.category}
              </span>
            </div>
            <p className="text-xs text-slate-500 max-w-2xl leading-relaxed">
              Calculated using the official transparent CareerWise formula:
              <br className="hidden sm:inline" />
              <code className="text-slate-700 font-mono text-[11px] bg-slate-100 px-1 py-0.5 rounded">
                (Skills×0.25) + (Assessments×0.20) + (Projects×0.20) + (Aptitude×0.15) + (Comm×0.10) + (Resume×0.05) + (Interview×0.05)
              </code>
            </p>
          </div>

          <div className="flex items-center gap-4 bg-slate-50 p-4 rounded-2xl border border-slate-200/80">
            <div className="text-center">
              <span className="text-3xl font-black text-slate-900">{readinessResult.overallScore}</span>
              <span className="text-sm text-slate-500 font-semibold">/100</span>
              <p className="text-[10px] uppercase font-bold text-slate-500">Readiness Score</p>
            </div>
            <div className="h-10 w-px bg-slate-200"></div>
            <button
              onClick={() => onNavigate('placement-zone')}
              className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-semibold transition-colors flex items-center gap-1.5 shadow-xs"
            >
              <span>Boost Readiness</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Missing Data Warning if any */}
        {!readinessResult.isFullyAssessed && (
          <div className="mt-4 p-3.5 rounded-2xl bg-amber-50 border border-amber-200 text-amber-900 text-xs flex items-start gap-2.5">
            <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
            <div>
              <span className="font-bold">Missing Assessment Data: </span>
              {readinessResult.unassessedComponents.join(', ')} currently have no verified submissions.
              Missing components are tracked as 0% until you submit proof. Complete them to elevate your rating!
            </div>
          </div>
        )}

        {/* 7 Component Breakdown Bars */}
        <div className="mt-6 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {[
            { label: 'Skill Completion', weight: '25%', data: readinessResult.components.skillCompletion, link: 'roadmap' },
            { label: 'Assessments', weight: '20%', data: readinessResult.components.assessmentScore, link: 'skill-gap' },
            { label: 'Projects & Evidence', weight: '20%', data: readinessResult.components.projectScore, link: 'projects' },
            { label: 'Aptitude Tests', weight: '15%', data: readinessResult.components.aptitudeScore, link: 'placement-zone' },
            { label: 'Communication', weight: '10%', data: readinessResult.components.communicationScore, link: 'interview-lab' },
            { label: 'Resume Score', weight: '5%', data: readinessResult.components.resumeScore, link: 'placement-zone' },
            { label: 'Interview Prep', weight: '5%', data: readinessResult.components.interviewScore, link: 'interview-lab' },
          ].map((item, idx) => (
            <div
              key={idx}
              onClick={() => onNavigate(item.link)}
              className="p-3.5 rounded-2xl bg-slate-50/70 border border-slate-200 hover:border-blue-300 hover:bg-blue-50/30 transition-all cursor-pointer group"
            >
              <div className="flex items-center justify-between text-xs mb-1.5">
                <span className="font-semibold text-slate-800 group-hover:text-blue-600 transition-colors">
                  {item.label}
                </span>
                <span className="text-[10px] text-slate-500 font-mono">{item.weight}</span>
              </div>
              <div className="flex items-center justify-between text-xs mb-1">
                <span className="font-bold text-slate-900">
                  {item.data.status === 'Not Assessed' ? 'Not Assessed' : `${item.data.score}%`}
                </span>
                <span className="text-[11px] text-slate-500">
                  +{item.data.weighted} pts
                </span>
              </div>
              <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                <div
                  className="bg-gradient-to-r from-blue-600 to-indigo-600 h-full rounded-full transition-all duration-500"
                  style={{ width: `${item.data.score}%` }}
                />
              </div>
            </div>
          ))}

          {/* Quick Info Box */}
          <div className="p-3.5 rounded-2xl bg-gradient-to-br from-indigo-50 to-purple-50 border border-indigo-100 flex flex-col justify-between">
            <div>
              <p className="text-xs font-bold text-indigo-900">Placement Benchmark</p>
              <p className="text-[11px] text-indigo-700 mt-1">
                Target 80%+ to unlock priority recruitment drives & faculty endorsements.
              </p>
            </div>
            <button
              onClick={() => onNavigate('skill-gap')}
              className="text-[11px] text-indigo-700 font-bold hover:underline inline-flex items-center gap-1 mt-2"
            >
              <span>View Gap Detective</span>
              <span>→</span>
            </button>
          </div>
        </div>
      </div>

      {/* Grid: Charts + Recommendations */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left 2 Cols: Radar & Action Cards */}
        <div className="lg:col-span-2 space-y-8">
          {/* Visual Readiness Radar Chart */}
          <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <Target className="w-4 h-4 text-blue-600" />
                Readiness Competency Breakdown
              </h3>
              <span className="text-xs text-slate-500">7 Core Placement Pillars</span>
            </div>
            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <RadarChart data={readinessChartData} outerRadius="75%">
                  <PolarGrid stroke="#e2e8f0" />
                  <PolarAngleAxis dataKey="subject" tick={{ fill: '#475569', fontSize: 11 }} />
                  <PolarRadiusAxis angle={30} domain={[0, 100]} tick={{ fill: '#94a3b8', fontSize: 10 }} />
                  <Radar
                    name="Score"
                    dataKey="score"
                    stroke="#4f46e5"
                    fill="#6366f1"
                    fillOpacity={0.45}
                  />
                  <Tooltip
                    formatter={(val: any) => [`${val}%`, 'Proficiency']}
                    contentStyle={{ borderRadius: '12px', border: '1px solid #cbd5e1', fontSize: '12px' }}
                  />
                </RadarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Continue Learning Cards */}
          <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                  <BookOpen className="w-4 h-4 text-blue-600" />
                  Continue Learning — {currentDept?.shortName}
                </h3>
                <p className="text-xs text-slate-500">Pick up where you left off in your academic roadmap</p>
              </div>
              <button
                onClick={() => onNavigate('roadmap')}
                className="text-xs text-blue-600 hover:text-blue-800 font-semibold"
              >
                View All Roadmaps →
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {continueLearningSkills.map((sk) => {
                const prog = progressMap[sk.id];
                const completedModules = prog?.completedModuleIds.length || 0;
                const totalModules = sk.modules.length;
                const pct = Math.round((completedModules / totalModules) * 100);

                return (
                  <div
                    key={sk.id}
                    onClick={() => onNavigate('skill-learning', sk.id)}
                    className="p-4 rounded-2xl border border-slate-200 hover:border-blue-400 hover:shadow-sm transition-all cursor-pointer bg-slate-50/50 flex flex-col justify-between"
                  >
                    <div>
                      <div className="flex items-center justify-between text-[11px] text-slate-500 mb-1">
                        <span className="font-semibold uppercase text-blue-600">{sk.difficulty}</span>
                        <span>{sk.estimatedHours} hrs</span>
                      </div>
                      <h4 className="text-xs font-bold text-slate-900 line-clamp-1">{sk.title}</h4>
                      <p className="text-[11px] text-slate-500 mt-1 line-clamp-2">{sk.description}</p>
                    </div>

                    <div className="mt-4 pt-3 border-t border-slate-200">
                      <div className="flex items-center justify-between text-[11px] mb-1">
                        <span className="text-slate-600">Progress</span>
                        <span className="font-bold text-slate-800">{pct}%</span>
                      </div>
                      <div className="w-full bg-slate-200 h-1.5 rounded-full overflow-hidden">
                        <div
                          className="bg-blue-600 h-full rounded-full"
                          style={{ width: `${pct}%` }}
                        />
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right Col: Recommended Actions & Missions */}
        <div className="space-y-6">
          {/* Next Recommended Actions Card */}
          <div className="bg-gradient-to-br from-blue-50/80 via-white to-indigo-50/40 rounded-3xl p-6 border border-blue-200/80 shadow-xs">
            <div className="flex items-center gap-2 mb-3">
              <Sparkles className="w-5 h-5 text-blue-600" />
              <h3 className="text-sm font-bold text-slate-900">Recommended Next Actions</h3>
            </div>
            <p className="text-xs text-slate-600 mb-4">
              AI-aligned surgical recommendations based on your current performance and roadmap requirements:
            </p>

            <div className="space-y-2.5">
              {readinessResult.recommendedNextActions.map((action, i) => (
                <div
                  key={i}
                  className="p-3 bg-white rounded-xl border border-slate-200/80 shadow-2xs flex items-start gap-2.5"
                >
                  <span className="w-5 h-5 rounded-full bg-blue-100 text-blue-700 font-bold text-xs flex items-center justify-center shrink-0 mt-0.5">
                    {i + 1}
                  </span>
                  <p className="text-xs text-slate-700 font-medium leading-relaxed">{action}</p>
                </div>
              ))}
            </div>

            <button
              onClick={() => onNavigate('skill-gap')}
              className="mt-4 w-full py-2 bg-white hover:bg-slate-50 text-blue-700 font-semibold text-xs rounded-xl border border-blue-200 transition-colors shadow-2xs"
            >
              Run Full Skill Gap Diagnostic →
            </button>
          </div>

          {/* Active Career Mission Card */}
          <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Award className="w-5 h-5 text-purple-600" />
                <h3 className="text-sm font-bold text-slate-900">Weekly Career Mission</h3>
              </div>
              <span className="text-[11px] font-bold text-purple-700 bg-purple-50 px-2 py-0.5 rounded-full border border-purple-200">
                +{activeMission.points} pts
              </span>
            </div>

            <h4 className="text-xs font-bold text-slate-800">{activeMission.title}</h4>
            <p className="text-[11px] text-slate-500 mt-1 leading-relaxed">
              {activeMission.description}
            </p>

            <div className="mt-4 space-y-2">
              {activeMission.tasks.slice(0, 3).map((t) => (
                <div
                  key={t.id}
                  className="flex items-center gap-2 text-xs p-2 rounded-lg bg-slate-50 border border-slate-100"
                >
                  <CheckCircle2
                    className={`w-3.5 h-3.5 shrink-0 ${t.completed ? 'text-emerald-600' : 'text-slate-300'}`}
                  />
                  <span className={`line-clamp-1 ${t.completed ? 'line-through text-slate-400' : 'text-slate-700'}`}>
                    {t.title}
                  </span>
                </div>
              ))}
            </div>

            <button
              onClick={() => onNavigate('missions')}
              className="mt-4 w-full py-2 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-semibold text-xs transition-colors shadow-xs"
            >
              Open Mission & Submit Evidence
            </button>
          </div>

          {/* Quick Links Card */}
          <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-xs">
            <p className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-3">
              Essential Placement Shortcuts
            </p>
            <div className="space-y-1.5 text-xs">
              <button
                onClick={() => onNavigate('career-simulator')}
                className="w-full text-left p-2.5 rounded-xl hover:bg-slate-50 font-medium text-slate-700 flex items-center justify-between transition-colors"
              >
                <span>Career Path Simulator</span>
                <ChevronRight className="w-4 h-4 text-slate-400" />
              </button>
              <button
                onClick={() => onNavigate('dependency-map')}
                className="w-full text-left p-2.5 rounded-xl hover:bg-slate-50 font-medium text-slate-700 flex items-center justify-between transition-colors"
              >
                <span>Interactive Prerequisite Map</span>
                <ChevronRight className="w-4 h-4 text-slate-400" />
              </button>
              <button
                onClick={() => onNavigate('interview-lab')}
                className="w-full text-left p-2.5 rounded-xl hover:bg-slate-50 font-medium text-slate-700 flex items-center justify-between transition-colors"
              >
                <span>Interview Practice Lab</span>
                <ChevronRight className="w-4 h-4 text-slate-400" />
              </button>
              <button
                onClick={() => onNavigate('portfolio')}
                className="w-full text-left p-2.5 rounded-xl hover:bg-slate-50 font-medium text-slate-700 flex items-center justify-between transition-colors"
              >
                <span>Evidence-Based Skill Portfolio</span>
                <ChevronRight className="w-4 h-4 text-slate-400" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
