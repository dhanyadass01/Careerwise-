import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { CareerPath } from '../types';
import {
  Compass,
  ArrowRight,
  CheckCircle2,
  AlertCircle,
  Briefcase,
  TrendingUp,
  Bookmark,
  GitCompare,
  DollarSign,
  Layers,
  HelpCircle,
  Sparkles,
} from 'lucide-react';

interface CareerPathSimulatorViewProps {
  onNavigateToRoadmap: () => void;
}

export const CareerPathSimulatorView: React.FC<CareerPathSimulatorViewProps> = ({
  onNavigateToRoadmap,
}) => {
  const {
    careerPaths,
    currentUser,
    setTargetCareerPath,
    selectedCareerPath,
    skills,
    progressMap,
  } = useApp();

  const [activePathId, setActivePathId] = useState<string>(
    currentUser?.targetCareerPathId || careerPaths[0].id
  );
  const [comparePathId, setComparePathId] = useState<string>(careerPaths[1].id);
  const [showComparison, setShowComparison] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);

  React.useEffect(() => {
    if (currentUser?.targetCareerPathId) {
      setActivePathId(currentUser.targetCareerPathId);
    }
  }, [currentUser]);

  const activePath = careerPaths.find((cp) => cp.id === activePathId) || careerPaths[0];
  const comparePath = careerPaths.find((cp) => cp.id === comparePathId) || careerPaths[1];

  // Calculate readiness for any career path based on required skills
  const computeRoleReadiness = (cp: CareerPath) => {
    if (cp.requiredSkillIds.length === 0) return 60;
    let satisfied = 0;
    cp.requiredSkillIds.forEach((sId) => {
      const prog = progressMap[sId];
      if (prog && (prog.isCompleted || (prog.quizScore && prog.quizScore >= 70))) {
        satisfied++;
      }
    });
    return Math.round((satisfied / cp.requiredSkillIds.length) * 100);
  };

  const activeReadiness = computeRoleReadiness(activePath);
  const compareReadiness = computeRoleReadiness(comparePath);

  const handleSavePreferred = () => {
    setTargetCareerPath(activePath.id);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2500);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2">
              <span className="p-2 rounded-xl bg-indigo-50 text-indigo-600">
                <Compass className="w-6 h-6" />
              </span>
              <div>
                <h1 className="text-2xl font-extrabold text-slate-900">Career Path Simulator</h1>
                <p className="text-xs text-slate-500">
                  Discover competency requirements, industry packages, and evaluate role readiness
                </p>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => setShowComparison(!showComparison)}
              className={`px-4 py-2 rounded-xl text-xs font-semibold border transition-all flex items-center gap-2 ${
                showComparison
                  ? 'bg-indigo-600 text-white border-indigo-600 shadow-sm'
                  : 'bg-white hover:bg-slate-50 text-slate-700 border-slate-200'
              }`}
            >
              <GitCompare className="w-4 h-4" />
              <span>{showComparison ? 'Exit Comparison' : 'Compare 2 Career Paths'}</span>
            </button>

            <button
              onClick={handleSavePreferred}
              className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold transition-colors flex items-center gap-1.5 shadow-xs"
            >
              <Bookmark className="w-4 h-4" />
              <span>{saveSuccess ? 'Saved as Target! ✓' : 'Save as Target Path'}</span>
            </button>
          </div>
        </div>

        {/* Roles Selector Pills */}
        <div className="mt-8 border-t border-slate-100 pt-6">
          <p className="text-xs font-semibold text-slate-500 mb-2">Available Career Tracks:</p>
          <div className="flex flex-wrap gap-2">
            {careerPaths.map((cp) => {
              const isSelected = activePathId === cp.id;
              const isUserPreferred = currentUser?.targetCareerPathId === cp.id;

              return (
                <button
                  key={cp.id}
                  onClick={() => setActivePathId(cp.id)}
                  className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all flex items-center gap-2 ${
                    isSelected
                      ? 'bg-blue-600 text-white shadow-sm shadow-blue-500/20'
                      : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                  }`}
                >
                  <span>{cp.title}</span>
                  {isUserPreferred && (
                    <span
                      className={`text-[9px] px-1.5 py-0.2 rounded-full font-bold uppercase ${
                        isSelected ? 'bg-white/20 text-white' : 'bg-blue-100 text-blue-700'
                      }`}
                    >
                      Target Goal
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Side-by-Side Comparison Mode */}
      {showComparison ? (
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
            <div>
              <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                <GitCompare className="w-5 h-5 text-indigo-600" />
                Head-to-Head Career Path Comparison
              </h2>
              <p className="text-xs text-slate-500">
                Compare competency requirements, salary bands, and your current preparation level side-by-side.
              </p>
            </div>

            <div className="flex items-center gap-2 text-xs">
              <span className="text-slate-500">Compare with:</span>
              <select
                value={comparePathId}
                onChange={(e) => setComparePathId(e.target.value)}
                className="px-3 py-1.5 rounded-xl border border-slate-200 font-semibold bg-white text-slate-800"
              >
                {careerPaths
                  .filter((c) => c.id !== activePathId)
                  .map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.title}
                    </option>
                  ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Path A */}
            <div className="p-6 rounded-2xl bg-blue-50/40 border border-blue-200 space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold uppercase text-blue-700">Role A</span>
                <span className="text-xs font-mono font-bold text-slate-800">{activePath.avgPackageLPA}</span>
              </div>
              <h3 className="text-xl font-extrabold text-slate-900">{activePath.title}</h3>
              <p className="text-xs text-slate-600 leading-relaxed">{activePath.description}</p>

              <div className="p-4 rounded-xl bg-white border border-blue-100">
                <div className="flex items-center justify-between text-xs mb-1">
                  <span className="font-semibold text-slate-700">Your Current Match</span>
                  <span className="font-bold text-blue-700">{activeReadiness}%</span>
                </div>
                <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                  <div className="bg-blue-600 h-full rounded-full" style={{ width: `${activeReadiness}%` }} />
                </div>
              </div>

              <div>
                <p className="text-xs font-bold text-slate-800 mb-2">Required Core Competencies:</p>
                <div className="flex flex-wrap gap-1.5">
                  {activePath.requiredSkillIds.map((sId) => {
                    const sk = skills.find((s) => s.id === sId);
                    return (
                      <span key={sId} className="text-xs px-2.5 py-1 rounded-lg bg-white border border-slate-200 text-slate-800 font-medium">
                        {sk?.title || sId}
                      </span>
                    );
                  })}
                </div>
              </div>

              <div>
                <p className="text-xs font-bold text-slate-800 mb-1">Recommended Projects:</p>
                <ul className="text-xs text-slate-600 space-y-1">
                  {activePath.recommendedProjects.map((p, i) => (
                    <li key={i} className="flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-blue-600"></span>
                      <span>{p}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div>
                <p className="text-xs font-bold text-slate-800 mb-1">Interview Focus Areas:</p>
                <p className="text-xs text-slate-600 leading-relaxed">{activePath.interviewTopics.join(' • ')}</p>
              </div>
            </div>

            {/* Path B */}
            <div className="p-6 rounded-2xl bg-purple-50/40 border border-purple-200 space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold uppercase text-purple-700">Role B</span>
                <span className="text-xs font-mono font-bold text-slate-800">{comparePath.avgPackageLPA}</span>
              </div>
              <h3 className="text-xl font-extrabold text-slate-900">{comparePath.title}</h3>
              <p className="text-xs text-slate-600 leading-relaxed">{comparePath.description}</p>

              <div className="p-4 rounded-xl bg-white border border-purple-100">
                <div className="flex items-center justify-between text-xs mb-1">
                  <span className="font-semibold text-slate-700">Your Current Match</span>
                  <span className="font-bold text-purple-700">{compareReadiness}%</span>
                </div>
                <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                  <div className="bg-purple-600 h-full rounded-full" style={{ width: `${compareReadiness}%` }} />
                </div>
              </div>

              <div>
                <p className="text-xs font-bold text-slate-800 mb-2">Required Core Competencies:</p>
                <div className="flex flex-wrap gap-1.5">
                  {comparePath.requiredSkillIds.map((sId) => {
                    const sk = skills.find((s) => s.id === sId);
                    return (
                      <span key={sId} className="text-xs px-2.5 py-1 rounded-lg bg-white border border-slate-200 text-slate-800 font-medium">
                        {sk?.title || sId}
                      </span>
                    );
                  })}
                </div>
              </div>

              <div>
                <p className="text-xs font-bold text-slate-800 mb-1">Recommended Projects:</p>
                <ul className="text-xs text-slate-600 space-y-1">
                  {comparePath.recommendedProjects.map((p, i) => (
                    <li key={i} className="flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-purple-600"></span>
                      <span>{p}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div>
                <p className="text-xs font-bold text-slate-800 mb-1">Interview Focus Areas:</p>
                <p className="text-xs text-slate-600 leading-relaxed">{comparePath.interviewTopics.join(' • ')}</p>
              </div>
            </div>
          </div>
        </div>
      ) : (
        /* Detailed Single View */
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main 2 Cols */}
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
                <div>
                  <span className="text-xs font-bold uppercase tracking-wider text-blue-600">
                    Industry Placement Track
                  </span>
                  <h2 className="text-2xl font-black text-slate-900 mt-1">{activePath.title}</h2>
                  <p className="text-xs sm:text-sm text-slate-600 mt-2 leading-relaxed">
                    {activePath.description}
                  </p>
                </div>

                <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 shrink-0 text-center min-w-[150px]">
                  <p className="text-xs font-semibold text-slate-500">Typical Salary Band</p>
                  <p className="text-xl font-black text-slate-900 mt-0.5">{activePath.avgPackageLPA}</p>
                  <p className="text-[10px] text-emerald-700 font-bold uppercase mt-1">
                    {activePath.demandLevel} Demand
                  </p>
                </div>
              </div>

              {/* Required Skills Matrix */}
              <div className="pt-6 border-t border-slate-100">
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-3">
                  Required Competency Blueprint
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {activePath.requiredSkillIds.map((sId) => {
                    const sk = skills.find((s) => s.id === sId);
                    const prog = progressMap[sId];
                    const isDone = prog?.isCompleted || (prog?.quizScore && prog?.quizScore >= 70);

                    return (
                      <div
                        key={sId}
                        className="p-3.5 rounded-2xl border border-slate-200 bg-slate-50/60 flex items-center justify-between"
                      >
                        <div>
                          <p className="text-xs font-bold text-slate-800">{sk?.title || sId}</p>
                          <p className="text-[10px] text-slate-500">{sk?.difficulty || 'Intermediate'} • {sk?.estimatedHours || 20} hrs</p>
                        </div>
                        <span
                          className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                            isDone ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-200 text-slate-600'
                          }`}
                        >
                          {isDone ? 'Demonstrated ✓' : 'In Progress'}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Recommended Projects & Portfolio */}
              <div className="pt-6 border-t border-slate-100 grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div>
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">
                    Recommended Capstone Projects
                  </h3>
                  <ul className="space-y-1.5 text-xs text-slate-700">
                    {activePath.recommendedProjects.map((p, i) => (
                      <li key={i} className="flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-blue-600 shrink-0" />
                        <span>{p}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div>
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">
                    Recruiter Portfolio Requirements
                  </h3>
                  <ul className="space-y-1.5 text-xs text-slate-700">
                    {activePath.portfolioRequirements.map((r, i) => (
                      <li key={i} className="flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-indigo-600 shrink-0" />
                        <span>{r}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          </div>

          {/* Right Col: Readiness & Interview Topics */}
          <div className="space-y-6">
            <div className="bg-gradient-to-br from-blue-50/80 via-white to-indigo-50/40 rounded-3xl p-6 border border-blue-200 shadow-xs">
              <h3 className="text-sm font-bold text-slate-900 mb-1">Your Role Readiness Score</h3>
              <p className="text-xs text-slate-500 mb-4">
                Percentage of prerequisite competencies satisfied for {activePath.title}:
              </p>

              <div className="flex items-baseline gap-2 mb-2">
                <span className="text-4xl font-black text-blue-700">{activeReadiness}%</span>
                <span className="text-xs text-slate-500 font-semibold">Match</span>
              </div>

              <div className="w-full bg-slate-200 h-2.5 rounded-full overflow-hidden mb-4">
                <div
                  className="bg-gradient-to-r from-blue-600 to-indigo-600 h-full rounded-full transition-all duration-500"
                  style={{ width: `${activeReadiness}%` }}
                />
              </div>

              <p className="text-xs text-slate-600 leading-relaxed">
                {activeReadiness >= 75
                  ? 'Strong alignment! Your current coursework and evidence position you well for recruitment rounds.'
                  : 'Developing alignment. Focus on completing missing core skills in your department roadmap to elevate your match.'}
              </p>

              <button
                onClick={onNavigateToRoadmap}
                className="mt-4 w-full py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs rounded-xl transition-colors shadow-xs"
              >
                Open Roadmap for Missing Skills →
              </button>
            </div>

            <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs">
              <h3 className="text-sm font-bold text-slate-900 mb-2">Interview Technical Focus</h3>
              <p className="text-xs text-slate-500 mb-4">
                Topics prioritized by recruiters during technical & domain rounds for this role:
              </p>
              <div className="flex flex-wrap gap-1.5">
                {activePath.interviewTopics.map((topic, i) => (
                  <span
                    key={i}
                    className="text-xs px-2.5 py-1 rounded-lg bg-slate-100 text-slate-800 font-medium"
                  >
                    {topic}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Transparent Disclaimer */}
      <div className="p-4 rounded-2xl bg-slate-100 border border-slate-200 text-slate-600 text-xs text-center">
        ℹ️ CareerWise simulator assessments are instructional preparation benchmarks and do not guarantee corporate employment or campus placement offers.
      </div>
    </div>
  );
};
