import React from 'react';

export type CartoonAvatarStyle =
  | 'coder-headphones'
  | 'scholar-grad'
  | 'creative-artist'
  | 'analyst-smart'
  | 'bot-cyber'
  | 'adventurer-cap'
  | 'curious-curly'
  | 'ninja-focus';

export interface CartoonAvatarOption {
  id: CartoonAvatarStyle;
  name: string;
  badge: string;
  description: string;
}

export const CARTOON_AVATAR_OPTIONS: CartoonAvatarOption[] = [
  { id: 'coder-headphones', name: 'Alex', badge: 'Dev & Tech', description: 'Headphones & Code Vibe' },
  { id: 'scholar-grad', name: 'Priya', badge: 'Scholar', description: 'Graduation Cap & Books' },
  { id: 'creative-artist', name: 'Sam', badge: 'Creative', description: 'Round Glasses & Sparkle' },
  { id: 'analyst-smart', name: 'Rohan', badge: 'Analyst', description: 'Smart Blazer & Tie' },
  { id: 'bot-cyber', name: 'Byte', badge: 'AI & Bot', description: 'Futuristic Cyber Mascot' },
  { id: 'adventurer-cap', name: 'Leo', badge: 'Builder', description: 'Streetwear Cap & Hoodie' },
  { id: 'curious-curly', name: 'Ananya', badge: 'Innovator', description: 'Curly Hair & Bright Eyes' },
  { id: 'ninja-focus', name: 'Kai', badge: 'Focus', description: 'Headband & Speed' },
];

export function getAvatarStyleFromName(name: string = ''): CartoonAvatarStyle {
  if (!name) return 'coder-headphones';
  // Check if name is already one of the avatar IDs
  if (CARTOON_AVATAR_OPTIONS.some((opt) => opt.id === name)) {
    return name as CartoonAvatarStyle;
  }
  let hash = 0;
  for (let i = 0; i < name.length; i++) {
    hash = (hash << 5) - hash + name.charCodeAt(i);
    hash |= 0;
  }
  const index = Math.abs(hash) % CARTOON_AVATAR_OPTIONS.length;
  return CARTOON_AVATAR_OPTIONS[index].id;
}

interface CartoonAvatarProps {
  name?: string;
  avatarId?: string;
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl' | '2xl' | number;
  className?: string;
  showBorder?: boolean;
}

export const CartoonAvatar: React.FC<CartoonAvatarProps> = ({
  name = 'Student',
  avatarId,
  size = 'md',
  className = '',
  showBorder = true,
}) => {
  const selectedStyle = avatarId && CARTOON_AVATAR_OPTIONS.some((o) => o.id === avatarId)
    ? (avatarId as CartoonAvatarStyle)
    : getAvatarStyleFromName(name);

  // Size mapping
  const sizeMap: Record<string, number> = {
    xs: 24,
    sm: 32,
    md: 40,
    lg: 48,
    xl: 64,
    '2xl': 80,
  };
  const pixelSize = typeof size === 'number' ? size : sizeMap[size] || 40;

  return (
    <div
      style={{ width: pixelSize, height: pixelSize }}
      className={`relative inline-flex items-center justify-center shrink-0 rounded-2xl overflow-hidden select-none transition-transform duration-200 ${
        showBorder ? 'ring-2 ring-white/80 shadow-xs' : ''
      } ${className}`}
      title={`${name} (Cartoon Avatar)`}
    >
      <svg
        viewBox="0 0 100 100"
        width="100%"
        height="100%"
        xmlns="http://www.w3.org/2000/svg"
        className="w-full h-full"
      >
        <defs>
          {/* Background Gradients */}
          <linearGradient id="bg-coder" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#3B82F6" />
            <stop offset="100%" stopColor="#1D4ED8" />
          </linearGradient>
          <linearGradient id="bg-scholar" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#8B5CF6" />
            <stop offset="100%" stopColor="#6D28D9" />
          </linearGradient>
          <linearGradient id="bg-creative" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#EC4899" />
            <stop offset="100%" stopColor="#BE185D" />
          </linearGradient>
          <linearGradient id="bg-analyst" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#10B981" />
            <stop offset="100%" stopColor="#047857" />
          </linearGradient>
          <linearGradient id="bg-bot" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#06B6D4" />
            <stop offset="100%" stopColor="#0E7490" />
          </linearGradient>
          <linearGradient id="bg-adventurer" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#F59E0B" />
            <stop offset="100%" stopColor="#D97706" />
          </linearGradient>
          <linearGradient id="bg-curly" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#A855F7" />
            <stop offset="100%" stopColor="#7E22CE" />
          </linearGradient>
          <linearGradient id="bg-ninja" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#64748B" />
            <stop offset="100%" stopColor="#334155" />
          </linearGradient>
        </defs>

        {/* 1. CODER HEADPHONES */}
        {selectedStyle === 'coder-headphones' && (
          <g>
            <rect width="100" height="100" fill="url(#bg-coder)" />
            {/* Clothes */}
            <path d="M20 100 C20 78 35 72 50 72 C65 72 80 78 80 100 Z" fill="#1E293B" />
            <path d="M42 72 L50 82 L58 72 Z" fill="#F8FAFC" />
            {/* Neck */}
            <rect x="44" y="60" width="12" height="15" rx="3" fill="#FBD38D" />
            {/* Face */}
            <ellipse cx="50" cy="46" rx="22" ry="24" fill="#FDE68A" />
            {/* Hair */}
            <path d="M26 40 C28 22 45 16 68 20 C74 22 75 30 74 38 C68 28 54 26 40 28 C34 30 28 35 26 40 Z" fill="#334155" />
            {/* Eyes */}
            <circle cx="42" cy="45" r="3" fill="#0F172A" />
            <circle cx="58" cy="45" r="3" fill="#0F172A" />
            <circle cx="43" cy="44" r="1" fill="#FFFFFF" />
            <circle cx="59" cy="44" r="1" fill="#FFFFFF" />
            {/* Blush */}
            <ellipse cx="37" cy="51" rx="3" ry="1.5" fill="#FCA5A5" opacity="0.7" />
            <ellipse cx="63" cy="51" rx="3" ry="1.5" fill="#FCA5A5" opacity="0.7" />
            {/* Smile */}
            <path d="M46 52 Q50 56 54 52" stroke="#B45309" strokeWidth="2" strokeLinecap="round" fill="none" />
            {/* Headphones */}
            <path d="M26 42 Q50 14 74 42" stroke="#0F172A" strokeWidth="4" fill="none" strokeLinecap="round" />
            <rect x="22" y="38" width="8" height="16" rx="4" fill="#38BDF8" />
            <rect x="70" y="38" width="8" height="16" rx="4" fill="#38BDF8" />
          </g>
        )}

        {/* 2. SCHOLAR GRADUATION */}
        {selectedStyle === 'scholar-grad' && (
          <g>
            <rect width="100" height="100" fill="url(#bg-scholar)" />
            {/* Clothes */}
            <path d="M18 100 C18 78 35 70 50 70 C65 70 82 78 82 100 Z" fill="#312E81" />
            <path d="M44 70 L50 84 L56 70 Z" fill="#FDE047" />
            {/* Neck */}
            <rect x="44" y="58" width="12" height="15" rx="3" fill="#FCD34D" />
            {/* Face */}
            <ellipse cx="50" cy="46" rx="22" ry="24" fill="#FED7AA" />
            {/* Hair */}
            <path d="M27 46 C26 34 32 26 50 26 C68 26 74 34 73 46 Z" fill="#451A03" />
            {/* Glasses */}
            <rect x="36" y="42" width="11" height="8" rx="2" stroke="#1E293B" strokeWidth="1.5" fill="rgba(255,255,255,0.4)" />
            <rect x="53" y="42" width="11" height="8" rx="2" stroke="#1E293B" strokeWidth="1.5" fill="rgba(255,255,255,0.4)" />
            <line x1="47" y1="46" x2="53" y2="46" stroke="#1E293B" strokeWidth="1.5" />
            {/* Eyes behind glasses */}
            <circle cx="41.5" cy="46" r="2" fill="#0F172A" />
            <circle cx="58.5" cy="46" r="2" fill="#0F172A" />
            {/* Smile */}
            <path d="M45 54 Q50 58 55 54" stroke="#9A3412" strokeWidth="2" strokeLinecap="round" fill="none" />
            {/* Graduation Cap */}
            <polygon points="50,15 84,24 50,33 16,24" fill="#1E1B4B" />
            <rect x="38" y="28" width="24" height="7" rx="2" fill="#1E1B4B" />
            {/* Tassel */}
            <circle cx="50" cy="24" r="2.5" fill="#FACC15" />
            <path d="M50 24 Q68 28 66 38" stroke="#FACC15" strokeWidth="2" fill="none" />
            <circle cx="66" cy="38" r="2" fill="#FACC15" />
          </g>
        )}

        {/* 3. CREATIVE ARTIST */}
        {selectedStyle === 'creative-artist' && (
          <g>
            <rect width="100" height="100" fill="url(#bg-creative)" />
            {/* Clothes */}
            <path d="M18 100 C18 78 35 72 50 72 C65 72 82 78 82 100 Z" fill="#BE123C" />
            <circle cx="50" cy="84" r="4" fill="#FEE2E2" />
            {/* Neck */}
            <rect x="44" y="60" width="12" height="15" rx="3" fill="#FDE68A" />
            {/* Face */}
            <ellipse cx="50" cy="46" rx="22" ry="24" fill="#FEF08A" />
            {/* Hair */}
            <path d="M24 45 C22 28 35 18 50 18 C65 18 78 28 76 45 C74 38 68 26 50 26 C32 26 26 38 24 45 Z" fill="#1C1917" />
            <path d="M24 45 C22 55 26 62 30 65 C28 58 26 52 26 45 Z" fill="#1C1917" />
            <path d="M76 45 C78 55 74 62 70 65 C72 58 74 52 74 45 Z" fill="#1C1917" />
            {/* Eyes with lashes */}
            <circle cx="41" cy="45" r="3" fill="#1C1917" />
            <circle cx="59" cy="45" r="3" fill="#1C1917" />
            <circle cx="42" cy="44" r="1.2" fill="#FFFFFF" />
            <circle cx="60" cy="44" r="1.2" fill="#FFFFFF" />
            {/* Cute Cheek Stars */}
            <path d="M35 52 L36 50 L37 52 L39 53 L37 54 L36 56 L35 54 L33 53 Z" fill="#F43F5E" />
            <path d="M65 52 L66 50 L67 52 L69 53 L67 54 L66 56 L65 54 L63 53 Z" fill="#F43F5E" />
            {/* Smile */}
            <path d="M45 53 Q50 58 55 53" stroke="#9F1239" strokeWidth="2" strokeLinecap="round" fill="none" />
            {/* Beret / Beanie */}
            <ellipse cx="50" cy="22" rx="26" ry="10" fill="#FFE4E6" />
            <circle cx="50" cy="12" r="3" fill="#FB7185" />
          </g>
        )}

        {/* 4. ANALYST SMART */}
        {selectedStyle === 'analyst-smart' && (
          <g>
            <rect width="100" height="100" fill="url(#bg-analyst)" />
            {/* Suit & Collar */}
            <path d="M18 100 C18 78 34 72 50 72 C66 72 82 78 82 100 Z" fill="#064E3B" />
            <polygon points="50,72 42,100 58,100" fill="#ECFDF5" />
            <polygon points="50,76 47,88 50,96 53,88" fill="#F59E0B" />
            {/* Neck */}
            <rect x="44" y="60" width="12" height="14" rx="3" fill="#FED7AA" />
            {/* Face */}
            <ellipse cx="50" cy="45" rx="21" ry="23" fill="#FFEDD5" />
            {/* Side-part Hair */}
            <path d="M26 40 C28 22 42 16 66 18 C74 22 75 32 74 42 C68 30 52 24 38 28 C30 31 27 36 26 40 Z" fill="#292524" />
            {/* Glasses */}
            <circle cx="41" cy="45" r="6" stroke="#047857" strokeWidth="1.8" fill="rgba(255,255,255,0.4)" />
            <circle cx="59" cy="45" r="6" stroke="#047857" strokeWidth="1.8" fill="rgba(255,255,255,0.4)" />
            <line x1="47" y1="45" x2="53" y2="45" stroke="#047857" strokeWidth="1.8" />
            {/* Eyes */}
            <circle cx="41" cy="45" r="2.5" fill="#1C1917" />
            <circle cx="59" cy="45" r="2.5" fill="#1C1917" />
            {/* Confident Smile */}
            <path d="M46 54 Q50 58 55 54" stroke="#9A3412" strokeWidth="2" strokeLinecap="round" fill="none" />
          </g>
        )}

        {/* 5. BOT CYBER */}
        {selectedStyle === 'bot-cyber' && (
          <g>
            <rect width="100" height="100" fill="url(#bg-bot)" />
            {/* Bot Body */}
            <path d="M24 100 C24 78 35 74 50 74 C65 74 76 78 76 100 Z" fill="#155E75" />
            <rect x="42" y="78" width="16" height="8" rx="2" fill="#67E8F9" />
            {/* Antenna */}
            <line x1="50" y1="26" x2="50" y2="15" stroke="#E0F2FE" strokeWidth="3" />
            <circle cx="50" cy="13" r="4" fill="#FACC15" />
            {/* Bot Head */}
            <rect x="26" y="24" width="48" height="42" rx="14" fill="#CFFAFE" />
            <rect x="22" y="38" width="6" height="14" rx="3" fill="#0891B2" />
            <rect x="72" y="38" width="6" height="14" rx="3" fill="#0891B2" />
            {/* Visor Screen */}
            <rect x="32" y="32" width="36" height="20" rx="8" fill="#0E7490" />
            {/* Glowing Digital Eyes */}
            <circle cx="41" cy="42" r="3.5" fill="#22D3EE" />
            <circle cx="59" cy="42" r="3.5" fill="#22D3EE" />
            <circle cx="42" cy="41" r="1.2" fill="#FFFFFF" />
            <circle cx="60" cy="41" r="1.2" fill="#FFFFFF" />
            {/* Digital Smile */}
            <path d="M44 58 Q50 63 56 58" stroke="#0891B2" strokeWidth="2.5" strokeLinecap="round" fill="none" />
          </g>
        )}

        {/* 6. ADVENTURER CAP */}
        {selectedStyle === 'adventurer-cap' && (
          <g>
            <rect width="100" height="100" fill="url(#bg-adventurer)" />
            {/* Hoodie */}
            <path d="M18 100 C18 78 35 72 50 72 C65 72 82 78 82 100 Z" fill="#78350F" />
            <path d="M44 72 L50 82 L56 72 Z" fill="#FEF3C7" />
            {/* Neck */}
            <rect x="44" y="60" width="12" height="15" rx="3" fill="#FDE68A" />
            {/* Face */}
            <ellipse cx="50" cy="47" rx="21" ry="23" fill="#FEF08A" />
            {/* Eyes */}
            <circle cx="42" cy="46" r="3" fill="#1C1917" />
            <circle cx="58" cy="46" r="3" fill="#1C1917" />
            <circle cx="43" cy="45" r="1.2" fill="#FFFFFF" />
            <circle cx="59" cy="45" r="1.2" fill="#FFFFFF" />
            {/* Playful Grin */}
            <path d="M44 54 Q50 60 56 54" stroke="#92400E" strokeWidth="2" strokeLinecap="round" fill="#FFFFFF" />
            {/* Backwards Cap */}
            <ellipse cx="50" cy="30" rx="24" ry="12" fill="#B45309" />
            <path d="M26 30 Q50 18 74 30 Z" fill="#D97706" />
            <polygon points="50,30 32,36 68,36" fill="#92400E" />
          </g>
        )}

        {/* 7. CURIOUS CURLY */}
        {selectedStyle === 'curious-curly' && (
          <g>
            <rect width="100" height="100" fill="url(#bg-curly)" />
            {/* Clothes */}
            <path d="M18 100 C18 78 35 72 50 72 C65 72 82 78 82 100 Z" fill="#581C87" />
            <path d="M45 72 L50 80 L55 72 Z" fill="#F3E8FF" />
            {/* Neck */}
            <rect x="44" y="60" width="12" height="15" rx="3" fill="#FDBA74" />
            {/* Bouncy Curly Hair Back */}
            <circle cx="30" cy="30" r="10" fill="#3B0764" />
            <circle cx="42" cy="22" r="10" fill="#3B0764" />
            <circle cx="58" cy="22" r="10" fill="#3B0764" />
            <circle cx="70" cy="30" r="10" fill="#3B0764" />
            <circle cx="26" cy="44" r="8" fill="#3B0764" />
            <circle cx="74" cy="44" r="8" fill="#3B0764" />
            {/* Face */}
            <ellipse cx="50" cy="47" rx="21" ry="23" fill="#FED7AA" />
            {/* Curly bangs */}
            <circle cx="38" cy="32" r="6" fill="#3B0764" />
            <circle cx="50" cy="30" r="6" fill="#3B0764" />
            <circle cx="62" cy="32" r="6" fill="#3B0764" />
            {/* Eyes */}
            <circle cx="42" cy="47" r="3.2" fill="#1F2937" />
            <circle cx="58" cy="47" r="3.2" fill="#1F2937" />
            <circle cx="43" cy="46" r="1.2" fill="#FFFFFF" />
            <circle cx="59" cy="46" r="1.2" fill="#FFFFFF" />
            {/* Warm Smile */}
            <path d="M45 55 Q50 60 55 55" stroke="#9A3412" strokeWidth="2" strokeLinecap="round" fill="none" />
          </g>
        )}

        {/* 8. NINJA FOCUS */}
        {selectedStyle === 'ninja-focus' && (
          <g>
            <rect width="100" height="100" fill="url(#bg-ninja)" />
            {/* Jacket */}
            <path d="M18 100 C18 78 35 72 50 72 C65 72 82 78 82 100 Z" fill="#0F172A" />
            <path d="M46 72 L50 82 L54 72 Z" fill="#38BDF8" />
            {/* Neck */}
            <rect x="44" y="60" width="12" height="15" rx="3" fill="#FDE68A" />
            {/* Face */}
            <ellipse cx="50" cy="47" rx="21" ry="23" fill="#FEF08A" />
            {/* Hair */}
            <path d="M26 38 C26 22 42 16 68 18 C74 22 75 32 74 42 Z" fill="#0F172A" />
            {/* Headband */}
            <rect x="25" y="32" width="50" height="8" rx="2" fill="#EF4444" />
            <circle cx="50" cy="36" r="2.5" fill="#FFFFFF" />
            {/* Eyes */}
            <path d="M38 46 Q43 43 46 47" stroke="#0F172A" strokeWidth="2.5" strokeLinecap="round" fill="none" />
            <path d="M62 46 Q57 43 54 47" stroke="#0F172A" strokeWidth="2.5" strokeLinecap="round" fill="none" />
            {/* Confident Smile */}
            <path d="M45 54 Q50 58 55 54" stroke="#92400E" strokeWidth="2" strokeLinecap="round" fill="none" />
          </g>
        )}
      </svg>
    </div>
  );
};
