import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  Target,
  AlertTriangle,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  Clock,
  ArrowRight,
  ExternalLink,
  Sparkles,
  BookOpen,
  Filter,
} from 'lucide-react';

interface SkillGapDetectiveViewProps {
  onSelectSkill: (skillId: string) => void;
  onNavigateToProjects: () => void;
}

export const SkillGapDetectiveView: React.FC<SkillGapDetectiveViewProps> = ({
  onSelectSkill,
  onNavigateToProjects,
}) => {
  const { currentUser, skillGapReport, departments, selectedCareerPath } = useApp();
  const [filterGap, setFilterGap] = useState<string>('all');

  const currentDept = departments.find((d) => d.id === currentUser?.department);

  const filteredItems = skillGapReport.items.filter((item) => {
    if (filterGap === 'all') return true;
    if (filterGap === 'critical') return item.gapLevel === 'Critical';
    if (filterGap === 'moderate') return item.gapLevel === 'Moderate';
    if (filterGap === 'minor') return item.gapLevel === 'Minor';
    if (filterGap === 'none') return item.gapLevel === 'None';
    return true;
  });

  const getGapBadge = (gap: string) => {
    switch (gap) {
      case 'Critical':
        return 'bg-rose-100 text-rose-800 border-rose-300';
      case 'Moderate':
        return 'bg-amber-100 text-amber-800 border-amber-300';
      case 'Minor':
        return 'bg-blue-100 text-blue-800 border-blue-300';
      default:
        return 'bg-emerald-100 text-emerald-800 border-emerald-300';
    }
  };

  const getProficiencyBadge = (prof: string) => {
    switch (prof) {
      case 'Mastered':
        return 'bg-purple-100 text-purple-800';
      case 'Strong':
        return 'bg-emerald-100 text-emerald-800';
      case 'Developing':
        return 'bg-blue-100 text-blue-800';
      case 'Needs Improvement':
        return 'bg-amber-100 text-amber-800';
      default:
        return 'bg-slate-100 text-slate-700';
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header Banner */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="p-2 rounded-xl bg-blue-50 text-blue-600">
                <Target className="w-6 h-6" />
              </span>
              <div>
                <h1 className="text-2xl font-extrabold text-slate-900">
                  Skill Gap Detective Engine
                </h1>
                <p className="text-xs text-slate-500">
                  Personalized diagnostic comparison: Current Evidence vs Academic Year & Target Role Requirements
                </p>
              </div>
            </div>

            <p className="text-xs sm:text-sm text-slate-600 max-w-3xl leading-relaxed pt-1">
              The engine analyzes your completed modules, quiz assessment scores, and submitted project evidence
              against benchmark proficiencies for <strong className="text-slate-800">{currentDept?.name} ({currentUser?.year})</strong> and your target career goal <strong className="text-blue-700">{selectedCareerPath?.title}</strong>.
            </p>
          </div>

          {/* Critical Gaps Count Card */}
          <div className="bg-slate-50 border border-slate-200 p-5 rounded-2xl shrink-0 min-w-[200px] text-center">
            <p className="text-xs font-bold text-slate-600 uppercase tracking-wider">High/Moderate Gaps</p>
            <p className="text-3xl font-black text-rose-600 mt-0.5">{skillGapReport.criticalGapsCount}</p>
            <p className="text-[11px] text-slate-500 mt-1">
              Requiring immediate revision
            </p>
          </div>
        </div>

        {/* Diagnostic Summary Callout */}
        <div className="mt-6 p-4 rounded-2xl bg-gradient-to-r from-blue-50 via-indigo-50/50 to-white border border-blue-200/80 flex items-start gap-3">
          <Sparkles className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
          <div className="text-xs text-slate-700">
            <span className="font-bold text-slate-900">Detective Diagnostic Finding: </span>
            {skillGapReport.overallSummary}
          </div>
        </div>

        {/* Filter Pills */}
        <div className="mt-6 pt-6 border-t border-slate-100 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-1.5 overflow-x-auto text-xs">
            <span className="text-slate-500 font-medium mr-1 flex items-center gap-1">
              <Filter className="w-3.5 h-3.5" /> Filter:
            </span>
            {[
              { id: 'all', label: 'All Skills' },
              { id: 'critical', label: 'Critical Gaps' },
              { id: 'moderate', label: 'Moderate Gaps' },
              { id: 'minor', label: 'Minor Gaps' },
              { id: 'none', label: 'On Track (None)' },
            ].map((f) => (
              <button
                key={f.id}
                onClick={() => setFilterGap(f.id)}
                className={`px-3 py-1.5 rounded-xl font-semibold transition-colors ${
                  filterGap === f.id
                    ? 'bg-blue-600 text-white shadow-2xs'
                    : 'bg-slate-100 hover:bg-slate-200 text-slate-600'
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>

          <div className="text-xs text-slate-500">
            Showing {filteredItems.length} of {skillGapReport.items.length} roadmap competencies
          </div>
        </div>
      </div>

      {/* Skills Gap Cards Grid */}
      <div className="space-y-4">
        {filteredItems.map((item) => (
          <div
            key={item.skillId}
            className="bg-white rounded-3xl p-6 border border-slate-200 hover:border-blue-300 hover:shadow-xs transition-all"
          >
            <div className="flex flex-col lg:flex-row lg:items-start justify-between gap-4">
              <div className="space-y-1.5">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="text-sm font-extrabold text-slate-900">{item.skillTitle}</span>
                  <span className="text-[10px] font-semibold px-2 py-0.5 rounded-md bg-slate-100 text-slate-600">
                    {item.category}
                  </span>
                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded-md border uppercase ${getGapBadge(
                      item.gapLevel
                    )}`}
                  >
                    {item.gapLevel} Gap
                  </span>
                  {item.hasInsufficientEvidence && (
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-amber-50 text-amber-800 border border-amber-200 flex items-center gap-1">
                      <AlertCircle className="w-3 h-3" />
                      Insufficient Quiz/Project Evidence
                    </span>
                  )}
                </div>

                <div className="flex flex-wrap items-center gap-4 text-xs pt-1">
                  <div>
                    <span className="text-slate-500">Current: </span>
                    <span className={`font-bold px-2 py-0.5 rounded ${getProficiencyBadge(item.currentProficiency)}`}>
                      {item.currentProficiency}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-500">Expected ({currentUser?.year}): </span>
                    <span className={`font-bold px-2 py-0.5 rounded ${getProficiencyBadge(item.expectedProficiency)}`}>
                      {item.expectedProficiency}
                    </span>
                  </div>
                  <div className="text-slate-500">
                    Est. Effort: <strong className="text-slate-700">{item.estimatedLearningEffort}</strong>
                  </div>
                  {item.scorePercentage > 0 && (
                    <div className="text-slate-500">
                      Demonstrated Score: <strong className="text-blue-700">{item.scorePercentage}%</strong>
                    </div>
                  )}
                </div>
              </div>

              {/* Action Button */}
              <button
                onClick={() => onSelectSkill(item.skillId)}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-semibold transition-colors flex items-center gap-1.5 shrink-0 shadow-2xs self-start"
              >
                <span>Open Learning & Quiz</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Recommendations & Practice Tasks */}
            <div className="mt-4 pt-4 border-t border-slate-100 grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-100">
                <p className="text-xs font-bold text-slate-800 mb-1 flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-blue-600" />
                  Next Recommended Action:
                </p>
                <p className="text-xs text-slate-600 leading-relaxed">{item.nextRecommendedAction}</p>
              </div>

              <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-100">
                <p className="text-xs font-bold text-slate-800 mb-1">Targeted Practice Tasks:</p>
                <ul className="space-y-1">
                  {item.recommendedPracticeTasks.map((task, idx) => (
                    <li key={idx} className="text-xs text-slate-600 flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-blue-600 shrink-0"></span>
                      <span>{task}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
