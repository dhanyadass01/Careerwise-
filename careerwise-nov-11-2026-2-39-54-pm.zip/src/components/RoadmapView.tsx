import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { DepartmentId, AcademicYear, Skill } from '../types';
import {
  Map,
  BookOpen,
  CheckCircle2,
  Clock,
  Sparkles,
  ArrowRight,
  Filter,
  Layers,
  Award,
  Lock,
} from 'lucide-react';

interface RoadmapViewProps {
  onSelectSkill: (skillId: string) => void;
}

export const RoadmapView: React.FC<RoadmapViewProps> = ({ onSelectSkill }) => {
  const { currentUser, departments, skills, progressMap } = useApp();

  const [selectedDept, setSelectedDept] = useState<DepartmentId>(
    currentUser?.department || 'bsc_cs'
  );
  const [selectedYear, setSelectedYear] = useState<AcademicYear>(
    currentUser?.year || '1st Year'
  );

  React.useEffect(() => {
    if (currentUser?.department) {
      setSelectedDept(currentUser.department);
    }
    if (currentUser?.year) {
      setSelectedYear(currentUser.year);
    }
  }, [currentUser]);

  const activeDeptInfo = departments.find((d) => d.id === selectedDept);

  // Filter skills for selected dept and year
  const activeSkills = skills.filter(
    (s) => s.departmentId === selectedDept && s.year === selectedYear
  );

  // Compute year stats
  const completedInYear = activeSkills.filter((s) => progressMap[s.id]?.isCompleted).length;
  const yearPct = activeSkills.length > 0 ? Math.round((completedInYear / activeSkills.length) * 100) : 0;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Map className="w-5 h-5 text-blue-600" />
              <h1 className="text-2xl font-extrabold text-slate-900">
                Department-Wise Skill Roadmaps
              </h1>
            </div>
            <p className="text-xs sm:text-sm text-slate-500 max-w-2xl leading-relaxed">
              Tailored curriculum roadmaps verified by faculty and corporate placement councils.
              Explore foundational, intermediate, and placement-ready milestones for each college discipline.
            </p>
          </div>

          <div className="bg-blue-50/70 border border-blue-200 p-4 rounded-2xl flex items-center gap-4 shrink-0">
            <div>
              <p className="text-xs font-bold text-blue-900">{selectedYear} Completion</p>
              <p className="text-2xl font-black text-blue-700">{yearPct}%</p>
              <p className="text-[10px] text-blue-600 font-medium">
                {completedInYear} of {activeSkills.length} skills completed
              </p>
            </div>
            <div className="w-14 h-14 rounded-full border-4 border-blue-200 border-t-blue-600 flex items-center justify-center font-bold text-xs text-blue-900">
              {yearPct}%
            </div>
          </div>
        </div>

        {/* Department Switcher Tabs */}
        <div className="mt-8 border-t border-slate-100 pt-6">
          <p className="text-xs font-semibold text-slate-500 mb-2">Select College Stream:</p>
          <div className="flex flex-wrap gap-2">
            {departments.map((dept) => {
              const isSelected = selectedDept === dept.id;
              const isStudentDept = currentUser?.department === dept.id;

              return (
                <button
                  key={dept.id}
                  onClick={() => setSelectedDept(dept.id)}
                  className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all flex items-center gap-2 ${
                    isSelected
                      ? 'bg-blue-600 text-white shadow-sm shadow-blue-500/20'
                      : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                  }`}
                >
                  <span>{dept.name}</span>
                  {isStudentDept && (
                    <span
                      className={`text-[9px] px-1.5 py-0.2 rounded-full font-bold uppercase ${
                        isSelected ? 'bg-white/20 text-white' : 'bg-blue-100 text-blue-700'
                      }`}
                    >
                      Enrolled
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* Academic Year Tabs */}
        <div className="mt-6 flex border-b border-slate-200">
          {(['1st Year', '2nd Year', '3rd Year'] as AcademicYear[]).map((yr) => {
            const isSelected = selectedYear === yr;
            const label =
              yr === '1st Year'
                ? '1st Year — Foundation'
                : yr === '2nd Year'
                ? '2nd Year — Intermediate'
                : '3rd Year — Placement Ready';

            return (
              <button
                key={yr}
                onClick={() => setSelectedYear(yr)}
                className={`py-3 px-5 text-xs font-bold border-b-2 transition-all flex items-center gap-2 ${
                  isSelected
                    ? 'border-blue-600 text-blue-700 bg-blue-50/40'
                    : 'border-transparent text-slate-500 hover:text-slate-800 hover:border-slate-300'
                }`}
              >
                <span>{label}</span>
                {currentUser?.year === yr && (
                  <span className="w-2 h-2 rounded-full bg-blue-600"></span>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Skills Grid */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-base font-bold text-slate-800">
            {activeDeptInfo?.shortName} • {selectedYear} Core Skill Catalog
          </h2>
          <span className="text-xs text-slate-500 font-medium">
            {activeSkills.length} Required Skills
          </span>
        </div>

        {activeSkills.length === 0 ? (
          <div className="bg-white rounded-3xl p-12 text-center border border-slate-200">
            <BookOpen className="w-12 h-12 text-slate-300 mx-auto mb-3" />
            <h3 className="text-base font-bold text-slate-800">No skills configured yet</h3>
            <p className="text-xs text-slate-500 max-w-sm mx-auto mt-1">
              Skills for this academic track are currently being updated in the department curriculum.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {activeSkills.map((skill) => {
              const progress = progressMap[skill.id];
              const completedModules = progress?.completedModuleIds.length || 0;
              const totalModules = skill.modules.length;
              const pct = Math.round((completedModules / totalModules) * 100);
              const isCompleted = progress?.isCompleted;
              const quizScore = progress?.quizScore;

              return (
                <div
                  key={skill.id}
                  onClick={() => onSelectSkill(skill.id)}
                  className="bg-white rounded-3xl p-6 border border-slate-200 hover:border-blue-400 hover:shadow-md transition-all cursor-pointer flex flex-col justify-between group"
                >
                  <div>
                    {/* Top Badges */}
                    <div className="flex items-center justify-between gap-2 mb-3">
                      <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-md bg-blue-50 text-blue-700 border border-blue-200/60">
                        {skill.category}
                      </span>
                      <div className="flex items-center gap-1 text-[11px] text-slate-500">
                        <Clock className="w-3.5 h-3.5" />
                        <span>{skill.estimatedHours} hrs</span>
                      </div>
                    </div>

                    <h3 className="text-base font-bold text-slate-900 group-hover:text-blue-600 transition-colors">
                      {skill.title}
                    </h3>
                    <p className="text-xs text-slate-600 mt-2 line-clamp-3 leading-relaxed">
                      {skill.description}
                    </p>

                    {/* Learning Modules pill preview */}
                    <div className="mt-4 pt-3 border-t border-slate-100">
                      <p className="text-[11px] font-semibold text-slate-500 mb-2">
                        Modules ({totalModules}):
                      </p>
                      <ul className="space-y-1">
                        {skill.modules.slice(0, 3).map((m, idx) => (
                          <li
                            key={m.id}
                            className="text-[11px] text-slate-700 flex items-center gap-1.5"
                          >
                            <span className="w-1.5 h-1.5 rounded-full bg-slate-300"></span>
                            <span className="truncate">{m.title}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  {/* Progress & Action Bottom Bar */}
                  <div className="mt-6 pt-4 border-t border-slate-100">
                    <div className="flex items-center justify-between text-xs mb-1.5">
                      <span className="text-slate-500 font-medium">Status</span>
                      <div className="flex items-center gap-2">
                        {quizScore !== undefined && (
                          <span className="text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                            Quiz: {quizScore}%
                          </span>
                        )}
                        <span className="font-bold text-slate-800">
                          {isCompleted ? 'Completed' : `${pct}%`}
                        </span>
                      </div>
                    </div>

                    <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all duration-300 ${
                          isCompleted ? 'bg-emerald-500' : 'bg-blue-600'
                        }`}
                        style={{ width: `${isCompleted ? 100 : pct}%` }}
                      />
                    </div>

                    <div className="mt-4 flex items-center justify-between text-xs font-semibold text-blue-600 group-hover:text-blue-800">
                      <span>{isCompleted ? 'Review Modules & Quiz' : 'Start Learning'}</span>
                      <ArrowRight className="w-4 h-4 transform group-hover:translate-x-1 transition-transform" />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
