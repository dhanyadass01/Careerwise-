import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { RevisionItem } from '../types';
import {
  RotateCcw,
  Sparkles,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  BookOpen,
  Calendar,
  Layers,
} from 'lucide-react';
import confetti from 'canvas-confetti';

export const SmartRevisionView: React.FC = () => {
  const { revisionItems } = useApp();
  const [items, setItems] = useState<RevisionItem[]>(revisionItems);
  const [revealedAnswers, setRevealedAnswers] = useState<Set<string>>(new Set());

  const handleToggleReveal = (id: string) => {
    setRevealedAnswers((prev) => {
      const copy = new Set(prev);
      if (copy.has(id)) copy.delete(id);
      else copy.add(id);
      return copy;
    });
  };

  const handleMarkMastered = (id: string) => {
    setItems((prev) =>
      prev.map((item) =>
        item.id === id ? { ...item, masteryLevel: 'Mastered', lastScore: 95 } : item
      )
    );
    confetti({
      particleCount: 50,
      spread: 50,
      origin: { y: 0.6 },
    });
  };

  const getMasteryBadge = (level: string) => {
    switch (level) {
      case 'Mastered':
        return 'bg-emerald-100 text-emerald-800 border-emerald-300';
      case 'Reinforcing':
        return 'bg-blue-100 text-blue-800 border-blue-300';
      default:
        return 'bg-rose-100 text-rose-800 border-rose-300';
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2">
              <span className="p-2 rounded-xl bg-indigo-50 text-indigo-600">
                <RotateCcw className="w-6 h-6" />
              </span>
              <div>
                <h1 className="text-2xl font-extrabold text-slate-900">Smart Revision Engine</h1>
                <p className="text-xs text-slate-500">
                  Spaced-repetition queue surfacing previously weak assessment concepts before knowledge decays
                </p>
              </div>
            </div>
          </div>

          <div className="bg-indigo-50 border border-indigo-200 p-4 rounded-2xl text-xs text-indigo-900">
            <strong>Active Queue:</strong> {items.filter((i) => i.masteryLevel !== 'Mastered').length} concepts due for recall
          </div>
        </div>
      </div>

      {/* Revision Queue Cards */}
      <div className="space-y-4">
        {items.map((item) => {
          const isRevealed = revealedAnswers.has(item.id);

          return (
            <div
              key={item.id}
              className="bg-white rounded-3xl p-6 border border-slate-200 hover:border-indigo-300 hover:shadow-xs transition-all space-y-4"
            >
              <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-700 bg-indigo-50 px-2.5 py-0.5 rounded-full border border-indigo-200">
                      {item.skillName}
                    </span>
                    <span
                      className={`text-[10px] font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full border ${getMasteryBadge(
                        item.masteryLevel
                      )}`}
                    >
                      {item.masteryLevel}
                    </span>
                    <span className="text-xs text-slate-500 flex items-center gap-1 font-medium">
                      <Calendar className="w-3.5 h-3.5 text-slate-400" />
                      Due: {item.recommendedReviewDate}
                    </span>
                  </div>
                  <h3 className="text-base font-bold text-slate-900 mt-1">{item.topic}</h3>
                </div>

                <div className="flex items-center gap-2">
                  <span className="text-xs text-slate-500">Prior Quiz:</span>
                  <span className="text-sm font-black text-slate-800">{item.lastScore}%</span>
                </div>
              </div>

              {/* Short concept note */}
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 text-xs text-slate-700 leading-relaxed">
                <span className="font-bold text-slate-900 block mb-1">Concept Summary & Memory Anchor:</span>
                {item.conceptSummary}
              </div>

              {/* Practice Question */}
              <div className="p-4 rounded-2xl bg-indigo-50/40 border border-indigo-100 text-xs space-y-2">
                <span className="font-bold text-indigo-950 block">Quick Recall Challenge:</span>
                <p className="font-medium text-slate-800">{item.sampleQuestion}</p>

                {isRevealed && (
                  <div className="mt-3 p-3 bg-white rounded-xl border border-indigo-200 text-xs text-indigo-950 animate-in fade-in duration-150">
                    <span className="font-bold block mb-0.5">Model Answer:</span>
                    {item.sampleAnswer}
                  </div>
                )}

                <div className="flex items-center justify-between pt-2">
                  <button
                    onClick={() => handleToggleReveal(item.id)}
                    className="text-xs font-semibold text-indigo-600 hover:text-indigo-800"
                  >
                    {isRevealed ? 'Hide Model Answer ▲' : 'Reveal Model Answer ▼'}
                  </button>

                  {item.masteryLevel !== 'Mastered' && (
                    <button
                      onClick={() => handleMarkMastered(item.id)}
                      className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-semibold transition-colors flex items-center gap-1.5 shadow-2xs"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>Mark Mastered & Schedule Next</span>
                    </button>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
