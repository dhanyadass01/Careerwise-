import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { CareerMission } from '../types';
import { CheckCircle2, Award, Clock, ArrowRight, ExternalLink, Send, Sparkles, FileText } from 'lucide-react';
import confetti from 'canvas-confetti';

export const WeeklyMissionsView: React.FC = () => {
  const { careerMissions, submitMissionTask, submitMissionEvidence, currentUser } = useApp();

  const [evidenceText, setEvidenceText] = useState('');
  const [evidenceUrl, setEvidenceUrl] = useState('');
  const [submittedMissionIds, setSubmittedMissionIds] = useState<Set<string>>(new Set());

  // Filter missions by department or show all
  const deptMissions = careerMissions.filter(
    (m) => m.departmentId === currentUser?.department
  );
  const activeMissions = deptMissions.length > 0 ? deptMissions : careerMissions;

  const handleTaskCheck = (missionId: string, taskId: string, currentVal: boolean) => {
    submitMissionTask(missionId, taskId, !currentVal);
  };

  const handleSubmitEvidence = (mission: CareerMission) => {
    if (!evidenceText) {
      alert('Please provide a brief description of your completed mission evidence.');
      return;
    }

    submitMissionEvidence(mission.id, evidenceText, evidenceUrl);
    setSubmittedMissionIds((prev) => new Set([...prev, mission.id]));
    setEvidenceText('');
    setEvidenceUrl('');

    confetti({
      particleCount: 90,
      spread: 60,
      origin: { y: 0.6 },
    });
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header Banner */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2">
              <span className="p-2 rounded-xl bg-purple-50 text-purple-600">
                <Award className="w-6 h-6" />
              </span>
              <div>
                <h1 className="text-2xl font-extrabold text-slate-900">Weekly Career Missions</h1>
                <p className="text-xs text-slate-500">
                  Practical weekly milestone challenges designed to build portfolio evidence and earn placement badges
                </p>
              </div>
            </div>
          </div>

          <div className="bg-purple-50/70 border border-purple-200 p-4 rounded-2xl flex items-center gap-4 shrink-0">
            <div>
              <p className="text-xs font-bold text-purple-900">Weekly Mission Cadence</p>
              <p className="text-xs text-purple-700 mt-0.5">
                Complete tasks & submit verifiable deliverables to earn badges.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Missions Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {activeMissions.map((mission) => {
          const completedCount = mission.tasks.filter((t) => t.completed).length;
          const totalTasks = mission.tasks.length;
          const allTasksCompleted = completedCount === totalTasks;
          const isSubmitted = submittedMissionIds.has(mission.id);

          return (
            <div
              key={mission.id}
              className="bg-white rounded-3xl p-6 border border-slate-200 hover:border-purple-300 hover:shadow-xs transition-all flex flex-col justify-between"
            >
              <div>
                {/* Top Badge */}
                <div className="flex items-center justify-between gap-2 mb-3">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-purple-700 bg-purple-50 px-2.5 py-0.5 rounded-full border border-purple-200">
                    Week {mission.weekNumber} Mission
                  </span>
                  <div className="flex items-center gap-1 text-[11px] font-bold text-slate-500">
                    <Clock className="w-3.5 h-3.5 text-slate-400" />
                    <span>{mission.deadlineDays} Days Left</span>
                  </div>
                </div>

                <h3 className="text-base font-bold text-slate-900">{mission.title}</h3>
                <p className="text-xs text-slate-600 mt-2 leading-relaxed">
                  {mission.description}
                </p>

                {/* Badge Award Card */}
                <div className="mt-4 p-3 rounded-2xl bg-gradient-to-r from-purple-50 to-indigo-50 border border-purple-100 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-purple-600" />
                    <div>
                      <p className="text-xs font-bold text-purple-950">{mission.badgeName}</p>
                      <p className="text-[10px] text-purple-700">Verifiable Milestone Badge</p>
                    </div>
                  </div>
                  <span className="text-xs font-black text-purple-700">+{mission.points} pts</span>
                </div>

                {/* Tasks Checklist */}
                <div className="mt-5 pt-4 border-t border-slate-100">
                  <div className="flex items-center justify-between text-xs font-semibold text-slate-600 mb-2">
                    <span>Task Checklist</span>
                    <span>{completedCount} / {totalTasks}</span>
                  </div>

                  <div className="space-y-2">
                    {mission.tasks.map((task) => (
                      <div
                        key={task.id}
                        onClick={() => handleTaskCheck(mission.id, task.id, task.completed)}
                        className={`p-2.5 rounded-xl border text-xs cursor-pointer transition-colors flex items-start gap-2.5 ${
                          task.completed
                            ? 'bg-emerald-50/50 border-emerald-200 text-slate-500'
                            : 'bg-slate-50 border-slate-200 text-slate-800 hover:bg-purple-50/40'
                        }`}
                      >
                        <CheckCircle2
                          className={`w-4 h-4 shrink-0 mt-0.5 ${
                            task.completed ? 'text-emerald-600' : 'text-slate-300'
                          }`}
                        />
                        <span className={task.completed ? 'line-through' : 'font-medium'}>
                          {task.title}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Submit Evidence Section */}
              <div className="mt-6 pt-4 border-t border-slate-100 space-y-3">
                <p className="text-[11px] font-semibold text-slate-500">
                  Deliverable: {mission.deliverableDescription}
                </p>

                {isSubmitted ? (
                  <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-semibold text-center flex items-center justify-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    <span>Evidence Submitted & Points Claimed!</span>
                  </div>
                ) : (
                  <div className="space-y-2">
                    <input
                      type="text"
                      placeholder="Summary of completed tasks / results..."
                      value={evidenceText}
                      onChange={(e) => setEvidenceText(e.target.value)}
                      className="w-full px-3 py-1.5 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-purple-500"
                    />
                    <input
                      type="url"
                      placeholder="Optional link (GitHub, Google Drive, Loom, Doc)"
                      value={evidenceUrl}
                      onChange={(e) => setEvidenceUrl(e.target.value)}
                      className="w-full px-3 py-1.5 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-purple-500"
                    />
                    <button
                      type="button"
                      onClick={() => handleSubmitEvidence(mission)}
                      disabled={!allTasksCompleted}
                      className="w-full py-2 bg-purple-600 hover:bg-purple-700 disabled:opacity-50 text-white font-semibold text-xs rounded-xl transition-colors shadow-2xs flex items-center justify-center gap-1.5"
                    >
                      <Send className="w-3.5 h-3.5" />
                      <span>{allTasksCompleted ? 'Submit Evidence & Claim Badge' : 'Complete All Tasks First'}</span>
                    </button>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
