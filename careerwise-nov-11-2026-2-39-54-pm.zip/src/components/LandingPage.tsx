import React from 'react';
import {
  GraduationCap,
  Sparkles,
  ArrowRight,
  Target,
  Compass,
  GitBranch,
  FolderKanban,
  Mic,
  Layers,
  CheckCircle2,
  BookOpen,
  Cpu,
  Coins,
  Briefcase,
  UserPlus,
  LogIn,
  Check,
  Shield,
  Award,
} from 'lucide-react';

interface LandingPageProps {
  onNavigate: (tab: string) => void;
  onOpenAuth?: () => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({ onNavigate }) => {
  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col">
      {/* Hero Section */}
      <section className="relative overflow-hidden pt-12 pb-20 lg:pt-20 lg:pb-28 bg-gradient-to-b from-white via-blue-50/40 to-slate-50 border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center max-w-3xl mx-auto">
            {/* Tagline Badge */}
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-blue-100/90 border border-blue-200 text-blue-800 text-xs font-semibold mb-6 shadow-xs animate-in fade-in slide-in-from-top-2 duration-300">
              <Sparkles className="w-3.5 h-3.5 text-blue-600" />
              <span>Learn the Right Skills. Build Your Career. Get Placement Ready.</span>
            </div>

            {/* Main Header */}
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-slate-900 leading-tight">
              Personalized Skill Development for{' '}
              <span className="bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 bg-clip-text text-transparent">
                CareerWise
              </span>{' '}
              Graduates
            </h1>

            {/* Sub-description */}
            <p className="mt-6 text-base sm:text-lg text-slate-600 leading-relaxed font-normal">
              A comprehensive career advancement platform helping college students discover the right skills,
              build practical verifiable projects, bridge skill gaps, and prepare systematically for high-value campus placements.
            </p>

            {/* Primary Action Buttons */}
            <div className="mt-8 flex flex-wrap items-center justify-center gap-3.5">
              {/* START LEARNING BUTTON - PRIMARY CTA */}
              <button
                onClick={() => onNavigate('login')}
                className="px-7 py-3.5 rounded-2xl bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 hover:from-blue-700 hover:via-indigo-700 hover:to-purple-700 text-white font-bold text-sm sm:text-base shadow-lg shadow-indigo-500/25 transition-all flex items-center gap-2.5 transform active:scale-95"
              >
                <Sparkles className="w-5 h-5 text-amber-300" />
                <span>Start Learning</span>
                <ArrowRight className="w-5 h-5" />
              </button>

              {/* LOG IN BUTTON */}
              <button
                onClick={() => onNavigate('login')}
                className="px-6 py-3.5 rounded-2xl bg-white hover:bg-slate-50 text-slate-800 font-semibold text-sm border border-slate-300 shadow-xs transition-colors flex items-center gap-2"
              >
                <LogIn className="w-4 h-4 text-blue-600" />
                <span>Log In</span>
              </button>

              {/* EXPLORE ROADMAPS */}
              <button
                onClick={() => onNavigate('roadmap')}
                className="px-6 py-3.5 rounded-2xl bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-semibold text-sm border border-indigo-200 transition-colors flex items-center gap-2"
              >
                <BookOpen className="w-4 h-4 text-indigo-600" />
                <span>Explore Curricula</span>
              </button>
            </div>

            {/* Highlights pill row */}
            <div className="mt-10 flex flex-wrap items-center justify-center gap-4 text-xs text-slate-600 font-medium">
              <span className="flex items-center gap-1.5 bg-white px-3 py-1.5 rounded-full border border-slate-200 shadow-2xs">
                <Check className="w-3.5 h-3.5 text-emerald-600" /> 5 College Departments
              </span>
              <span className="flex items-center gap-1.5 bg-white px-3 py-1.5 rounded-full border border-slate-200 shadow-2xs">
                <Check className="w-3.5 h-3.5 text-emerald-600" /> Tailored Custom Projects
              </span>
              <span className="flex items-center gap-1.5 bg-white px-3 py-1.5 rounded-full border border-slate-200 shadow-2xs">
                <Check className="w-3.5 h-3.5 text-emerald-600" /> 7-Factor Readiness Score
              </span>
              <span className="flex items-center gap-1.5 bg-white px-3 py-1.5 rounded-full border border-slate-200 shadow-2xs">
                <Check className="w-3.5 h-3.5 text-emerald-600" /> Verifiable Portfolio
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* Department Streams Section */}
      <section className="py-16 bg-white border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <h2 className="text-xs font-bold uppercase tracking-wider text-blue-600">Department Streams</h2>
            <p className="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-1">
              Curricula Tailored to Your Degree Program
            </p>
            <p className="text-sm text-slate-500 mt-2">
              CareerWise delivers specific, domain-relevant curriculum skills—no generic one-size-fits-all tracks.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Science Stream */}
            <div className="p-6 rounded-2xl bg-gradient-to-b from-blue-50/50 to-white border border-blue-100 hover:shadow-md transition-shadow flex flex-col justify-between">
              <div>
                <div className="w-12 h-12 rounded-xl bg-blue-600 text-white flex items-center justify-center mb-4 shadow-sm">
                  <Cpu className="w-6 h-6" />
                </div>
                <h3 className="text-lg font-bold text-slate-900">Science — Tech & Engineering</h3>
                <p className="text-xs text-slate-600 mt-2 leading-relaxed">
                  Foundational programming, data structures, full stack web apps, databases, cloud architecture, and machine learning models.
                </p>
                <div className="mt-4 space-y-2">
                  <div className="flex items-center gap-2 text-xs font-medium text-slate-700 bg-white p-2 rounded-lg border border-slate-200">
                    <CheckCircle2 className="w-4 h-4 text-blue-600 shrink-0" />
                    <span>B.Sc Computer Science</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs font-medium text-slate-700 bg-white p-2 rounded-lg border border-slate-200">
                    <CheckCircle2 className="w-4 h-4 text-blue-600 shrink-0" />
                    <span>B.Sc Information Technology</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs font-medium text-slate-700 bg-white p-2 rounded-lg border border-slate-200">
                    <CheckCircle2 className="w-4 h-4 text-blue-600 shrink-0" />
                    <span>B.Sc AI & Machine Learning</span>
                  </div>
                </div>
              </div>
              <button
                onClick={() => onNavigate('login')}
                className="mt-6 w-full py-2.5 rounded-xl text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 transition-colors flex items-center justify-center gap-1.5"
              >
                <span>Start Learning Tech</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Commerce Stream */}
            <div className="p-6 rounded-2xl bg-gradient-to-b from-purple-50/50 to-white border border-purple-100 hover:shadow-md transition-shadow flex flex-col justify-between">
              <div>
                <div className="w-12 h-12 rounded-xl bg-purple-600 text-white flex items-center justify-center mb-4 shadow-sm">
                  <Coins className="w-6 h-6" />
                </div>
                <h3 className="text-lg font-bold text-slate-900">Commerce — Finance & Accounting</h3>
                <p className="text-xs text-slate-600 mt-2 leading-relaxed">
                  Corporate accounting standards, advanced financial modeling in Excel, GST & taxation compliance, Tally Prime, and Power BI dashboards.
                </p>
                <div className="mt-4 space-y-2">
                  <div className="flex items-center gap-2 text-xs font-medium text-slate-700 bg-white p-2 rounded-lg border border-slate-200">
                    <CheckCircle2 className="w-4 h-4 text-purple-600 shrink-0" />
                    <span>Bachelor of Commerce (B.Com)</span>
                  </div>
                  <div className="p-2.5 rounded-lg bg-purple-50/60 border border-purple-200 text-[11px] text-purple-900 leading-relaxed">
                    Key Competencies: Accounting, Advanced Excel, TallyPrime, GST Compliance, Financial Analysis.
                  </div>
                </div>
              </div>
              <button
                onClick={() => onNavigate('login')}
                className="mt-6 w-full py-2.5 rounded-xl text-xs font-bold text-white bg-purple-600 hover:bg-purple-700 transition-colors flex items-center justify-center gap-1.5"
              >
                <span>Start Learning Finance</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Business Stream */}
            <div className="p-6 rounded-2xl bg-gradient-to-b from-emerald-50/50 to-white border border-emerald-100 hover:shadow-md transition-shadow flex flex-col justify-between">
              <div>
                <div className="w-12 h-12 rounded-xl bg-emerald-600 text-white flex items-center justify-center mb-4 shadow-sm">
                  <Briefcase className="w-6 h-6" />
                </div>
                <h3 className="text-lg font-bold text-slate-900">Business — Management & Strategy</h3>
                <p className="text-xs text-slate-600 mt-2 leading-relaxed">
                  Strategic management, full-funnel digital marketing, market research, sales negotiation, pitch decks, and data-backed business analytics.
                </p>
                <div className="mt-4 space-y-2">
                  <div className="flex items-center gap-2 text-xs font-medium text-slate-700 bg-white p-2 rounded-lg border border-slate-200">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>BBA (Business Administration)</span>
                  </div>
                  <div className="p-2.5 rounded-lg bg-emerald-50/60 border border-emerald-200 text-[11px] text-emerald-900 leading-relaxed">
                    Key Competencies: Business Strategy, Digital Marketing, Sales Funnels, Product Management, Analytics.
                  </div>
                </div>
              </div>
              <button
                onClick={() => onNavigate('login')}
                className="mt-6 w-full py-2.5 rounded-xl text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 transition-colors flex items-center justify-center gap-1.5"
              >
                <span>Start Learning Management</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* How CareerWise Works (7-step flow) */}
      <section className="py-16 bg-slate-50 border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <h2 className="text-xs font-bold uppercase tracking-wider text-blue-600">The Student Pathway</h2>
            <p className="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-1">How CareerWise Works</p>
            <p className="text-sm text-slate-500 mt-2">
              From day one in college to campus interview day, a systematic step-by-step development process.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              { step: '01', title: 'Create Student Account', desc: 'Enter your name, department, academic year, and current known skills.' },
              { step: '02', title: 'Tailored Project Engine', desc: 'Receive unique project architectures and tasks customized to your skills.' },
              { step: '03', title: 'Personalized Roadmap', desc: 'Unlock structured skill modules mapped to modern corporate standards.' },
              { step: '04', title: 'Learn and Practise', desc: 'Study practical lessons with curated resources, quizzes, and exercises.' },
              { step: '05', title: 'Skill Gap Detective', desc: 'Pinpoint gaps between expected benchmarks and your verified skills.' },
              { step: '06', title: 'Build Practical Projects', desc: 'Submit GitHub & live link evidence with faculty reviews and feedback.' },
              { step: '07', title: 'Placement Readiness', desc: 'Track your transparent readiness score across 7 weighted dimensions.' },
            ].map((s, idx) => (
              <div
                key={s.step}
                className={`p-5 rounded-2xl bg-white border border-slate-200 shadow-xs relative ${
                  idx === 6 ? 'sm:col-span-2 lg:col-span-2 bg-gradient-to-r from-blue-50 via-indigo-50 to-white' : ''
                }`}
              >
                <div className="text-xs font-extrabold text-blue-600 tracking-wider mb-1">STEP {s.step}</div>
                <h4 className="text-base font-bold text-slate-900">{s.title}</h4>
                <p className="text-xs text-slate-600 mt-1.5 leading-relaxed">{s.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Feature Highlights */}
      <section className="py-16 bg-white border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <h2 className="text-xs font-bold uppercase tracking-wider text-blue-600">Platform Capabilities</h2>
            <p className="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-1">Engineered for Verifiable Learning</p>
            <p className="text-sm text-slate-500 mt-2">
              Every feature bridges the gap between classroom theory and real corporate campus recruitment expectations.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <div className="p-5 rounded-2xl border border-slate-200 hover:border-blue-300 transition-all bg-slate-50/50">
              <div className="w-10 h-10 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center mb-3">
                <Target className="w-5 h-5" />
              </div>
              <h4 className="text-base font-bold text-slate-900">Personalized Skill Gap Detective</h4>
              <p className="text-xs text-slate-600 mt-1.5 leading-relaxed">
                Rule-based diagnostic engine comparing expected roadmap proficiencies against quiz scores and project evidence to recommend surgical practice tasks.
              </p>
            </div>

            <div className="p-5 rounded-2xl border border-slate-200 hover:border-blue-300 transition-all bg-slate-50/50">
              <div className="w-10 h-10 rounded-xl bg-indigo-100 text-indigo-700 flex items-center justify-center mb-3">
                <Compass className="w-5 h-5" />
              </div>
              <h4 className="text-base font-bold text-slate-900">Career Path Simulator</h4>
              <p className="text-xs text-slate-600 mt-1.5 leading-relaxed">
                Explore target roles (Full Stack Dev, Financial Analyst, AI Engineer, Marketing Exec) and compare paths side-by-side with required competencies.
              </p>
            </div>

            <div className="p-5 rounded-2xl border border-slate-200 hover:border-blue-300 transition-all bg-slate-50/50">
              <div className="w-10 h-10 rounded-xl bg-purple-100 text-purple-700 flex items-center justify-center mb-3">
                <GitBranch className="w-5 h-5" />
              </div>
              <h4 className="text-base font-bold text-slate-900">Skill Dependency Map</h4>
              <p className="text-xs text-slate-600 mt-1.5 leading-relaxed">
                Interactive node hierarchy revealing prerequisites before advanced modules unlock, ensuring students build foundational fundamentals first.
              </p>
            </div>

            <div className="p-5 rounded-2xl border border-slate-200 hover:border-blue-300 transition-all bg-slate-50/50">
              <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center mb-3">
                <FolderKanban className="w-5 h-5" />
              </div>
              <h4 className="text-base font-bold text-slate-900">Skill-to-Project Bridge</h4>
              <p className="text-xs text-slate-600 mt-1.5 leading-relaxed">
                Department-tailored real capstone projects with milestone tracking, GitHub / live link submission, and faculty review feedback loops.
              </p>
            </div>

            <div className="p-5 rounded-2xl border border-slate-200 hover:border-blue-300 transition-all bg-slate-50/50">
              <div className="w-10 h-10 rounded-xl bg-amber-100 text-amber-700 flex items-center justify-center mb-3">
                <Mic className="w-5 h-5" />
              </div>
              <h4 className="text-base font-bold text-slate-900">Interview Practice Lab</h4>
              <p className="text-xs text-slate-600 mt-1.5 leading-relaxed">
                Department-aware interview simulator for HR, technical, aptitude, communication, and project explanation with structured rubric feedback.
              </p>
            </div>

            <div className="p-5 rounded-2xl border border-slate-200 hover:border-blue-300 transition-all bg-slate-50/50">
              <div className="w-10 h-10 rounded-xl bg-rose-100 text-rose-700 flex items-center justify-center mb-3">
                <Layers className="w-5 h-5" />
              </div>
              <h4 className="text-base font-bold text-slate-900">Evidence-Based Portfolio & Badges</h4>
              <p className="text-xs text-slate-600 mt-1.5 leading-relaxed">
                Verified portfolio highlighting completed courses, certified quizzes, and approved project links. Includes a secure public shareable link.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Call To Action Banner */}
      <section className="py-16 bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 text-white">
        <div className="max-w-4xl mx-auto px-4 text-center space-y-6">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-white/10 text-white text-xs font-semibold backdrop-blur">
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            <span>Ready for Campus Recruitment</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight">
            Accelerate Your Learning with Your Custom Skill Plan
          </h2>
          <p className="text-sm sm:text-base text-blue-100 max-w-2xl mx-auto leading-relaxed">
            Create your account in under 60 seconds, input your current skills, and receive an individualized project architecture, prioritized tasks, and placement diagnostic.
          </p>
          <div className="flex flex-wrap items-center justify-center gap-4 pt-2">
            <button
              onClick={() => onNavigate('login')}
              className="px-8 py-3.5 rounded-2xl bg-white text-blue-700 hover:bg-blue-50 font-extrabold text-sm shadow-xl transition-all flex items-center gap-2 transform active:scale-95"
            >
              <span>Start Learning Now</span>
              <ArrowRight className="w-4 h-4" />
            </button>
            <button
              onClick={() => onNavigate('login')}
              className="px-6 py-3.5 rounded-2xl bg-blue-700/60 hover:bg-blue-700 border border-blue-400/50 text-white font-semibold text-sm transition-colors flex items-center gap-2"
            >
              <LogIn className="w-4 h-4" />
              <span>Log In to Existing Account</span>
            </button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="mt-auto bg-slate-900 text-slate-400 py-12 text-xs border-t border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <div className="flex items-center gap-2 text-white font-bold text-lg mb-3">
                <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center">
                  <GraduationCap className="w-5 h-5" />
                </div>
                <span>CareerWise</span>
              </div>
              <p className="text-slate-400 text-xs leading-relaxed">
                “Learn the Right Skills. Build Your Career. Get Placement Ready.”
              </p>
              <p className="text-slate-500 text-[11px] mt-2">
                College-wide skill development, career guidance, practical learning, and placement readiness platform.
              </p>
            </div>

            <div>
              <h5 className="text-white font-semibold mb-3">Department Tracks</h5>
              <ul className="space-y-2">
                <li><button onClick={() => onNavigate('roadmap')} className="hover:text-white transition-colors">B.Sc Computer Science</button></li>
                <li><button onClick={() => onNavigate('roadmap')} className="hover:text-white transition-colors">B.Sc Information Technology</button></li>
                <li><button onClick={() => onNavigate('roadmap')} className="hover:text-white transition-colors">B.Sc AI & Machine Learning</button></li>
                <li><button onClick={() => onNavigate('roadmap')} className="hover:text-white transition-colors">Bachelor of Commerce (B.Com)</button></li>
                <li><button onClick={() => onNavigate('roadmap')} className="hover:text-white transition-colors">BBA (Management & Sales)</button></li>
              </ul>
            </div>

            <div>
              <h5 className="text-white font-semibold mb-3">Platform Tools</h5>
              <ul className="space-y-2">
                <li><button onClick={() => onNavigate('login')} className="hover:text-white transition-colors">Tailored Skill Plan</button></li>
                <li><button onClick={() => onNavigate('skill-gap')} className="hover:text-white transition-colors">Skill Gap Detective</button></li>
                <li><button onClick={() => onNavigate('career-simulator')} className="hover:text-white transition-colors">Career Path Simulator</button></li>
                <li><button onClick={() => onNavigate('interview-lab')} className="hover:text-white transition-colors">Interview Practice Lab</button></li>
                <li><button onClick={() => onNavigate('placement-zone')} className="hover:text-white transition-colors">Resume Completeness Builder</button></li>
              </ul>
            </div>

            <div>
              <h5 className="text-white font-semibold mb-3">Institutional Access</h5>
              <p className="text-slate-400 text-xs mb-3">
                Get started today by registering your student profile with your current skills.
              </p>
              <div className="flex gap-2">
                <button
                  onClick={() => onNavigate('login')}
                  className="px-3.5 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5"
                >
                  <UserPlus className="w-3.5 h-3.5" />
                  <span>Register</span>
                </button>
                <button
                  onClick={() => onNavigate('login')}
                  className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5"
                >
                  <LogIn className="w-3.5 h-3.5" />
                  <span>Log In</span>
                </button>
              </div>
            </div>
          </div>

          <div className="border-t border-slate-800 pt-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-slate-500">
            <div>
              © 2026 CareerWise. All rights reserved. Placement readiness scores serve as instructional preparation indicators.
            </div>
            <div className="flex gap-4">
              <span className="hover:text-slate-300 cursor-pointer">Privacy Guidelines</span>
              <span>•</span>
              <span className="hover:text-slate-300 cursor-pointer">Institutional Policy</span>
              <span>•</span>
              <span className="hover:text-slate-300 cursor-pointer">Support</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};
