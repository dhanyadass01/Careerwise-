import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  ArrowLeft,
  BookOpen,
  CheckCircle2,
  Clock,
  Sparkles,
  ExternalLink,
  Award,
  HelpCircle,
  RotateCcw,
  AlertCircle,
  FileText,
  Lightbulb,
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface SkillLearningViewProps {
  skillId: string;
  onBack: () => void;
  onNavigateToProjects: () => void;
}

export const SkillLearningView: React.FC<SkillLearningViewProps> = ({
  skillId,
  onBack,
  onNavigateToProjects,
}) => {
  const {
    skills,
    progressMap,
    completeSkillModule,
    submitQuizScore,
    generateCertificateForSkill,
  } = useApp();

  const skill = skills.find((s) => s.id === skillId) || skills[0];
  const progress = progressMap[skill.id];

  const completedModules = new Set(progress?.completedModuleIds || []);
  const quizScore = progress?.quizScore;

  // Quiz state
  const [selectedAnswers, setSelectedAnswers] = useState<Record<number, number>>({});
  const [quizSubmitted, setQuizSubmitted] = useState(false);
  const [latestScorePct, setLatestScorePct] = useState<number | null>(quizScore ?? null);
  const [certificateIssued, setCertificateIssued] = useState(false);

  const handleModuleToggle = (moduleId: string) => {
    completeSkillModule(skill.id, moduleId);
  };

  const handleOptionSelect = (qIndex: number, optIndex: number) => {
    if (quizSubmitted) return;
    setSelectedAnswers((prev) => ({ ...prev, [qIndex]: optIndex }));
  };

  const handleQuizSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (skill.quiz.length === 0) return;

    let correctCount = 0;
    skill.quiz.forEach((q, idx) => {
      if (selectedAnswers[idx] === q.correctAnswerIndex) {
        correctCount++;
      }
    });

    const scorePct = Math.round((correctCount / skill.quiz.length) * 100);
    setLatestScorePct(scorePct);
    setQuizSubmitted(true);
    submitQuizScore(skill.id, scorePct);

    if (scorePct >= 70) {
      confetti({
        particleCount: 80,
        spread: 60,
        origin: { y: 0.6 },
      });
    }
  };

  const handleRetakeQuiz = () => {
    setSelectedAnswers({});
    setQuizSubmitted(false);
  };

  const handleClaimCertificate = () => {
    generateCertificateForSkill(skill.title);
    setCertificateIssued(true);
    confetti({
      particleCount: 100,
      spread: 70,
      origin: { y: 0.6 },
    });
  };

  const pct = Math.round((completedModules.size / skill.modules.length) * 100);

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Back button */}
      <button
        onClick={onBack}
        className="inline-flex items-center gap-2 text-xs font-semibold text-slate-600 hover:text-slate-900 bg-white px-3 py-1.5 rounded-xl border border-slate-200 shadow-2xs transition-colors"
      >
        <ArrowLeft className="w-4 h-4" />
        <span>Back to Skill Roadmap</span>
      </button>

      {/* Hero Header */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-start justify-between gap-6">
          <div className="space-y-2">
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-[10px] font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full bg-blue-100 text-blue-800">
                {skill.category}
              </span>
              <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-slate-100 text-slate-700">
                {skill.difficulty} Level
              </span>
              <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-purple-100 text-purple-700">
                {skill.importance} Priority
              </span>
            </div>

            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900">{skill.title}</h1>
            <p className="text-xs sm:text-sm text-slate-600 max-w-2xl leading-relaxed">
              {skill.description}
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-blue-50/60 border border-blue-200/80 text-center shrink-0 min-w-[140px]">
            <p className="text-xs font-semibold text-blue-900">Module Completion</p>
            <p className="text-3xl font-black text-blue-700 mt-0.5">{pct}%</p>
            <p className="text-[10px] text-blue-600 mt-1">
              {completedModules.size} of {skill.modules.length} lessons
            </p>
          </div>
        </div>

        {/* Learning Objectives */}
        <div className="mt-6 pt-6 border-t border-slate-100">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-3">
            Core Learning Objectives
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            {skill.learningObjectives.map((obj, i) => (
              <div
                key={i}
                className="flex items-start gap-2.5 p-3 rounded-xl bg-slate-50 border border-slate-100 text-xs text-slate-700"
              >
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <span>{obj}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Modules List */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
              <BookOpen className="w-5 h-5 text-blue-600" />
              Syllabus & Structured Modules
            </h2>
            <p className="text-xs text-slate-500">
              Work through each topic and check the box upon mastery to persist your progress.
            </p>
          </div>
          <span className="text-xs font-bold text-slate-700">
            {completedModules.size} / {skill.modules.length} Done
          </span>
        </div>

        <div className="space-y-3">
          {skill.modules.map((mod, index) => {
            const isDone = completedModules.has(mod.id);
            return (
              <div
                key={mod.id}
                className={`p-4 rounded-2xl border transition-all ${
                  isDone ? 'bg-emerald-50/40 border-emerald-200' : 'bg-slate-50/70 border-slate-200'
                }`}
              >
                <div className="flex items-start justify-between gap-4">
                  <div className="flex items-start gap-3">
                    <button
                      onClick={() => handleModuleToggle(mod.id)}
                      className={`w-6 h-6 rounded-lg border flex items-center justify-center shrink-0 transition-colors mt-0.5 ${
                        isDone
                          ? 'bg-emerald-600 border-emerald-600 text-white'
                          : 'bg-white border-slate-300 hover:border-blue-500'
                      }`}
                      aria-label={`Mark module ${mod.title} as ${isDone ? 'incomplete' : 'complete'}`}
                    >
                      {isDone && <CheckCircle2 className="w-4 h-4" />}
                    </button>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-slate-500">Module {index + 1}:</span>
                        <h4
                          className={`text-sm font-bold ${
                            isDone ? 'text-slate-900' : 'text-slate-800'
                          }`}
                        >
                          {mod.title}
                        </h4>
                      </div>
                      <p className="text-xs text-slate-600 mt-1 leading-relaxed">{mod.content}</p>
                    </div>
                  </div>

                  <span className="text-[11px] font-mono text-slate-500 bg-white px-2 py-0.5 rounded-md border border-slate-200 shrink-0">
                    {mod.duration}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Verified External Resources */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs">
        <h2 className="text-lg font-bold text-slate-900 mb-2 flex items-center gap-2">
          <Lightbulb className="w-5 h-5 text-amber-500" />
          Verified Learning Resources
        </h2>
        <p className="text-xs text-slate-500 mb-6">
          Pre-vetted documentation, official tutorials, and video series aligned with this skill:
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
          {skill.resources.map((res, i) => (
            <a
              key={i}
              href={res.url}
              target="_blank"
              rel="noopener noreferrer"
              className="p-4 rounded-2xl border border-slate-200 hover:border-blue-400 hover:bg-blue-50/30 transition-all flex items-start justify-between gap-3 group"
            >
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-blue-600 bg-blue-50 px-2 py-0.5 rounded">
                  {res.type}
                </span>
                <h4 className="text-xs font-bold text-slate-900 group-hover:text-blue-700 transition-colors mt-2">
                  {res.title}
                </h4>
                <p className="text-[11px] text-slate-500 truncate mt-0.5">{res.url}</p>
              </div>
              <ExternalLink className="w-4 h-4 text-slate-400 group-hover:text-blue-600 shrink-0 mt-1" />
            </a>
          ))}
        </div>
      </div>

      {/* Assessment System & Quiz */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
          <div>
            <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
              <Award className="w-5 h-5 text-indigo-600" />
              Skill Proficiency Assessment Quiz
            </h2>
            <p className="text-xs text-slate-500">
              Validates your conceptual mastery. Quiz performance directly impacts your Placement Readiness Index.
            </p>
          </div>

          {latestScorePct !== null && (
            <div className="flex items-center gap-3 bg-slate-50 p-2.5 rounded-xl border border-slate-200">
              <span className="text-xs text-slate-600 font-medium">Your Benchmark:</span>
              <span
                className={`text-sm font-extrabold px-2.5 py-0.5 rounded-md ${
                  latestScorePct >= 70 ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'
                }`}
              >
                {latestScorePct}%
              </span>
            </div>
          )}
        </div>

        {skill.quiz.length === 0 ? (
          <p className="text-xs text-slate-500">No questions available for this module yet.</p>
        ) : (
          <form onSubmit={handleQuizSubmit} className="space-y-6">
            {skill.quiz.map((q, qIndex) => {
              const selectedOpt = selectedAnswers[qIndex];
              const isSubmitted = quizSubmitted;
              const isCorrect = selectedOpt === q.correctAnswerIndex;

              return (
                <div
                  key={q.id}
                  className={`p-5 rounded-2xl border transition-colors ${
                    isSubmitted
                      ? isCorrect
                        ? 'bg-emerald-50/40 border-emerald-300'
                        : 'bg-rose-50/40 border-rose-300'
                      : 'bg-slate-50/70 border-slate-200'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2 mb-3">
                    <p className="text-xs font-bold text-slate-800">
                      Question {qIndex + 1} of {skill.quiz.length} • {q.topic}
                    </p>
                    {isSubmitted && (
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase ${
                          isCorrect ? 'bg-emerald-600 text-white' : 'bg-rose-600 text-white'
                        }`}
                      >
                        {isCorrect ? 'Correct' : 'Incorrect'}
                      </span>
                    )}
                  </div>

                  <p className="text-sm font-semibold text-slate-900 mb-4">{q.question}</p>

                  {/* Options */}
                  <div className="space-y-2">
                    {q.options.map((opt, optIndex) => {
                      const isOptionSelected = selectedOpt === optIndex;
                      const isOptionCorrect = optIndex === q.correctAnswerIndex;

                      let optClasses = 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50';
                      if (isSubmitted) {
                        if (isOptionCorrect) {
                          optClasses = 'border-emerald-500 bg-emerald-100/70 text-emerald-900 font-semibold';
                        } else if (isOptionSelected) {
                          optClasses = 'border-rose-400 bg-rose-100 text-rose-900';
                        }
                      } else if (isOptionSelected) {
                        optClasses = 'border-blue-600 bg-blue-50 text-blue-900 font-semibold shadow-2xs';
                      }

                      return (
                        <button
                          key={optIndex}
                          type="button"
                          onClick={() => handleOptionSelect(qIndex, optIndex)}
                          className={`w-full text-left p-3 rounded-xl border text-xs transition-colors flex items-center justify-between ${optClasses}`}
                        >
                          <span>{opt}</span>
                          {isSubmitted && isOptionCorrect && (
                            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                          )}
                        </button>
                      );
                    })}
                  </div>

                  {/* Explanation after submission */}
                  {isSubmitted && (
                    <div className="mt-4 p-3 rounded-xl bg-white/90 border border-slate-200 text-xs text-slate-700">
                      <p className="font-bold text-slate-800 mb-1">Explanation:</p>
                      <p className="leading-relaxed">{q.explanation}</p>
                    </div>
                  )}
                </div>
              );
            })}

            {/* Action Bar */}
            <div className="flex flex-wrap items-center justify-between gap-4 pt-2">
              {!quizSubmitted ? (
                <button
                  type="submit"
                  disabled={Object.keys(selectedAnswers).length < skill.quiz.length}
                  className="px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white font-semibold text-xs transition-colors shadow-xs"
                >
                  Submit Answers & Validate
                </button>
              ) : (
                <button
                  type="button"
                  onClick={handleRetakeQuiz}
                  className="px-6 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-900 text-white font-semibold text-xs transition-colors flex items-center gap-2"
                >
                  <RotateCcw className="w-4 h-4" />
                  <span>Retake Assessment Quiz</span>
                </button>
              )}

              {/* Certificate Claim Button */}
              {latestScorePct !== null && latestScorePct >= 80 && (
                <button
                  type="button"
                  onClick={handleClaimCertificate}
                  disabled={certificateIssued}
                  className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 disabled:opacity-60 text-white font-semibold text-xs transition-all flex items-center gap-2 shadow-xs"
                >
                  <Award className="w-4 h-4" />
                  <span>{certificateIssued ? 'Certificate Issued ✓' : 'Claim Skill Certificate'}</span>
                </button>
              )}
            </div>
          </form>
        )}
      </div>

      {/* Practical Mini-Project Idea Box */}
      <div className="bg-gradient-to-br from-indigo-50/80 to-purple-50/60 rounded-3xl p-6 sm:p-8 border border-indigo-200/80 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-700 bg-white px-2.5 py-0.5 rounded-full border border-indigo-200">
              Hands-On Proof of Work
            </span>
            <h3 className="text-base font-bold text-slate-900 mt-2">Recommended Mini-Project</h3>
            <p className="text-xs text-slate-700 mt-1 max-w-xl leading-relaxed">
              {skill.miniProjectIdea}
            </p>
          </div>

          <button
            onClick={onNavigateToProjects}
            className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs transition-colors shrink-0 shadow-xs"
          >
            Explore Projects Bridge →
          </button>
        </div>
      </div>
    </div>
  );
};
