import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import { Certificate } from '../types';
import {
  Award,
  CheckCircle2,
  Printer,
  ShieldCheck,
  Search,
  ExternalLink,
  GraduationCap,
  Sparkles,
  BookOpen,
  ArrowRight,
  UserCheck,
  Lock,
} from 'lucide-react';
import { CartoonAvatar } from './CartoonAvatar';

interface CertificatesViewProps {
  onNavigate?: (tab: string) => void;
}

export const CertificatesView: React.FC<CertificatesViewProps> = ({ onNavigate }) => {
  const { certificates, currentUser, departments, skills, progressMap } = useApp();

  // Filter certificates to strictly those earned by the specific current user
  const userCertificates = useMemo(() => {
    if (!currentUser) return [];
    return certificates.filter((c) => {
      const matchId = c.studentId === currentUser.id;
      const matchName =
        Boolean(currentUser.name &&
        c.studentName &&
        c.studentName.trim().toLowerCase() === currentUser.name.trim().toLowerCase());
      return matchId || matchName;
    });
  }, [certificates, currentUser]);

  const [selectedCertId, setSelectedCertId] = useState<string | null>(null);
  const [verificationSearchId, setVerificationSearchId] = useState('');
  const [verificationResult, setVerificationResult] = useState<Certificate | null | 'not_found'>(null);

  // Active certificate
  const selectedCert = useMemo(() => {
    if (userCertificates.length === 0) return null;
    if (selectedCertId) {
      const found = userCertificates.find((c) => c.id === selectedCertId);
      if (found) return found;
    }
    return userCertificates[0];
  }, [userCertificates, selectedCertId]);

  const handleVerify = (e: React.FormEvent) => {
    e.preventDefault();
    if (!verificationSearchId.trim()) return;
    const found = certificates.find(
      (c) => c.certificateNumber.toLowerCase() === verificationSearchId.trim().toLowerCase()
    );
    setVerificationResult(found || 'not_found');
  };

  const handlePrint = () => {
    if (!selectedCert) return;
    window.print();
  };

  const currentDeptName = departments.find((d) => d.id === currentUser?.department)?.name || 'Academic Studies';

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 animate-in fade-in duration-200">
      {/* Header */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-3">
              <span className="p-2.5 rounded-2xl bg-purple-100 text-purple-700 shadow-2xs">
                <Award className="w-6 h-6" />
              </span>
              <div>
                <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight">
                  My Verified Certificates
                </h1>
                <p className="text-xs text-slate-500">
                  Institutional academic credentials awarded to your verified student account upon course completion
                </p>
              </div>
            </div>

            {/* Current user credential badge */}
            {currentUser && (
              <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-xl bg-purple-50 border border-purple-200/80 text-xs text-purple-900 font-medium">
                <CartoonAvatar avatarId={currentUser.avatar} name={currentUser.name} size="xs" />
                <span>
                  Showing credentials earned by:{' '}
                  <strong className="font-bold text-purple-950">{currentUser.name}</strong>
                  {currentUser.registerNumber && (
                    <span className="text-purple-600 font-mono ml-1">({currentUser.registerNumber})</span>
                  )}
                </span>
                <span className="ml-1 px-2 py-0.5 rounded-full bg-purple-200/80 text-[10px] font-bold uppercase tracking-wider text-purple-800">
                  {userCertificates.length} {userCertificates.length === 1 ? 'Credential' : 'Credentials'}
                </span>
              </div>
            )}
          </div>

          <div className="flex items-center gap-3">
            {selectedCert && (
              <button
                onClick={handlePrint}
                className="px-4 py-2.5 rounded-xl bg-slate-900 hover:bg-black text-white text-xs font-semibold transition-colors flex items-center gap-2 shadow-sm"
              >
                <Printer className="w-4 h-4" />
                <span>Print / Save as PDF</span>
              </button>
            )}
            {onNavigate && (
              <button
                onClick={() => onNavigate('career-simulator')}
                className="px-4 py-2.5 rounded-xl bg-blue-50 hover:bg-blue-100 text-blue-700 text-xs font-semibold transition-colors flex items-center gap-1.5 border border-blue-200"
              >
                <BookOpen className="w-4 h-4" />
                <span>Earn More Skills</span>
              </button>
            )}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Column: Specific User Certificates List & Institutional Verification Tool */}
        <div className="space-y-6">
          {/* Specific user certificates list */}
          <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-slate-900 flex items-center gap-1.5">
                  <UserCheck className="w-4 h-4 text-purple-600" />
                  Your Earned Credentials ({userCertificates.length})
                </h3>
                <p className="text-[11px] text-slate-500">Only certificates registered to your account</p>
              </div>
            </div>

            {userCertificates.length === 0 ? (
              <div className="p-6 rounded-2xl bg-slate-50 border border-dashed border-slate-300 text-center space-y-3">
                <div className="w-12 h-12 rounded-full bg-purple-50 text-purple-500 flex items-center justify-center mx-auto">
                  <Award className="w-6 h-6" />
                </div>
                <div className="space-y-1">
                  <p className="text-xs font-bold text-slate-800">No Certificates Earned Yet</p>
                  <p className="text-[11px] text-slate-500 max-w-xs mx-auto leading-relaxed">
                    You have not yet claimed any verified certificates. Complete course modules and pass the skill quizzes to receive official credentials.
                  </p>
                </div>
                {onNavigate && (
                  <button
                    type="button"
                    onClick={() => onNavigate('custom-plan')}
                    className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white text-xs font-semibold shadow-xs transition-colors"
                  >
                    <span>View My Skill Tasks</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            ) : (
              <div className="space-y-2.5">
                {userCertificates.map((cert) => {
                  const isSelected = selectedCert?.id === cert.id;
                  return (
                    <button
                      key={cert.id}
                      type="button"
                      onClick={() => setSelectedCertId(cert.id)}
                      className={`w-full text-left p-4 rounded-2xl border transition-all ${
                        isSelected
                          ? 'bg-purple-50/90 border-purple-400 shadow-xs ring-2 ring-purple-400/20'
                          : 'bg-white hover:bg-slate-50 border-slate-200'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-2">
                        <p className="font-bold text-slate-900 text-xs line-clamp-1">
                          {cert.skillOrCourseTitle}
                        </p>
                        <span className="shrink-0 text-[10px] font-bold px-2 py-0.5 rounded-full bg-purple-100 text-purple-700">
                          Verified
                        </span>
                      </div>
                      <p className="text-[11px] text-purple-700 font-mono font-semibold mt-1">
                        {cert.certificateNumber}
                      </p>
                      <div className="flex items-center justify-between text-[10px] text-slate-500 mt-2 pt-2 border-t border-slate-200/60">
                        <span>Issued: {cert.issueDate}</span>
                        <span className="font-medium text-purple-600">Click to view ➔</span>
                      </div>
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          {/* Institutional Verification Ledger Tool */}
          <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-4">
            <div>
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                Institutional Credential Verification
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                Recruiters and employers can check the public institutional ledger to verify any CareerWise credential.
              </p>
            </div>

            <form onSubmit={handleVerify} className="space-y-2">
              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder="e.g. CW-2026-CS-88912"
                  value={verificationSearchId}
                  onChange={(e) => setVerificationSearchId(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 font-mono focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
                <button
                  type="submit"
                  className="px-3.5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-semibold shrink-0 shadow-xs transition-colors"
                >
                  Verify
                </button>
              </div>
            </form>

            {verificationResult && (
              <div className="p-4 rounded-xl border text-xs animate-in fade-in duration-150">
                {verificationResult === 'not_found' ? (
                  <p className="text-rose-700 font-semibold flex items-center gap-1.5">
                    <span>❌ Certificate ID not found in institutional ledger.</span>
                  </p>
                ) : (
                  <div className="space-y-1.5 text-slate-700">
                    <p className="text-emerald-700 font-bold flex items-center gap-1.5 pb-1 border-b border-emerald-100">
                      <CheckCircle2 className="w-4 h-4" /> Official Verified Credential Found
                    </p>
                    <p>
                      <strong>Awarded To:</strong> {verificationResult.studentName}
                    </p>
                    <p>
                      <strong>Department:</strong> {verificationResult.department}
                    </p>
                    <p>
                      <strong>Course / Specialization:</strong> {verificationResult.skillOrCourseTitle}
                    </p>
                    <p>
                      <strong>Certificate ID:</strong>{' '}
                      <span className="font-mono font-bold text-slate-900">
                        {verificationResult.certificateNumber}
                      </span>
                    </p>
                    <p>
                      <strong>Issue Date:</strong> {verificationResult.issueDate}
                    </p>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Right 2 Columns: Certificate Preview or How-To Earn Guide */}
        <div className="lg:col-span-2">
          {selectedCert ? (
            <div className="p-8 sm:p-12 rounded-3xl bg-gradient-to-br from-amber-50/40 via-white to-amber-50/30 border-8 border-double border-amber-800/30 shadow-xl relative text-center space-y-6">
              {/* Corner Ornaments */}
              <div className="absolute top-4 left-4 text-amber-700/40 font-serif text-lg select-none">✦</div>
              <div className="absolute top-4 right-4 text-amber-700/40 font-serif text-lg select-none">✦</div>
              <div className="absolute bottom-4 left-4 text-amber-700/40 font-serif text-lg select-none">✦</div>
              <div className="absolute bottom-4 right-4 text-amber-700/40 font-serif text-lg select-none">✦</div>

              {/* Institution Title */}
              <div className="space-y-1">
                <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-blue-700 to-indigo-700 text-white flex items-center justify-center mx-auto shadow-md">
                  <GraduationCap className="w-7 h-7" />
                </div>
                <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-slate-900 font-serif uppercase">
                  CareerWise
                </h2>
                <p className="text-[10px] tracking-widest uppercase font-bold text-slate-500">
                  College Council for Career Development & Placement Preparedness
                </p>
              </div>

              {/* Certificate of Achievement */}
              <div className="space-y-2 pt-2">
                <p className="text-xs uppercase tracking-widest text-amber-800 font-semibold font-serif">
                  Certificate of Professional Achievement
                </p>
                <p className="text-xs text-slate-500 italic">This is proudly awarded to</p>
                <h3 className="text-3xl sm:text-4xl font-black text-slate-900 font-serif tracking-wide border-b-2 border-slate-200 pb-2 max-w-md mx-auto">
                  {selectedCert.studentName}
                </h3>
                <p className="text-xs text-slate-600 font-medium pt-1">
                  Department of {selectedCert.department}
                </p>
              </div>

              {/* Description */}
              <div className="max-w-xl mx-auto space-y-2">
                <p className="text-xs text-slate-600 leading-relaxed">
                  For successfully demonstrating academic mastery, passing all validated conceptual assessments,
                  and delivering evaluated capstone proof-of-work in:
                </p>
                <p className="text-lg font-bold text-indigo-900 font-serif">
                  "{selectedCert.skillOrCourseTitle}"
                </p>
              </div>

              {/* Verified Criteria */}
              <div className="max-w-lg mx-auto p-4 rounded-xl bg-white/80 border border-slate-200 text-left text-[11px] text-slate-600 space-y-1.5 shadow-2xs">
                <p className="font-bold text-slate-800 text-[10px] uppercase tracking-wider">
                  Verified Academic Criteria Satisfied:
                </p>
                {selectedCert.criteriaMet.map((c, i) => (
                  <p key={i} className="flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                    <span>{c}</span>
                  </p>
                ))}
              </div>

              {/* Signatures & Footer */}
              <div className="pt-6 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-6 text-xs text-slate-600">
                <div className="text-left font-mono text-[10px] space-y-0.5">
                  <p>
                    <strong>Certificate ID:</strong> {selectedCert.certificateNumber}
                  </p>
                  <p>
                    <strong>Issue Date:</strong> {selectedCert.issueDate}
                  </p>
                  <p>
                    <strong>Student ID:</strong> {selectedCert.studentId}
                  </p>
                </div>

                <div className="text-center sm:text-right space-y-0.5">
                  <div className="font-serif italic font-bold text-slate-800 text-sm">
                    K. R. Ramanathan
                  </div>
                  <div className="h-0.5 w-36 bg-slate-400 mx-auto sm:ml-auto"></div>
                  <p className="text-[10px] text-slate-500 font-medium">
                    Director of Placements & Training
                  </p>
                </div>
              </div>
            </div>
          ) : (
            /* Empty State for user without certificates */
            <div className="bg-white rounded-3xl p-8 sm:p-12 border border-slate-200 shadow-xs space-y-8 text-center">
              <div className="w-16 h-16 rounded-3xl bg-purple-50 text-purple-600 flex items-center justify-center mx-auto shadow-xs">
                <Award className="w-8 h-8" />
              </div>

              <div className="space-y-2 max-w-md mx-auto">
                <h3 className="text-xl font-bold text-slate-900">
                  Ready to Earn Your Verified CareerWise Certificate?
                </h3>
                <p className="text-xs text-slate-500 leading-relaxed">
                  CareerWise certificates are unique to each student and verified through our institutional academic ledger. Once earned, your certificate is permanently linked to your profile and exportable as a high-resolution PDF.
                </p>
              </div>

              {/* 3 Step Roadmap to Earn a Certificate */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-left max-w-2xl mx-auto">
                <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
                  <div className="w-7 h-7 rounded-lg bg-blue-100 text-blue-700 font-bold text-xs flex items-center justify-center">
                    1
                  </div>
                  <h4 className="text-xs font-bold text-slate-900">Study Course Modules</h4>
                  <p className="text-[11px] text-slate-500 leading-relaxed">
                    Explore interactive lessons and code examples in your department roadmap.
                  </p>
                </div>

                <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
                  <div className="w-7 h-7 rounded-lg bg-purple-100 text-purple-700 font-bold text-xs flex items-center justify-center">
                    2
                  </div>
                  <h4 className="text-xs font-bold text-slate-900">Pass the Assessment</h4>
                  <p className="text-[11px] text-slate-500 leading-relaxed">
                    Score 70% or higher on the end-of-module assessment to prove your competence.
                  </p>
                </div>

                <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
                  <div className="w-7 h-7 rounded-lg bg-emerald-100 text-emerald-700 font-bold text-xs flex items-center justify-center">
                    3
                  </div>
                  <h4 className="text-xs font-bold text-slate-900">Claim Credential</h4>
                  <p className="text-[11px] text-slate-500 leading-relaxed">
                    Click 'Claim Certificate' to instantly issue your verified credential and ID.
                  </p>
                </div>
              </div>

              {onNavigate && (
                <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => onNavigate('career-simulator')}
                    className="px-5 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white text-xs font-bold shadow-sm transition-all flex items-center gap-2"
                  >
                    <BookOpen className="w-4 h-4" />
                    <span>Go to Skill Courses</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => onNavigate('custom-plan')}
                    className="px-5 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold transition-all flex items-center gap-2"
                  >
                    <span>View Personalized Plan</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
