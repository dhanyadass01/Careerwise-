import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { AcademicYear, DepartmentId, ProjectSubmission, TrainingSession } from '../types';
import {
  Users,
  GraduationCap,
  FolderKanban,
  CheckCircle2,
  AlertTriangle,
  Award,
  TrendingUp,
  FileCheck2,
  Calendar,
  Plus,
  Send,
  ExternalLink,
  Github,
  BarChart2,
  Sparkles,
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
} from 'recharts';
import confetti from 'canvas-confetti';

export const FacultyDashboard: React.FC = () => {
  const {
    currentUser,
    departments,
    users,
    projectSubmissions,
    projects,
    reviewProjectSubmission,
    trainingSessions,
    createTrainingSession,
  } = useApp();

  const [selectedDept, setSelectedDept] = useState<DepartmentId>(
    currentUser?.department || 'bsc_cs'
  );
  const [selectedYear, setSelectedYear] = useState<AcademicYear | 'All'>('All');

  React.useEffect(() => {
    if (currentUser?.department) {
      setSelectedDept(currentUser.department);
    }
  }, [currentUser]);

  // Review modal state
  const [reviewSubId, setReviewSubId] = useState<string | null>(null);
  const [reviewGrade, setReviewGrade] = useState<number>(85);
  const [reviewStatus, setReviewStatus] = useState<'Approved' | 'Needs Revision'>('Approved');
  const [reviewFeedback, setReviewFeedback] = useState<string>('');

  // New Training session form state
  const [showTrainingModal, setShowTrainingModal] = useState(false);
  const [trainTitle, setTrainTitle] = useState('');
  const [trainTrainer, setTrainTrainer] = useState('');
  const [trainDate, setTrainDate] = useState('2026-10-31');
  const [trainTime, setTrainTime] = useState('02:00 PM - 04:30 PM');
  const [trainLocation, setTrainLocation] = useState('Seminar Hall A & Hybrid Meet');
  const [trainSkill, setTrainSkill] = useState('Technical Interview Preparation');
  const [trainDesc, setTrainDesc] = useState('');

  // Department students
  const deptStudents = users.filter(
    (u) =>
      u.role === 'student' &&
      u.department === selectedDept &&
      (selectedYear === 'All' || u.year === selectedYear)
  );

  // Submissions pending review
  const pendingSubmissions = projectSubmissions.filter(
    (s) => s.departmentId === selectedDept && s.status === 'Submitted'
  );

  // Training demand aggregate chart data
  const trainingDemandData = [
    { subject: 'SQL & DB', avgScore: 78, demand: 'Medium' },
    { subject: 'Coding / Logic', avgScore: 61, demand: 'High' },
    { subject: 'Aptitude Reasoning', avgScore: 72, demand: 'Medium' },
    { subject: 'Communication', avgScore: 49, demand: 'Critical' },
    { subject: 'Interview Lab', avgScore: 42, demand: 'Critical' },
  ];

  const handleOpenReview = (sub: ProjectSubmission) => {
    setReviewSubId(sub.id);
    setReviewGrade(sub.gradeScore ?? 85);
    setReviewStatus('Approved');
    setReviewFeedback(
      'Clean architecture and sound separation of concerns. Satisfies department capstone standards.'
    );
  };

  const handleSaveReview = (e: React.FormEvent) => {
    e.preventDefault();
    if (!reviewSubId) return;

    reviewProjectSubmission(reviewSubId, reviewStatus, reviewGrade, reviewFeedback);
    setReviewSubId(null);

    confetti({
      particleCount: 70,
      spread: 60,
      origin: { y: 0.6 },
    });
  };

  const handleCreateTraining = (e: React.FormEvent) => {
    e.preventDefault();
    if (!trainTitle || !trainTrainer) return;

    createTrainingSession({
      title: trainTitle,
      departmentId: selectedDept,
      year: '3rd Year',
      trainer: trainTrainer,
      date: trainDate,
      time: trainTime,
      locationOrUrl: trainLocation,
      targetSkill: trainSkill,
      description: trainDesc || 'Rigorous placement training workshop with pre/post evaluation.',
      attendeesCount: 45,
    });

    setShowTrainingModal(false);
    setTrainTitle('');
    setTrainTrainer('');
    setTrainDesc('');
  };

  const activeReviewSub = projectSubmissions.find((s) => s.id === reviewSubId);
  const activeReviewProject = activeReviewSub
    ? projects.find((p) => p.id === activeReviewSub.projectId)
    : null;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header Banner */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2">
              <span className="p-2 rounded-xl bg-blue-50 text-blue-600">
                <Users className="w-6 h-6" />
              </span>
              <div>
                <h1 className="text-2xl font-extrabold text-slate-900">
                  Faculty & HOD Management Portal
                </h1>
                <p className="text-xs text-slate-500">
                  Authorized department student monitoring, project grading, and placement training demand analytics
                </p>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowTrainingModal(true)}
              className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold transition-colors flex items-center gap-1.5 shadow-xs"
            >
              <Plus className="w-4 h-4" />
              <span>Schedule Placement Training</span>
            </button>
          </div>
        </div>

        {/* Filters */}
        <div className="mt-8 border-t border-slate-100 pt-6 flex flex-wrap items-center justify-between gap-4">
          <div className="flex flex-wrap items-center gap-2 text-xs">
            <span className="text-slate-500 font-semibold mr-1">Department:</span>
            {departments.map((d) => (
              <button
                key={d.id}
                onClick={() => setSelectedDept(d.id)}
                className={`px-3 py-1.5 rounded-xl font-semibold transition-all ${
                  selectedDept === d.id
                    ? 'bg-blue-600 text-white shadow-2xs'
                    : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                }`}
              >
                {d.shortName}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2 text-xs">
            <span className="text-slate-500 font-semibold">Year:</span>
            {(['All', '1st Year', '2nd Year', '3rd Year'] as (AcademicYear | 'All')[]).map((yr) => (
              <button
                key={yr}
                onClick={() => setSelectedYear(yr)}
                className={`px-3 py-1 rounded-lg font-semibold transition-all ${
                  selectedYear === yr
                    ? 'bg-slate-800 text-white'
                    : 'bg-slate-100 hover:bg-slate-200 text-slate-600'
                }`}
              >
                {yr}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Cohort Overview Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-2xs">
          <p className="text-xs font-bold text-slate-500 uppercase">Authorized Students</p>
          <p className="text-3xl font-black text-slate-900 mt-1">{deptStudents.length || 52}</p>
          <p className="text-[11px] text-slate-500 mt-1">Enrolled in selected cohort</p>
        </div>

        <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-2xs">
          <p className="text-xs font-bold text-slate-500 uppercase">Placement Ready</p>
          <p className="text-3xl font-black text-emerald-600 mt-1">31</p>
          <p className="text-[11px] text-emerald-700 mt-1">Scoring 60%+ on readiness</p>
        </div>

        <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-2xs">
          <p className="text-xs font-bold text-slate-500 uppercase">Needs Additional Support</p>
          <p className="text-3xl font-black text-amber-600 mt-1">15</p>
          <p className="text-[11px] text-amber-700 mt-1">Target for targeted intervention</p>
        </div>

        <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-2xs">
          <p className="text-xs font-bold text-slate-500 uppercase">Pending Project Reviews</p>
          <p className="text-3xl font-black text-blue-600 mt-1">{pendingSubmissions.length}</p>
          <p className="text-[11px] text-blue-700 mt-1">Submissions awaiting faculty review</p>
        </div>
      </div>

      {/* Grid: Project Review Queue + Placement Demand Analytics */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left 2 Cols: Submissions Queue */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-6">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <div>
                <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                  <FolderKanban className="w-5 h-5 text-blue-600" />
                  Student Project Submissions Queue
                </h2>
                <p className="text-xs text-slate-500">
                  Inspect GitHub repositories, deployed URLs, and assign grades with audit feedback.
                </p>
              </div>
              <span className="text-xs font-bold px-2.5 py-1 rounded-full bg-blue-100 text-blue-800">
                {projectSubmissions.length} Total Submissions
              </span>
            </div>

            <div className="space-y-4">
              {projectSubmissions.map((sub) => {
                const pr = projects.find((p) => p.id === sub.projectId);
                return (
                  <div
                    key={sub.id}
                    className="p-5 rounded-2xl border border-slate-200 bg-slate-50/50 space-y-3"
                  >
                    <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-2">
                      <div>
                        <div className="flex items-center gap-2">
                          <h3 className="text-sm font-bold text-slate-900">{sub.studentName}</h3>
                          <span className="text-[10px] text-slate-500 font-mono">
                            {sub.departmentId.toUpperCase()}
                          </span>
                        </div>
                        <p className="text-xs font-semibold text-blue-700 mt-0.5">
                          {pr?.title || 'Capstone Project'}
                        </p>
                      </div>

                      <div className="flex items-center gap-2">
                        <span
                          className={`text-xs font-bold px-3 py-0.5 rounded-full border ${
                            sub.status === 'Approved'
                              ? 'bg-emerald-100 text-emerald-800 border-emerald-300'
                              : sub.status === 'Needs Revision'
                              ? 'bg-amber-100 text-amber-800 border-amber-300'
                              : 'bg-blue-100 text-blue-800 border-blue-300'
                          }`}
                        >
                          {sub.status} {sub.gradeScore && `(${sub.gradeScore}/100)`}
                        </span>

                        <button
                          onClick={() => handleOpenReview(sub)}
                          className="px-3.5 py-1 bg-slate-900 hover:bg-black text-white text-xs font-semibold rounded-xl transition-colors"
                        >
                          Review & Grade
                        </button>
                      </div>
                    </div>

                    <p className="text-xs text-slate-600 leading-relaxed line-clamp-2">
                      {sub.reportNotes}
                    </p>

                    <div className="flex flex-wrap items-center gap-3 text-xs pt-1">
                      {sub.githubUrl && (
                        <a
                          href={sub.githubUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-blue-600 hover:underline flex items-center gap-1 font-semibold"
                        >
                          <Github className="w-3.5 h-3.5" />
                          <span>Code Repository</span>
                        </a>
                      )}
                      {sub.liveUrl && (
                        <a
                          href={sub.liveUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-purple-600 hover:underline flex items-center gap-1 font-semibold"
                        >
                          <ExternalLink className="w-3.5 h-3.5" />
                          <span>Live Demo</span>
                        </a>
                      )}
                    </div>

                    {sub.feedback && (
                      <div className="p-3 rounded-xl bg-white border border-slate-200 text-xs text-slate-700">
                        <span className="font-bold text-slate-800">Recorded Faculty Feedback: </span>
                        "{sub.feedback}"
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right Col: Placement Training Demand Analytics */}
        <div className="space-y-6">
          <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-4">
            <div>
              <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <BarChart2 className="w-5 h-5 text-purple-600" />
                Placement Training Demand Analytics
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                Aggregated cohort assessment averages identifying immediate remediation priorities.
              </p>
            </div>

            <div className="h-56 w-full pt-2">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={trainingDemandData} margin={{ top: 10, right: 10, left: -20, bottom: 20 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                  <XAxis dataKey="subject" tick={{ fill: '#475569', fontSize: 10 }} angle={-25} textAnchor="end" />
                  <YAxis domain={[0, 100]} tick={{ fill: '#94a3b8', fontSize: 10 }} />
                  <Tooltip
                    formatter={(val: any) => [`${val}%`, 'Cohort Average']}
                    contentStyle={{ borderRadius: '12px', fontSize: '12px' }}
                  />
                  <Bar dataKey="avgScore" fill="#6366f1" radius={[6, 6, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>

            <div className="p-4 rounded-2xl bg-purple-50/60 border border-purple-200 space-y-2 text-xs">
              <span className="font-bold text-purple-950 flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-purple-600" />
                Faculty Action Priorities:
              </span>
              <ol className="text-purple-900 space-y-1 list-decimal list-inside leading-relaxed">
                <li><strong>Interview Preparation (42%):</strong> Schedule mock rounds</li>
                <li><strong>Communication Skills (49%):</strong> Conduct GD simulations</li>
                <li><strong>Coding Practice (61%):</strong> Assign data structures drills</li>
              </ol>
            </div>
          </div>

          {/* Scheduled Training Sessions History */}
          <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-4">
            <h3 className="text-sm font-bold text-slate-900">Recorded Training Sessions</h3>
            <div className="space-y-3">
              {trainingSessions.map((ts) => (
                <div key={ts.id} className="p-3.5 rounded-2xl border border-slate-200 bg-slate-50/60 text-xs space-y-1.5">
                  <p className="font-bold text-slate-900">{ts.title}</p>
                  <p className="text-slate-600 font-medium">Trainer: {ts.trainer}</p>
                  <p className="text-slate-500 text-[11px]">{ts.date} • {ts.time}</p>
                  {ts.preTrainingAvgScore && ts.postTrainingAvgScore && (
                    <div className="mt-2 pt-2 border-t border-slate-200 flex items-center justify-between text-[11px]">
                      <span className="text-slate-500">Cohort Improvement:</span>
                      <span className="font-bold text-emerald-700">
                        {ts.preTrainingAvgScore}% → {ts.postTrainingAvgScore}% (+{ts.postTrainingAvgScore - ts.preTrainingAvgScore}%)
                      </span>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Review & Grade Modal */}
      {reviewSubId && activeReviewSub && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-lg overflow-hidden">
            <div className="p-5 bg-gradient-to-r from-blue-700 to-indigo-700 text-white flex items-center justify-between">
              <div>
                <h3 className="text-base font-bold">Faculty Project Evaluation</h3>
                <p className="text-blue-100 text-xs">
                  {activeReviewSub.studentName} • {activeReviewProject?.title || 'Capstone'}
                </p>
              </div>
              <button onClick={() => setReviewSubId(null)} className="text-white/80 hover:text-white">
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveReview} className="p-6 space-y-4">
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 text-xs space-y-1">
                <p><strong>GitHub:</strong> {activeReviewSub.githubUrl || 'None'}</p>
                <p><strong>Live Demo:</strong> {activeReviewSub.liveUrl || 'None'}</p>
                <p className="text-slate-600 line-clamp-2"><strong>Notes:</strong> {activeReviewSub.reportNotes}</p>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Status</label>
                  <select
                    value={reviewStatus}
                    onChange={(e) => setReviewStatus(e.target.value as any)}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 font-semibold"
                  >
                    <option value="Approved">Approved</option>
                    <option value="Needs Revision">Needs Revision</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Grade Score (0-100)</label>
                  <input
                    type="number"
                    min={0}
                    max={100}
                    value={reviewGrade}
                    onChange={(e) => setReviewGrade(Number(e.target.value))}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 font-bold"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Faculty Review Feedback & Recommendations *
                </label>
                <textarea
                  rows={4}
                  value={reviewFeedback}
                  onChange={(e) => setReviewFeedback(e.target.value)}
                  placeholder="Detail strengths, code design, security practices, and improvements..."
                  required
                  className="w-full p-3 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setReviewSubId(null)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-semibold bg-blue-600 hover:bg-blue-700 text-white rounded-xl shadow-xs"
                >
                  Confirm & Notify Student
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Schedule Training Modal */}
      {showTrainingModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-lg overflow-hidden">
            <div className="p-5 bg-gradient-to-r from-blue-700 to-indigo-700 text-white flex items-center justify-between">
              <div>
                <h3 className="text-base font-bold">Schedule Department Placement Training</h3>
                <p className="text-blue-100 text-xs">{selectedDept.toUpperCase()} Cohort</p>
              </div>
              <button onClick={() => setShowTrainingModal(false)} className="text-white/80 hover:text-white">
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateTraining} className="p-6 space-y-3.5">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Training Session Title *</label>
                <input
                  type="text"
                  required
                  value={trainTitle}
                  onChange={(e) => setTrainTitle(e.target.value)}
                  placeholder="e.g. Corporate Technical Interview Bootcamp"
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Lead Trainer / Guest Speaker *</label>
                  <input
                    type="text"
                    required
                    value={trainTrainer}
                    onChange={(e) => setTrainTrainer(e.target.value)}
                    placeholder="e.g. Mr. Rajesh Kumar (Tech Director)"
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Target Skill Competency</label>
                  <input
                    type="text"
                    value={trainSkill}
                    onChange={(e) => setTrainSkill(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Date</label>
                  <input
                    type="date"
                    value={trainDate}
                    onChange={(e) => setTrainDate(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Timing</label>
                  <input
                    type="text"
                    value={trainTime}
                    onChange={(e) => setTrainTime(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Venue or Meeting Link</label>
                <input
                  type="text"
                  value={trainLocation}
                  onChange={(e) => setTrainLocation(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setShowTrainingModal(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-semibold bg-blue-600 hover:bg-blue-700 text-white rounded-xl shadow-xs"
                >
                  Publish Training Session
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
