import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Project, ProjectStatus } from '../types';
import {
  FolderKanban,
  CheckCircle2,
  Clock,
  ArrowRight,
  ExternalLink,
  Github,
  Send,
  AlertCircle,
  FileCheck2,
  Award,
  Sparkles,
} from 'lucide-react';
import confetti from 'canvas-confetti';

export const ProjectsView: React.FC = () => {
  const {
    projects,
    projectSubmissions,
    currentUser,
    submitProject,
    departments,
  } = useApp();

  const [selectedProjectId, setSelectedProjectId] = useState<string>(projects[0].id);
  const [showSubmitModal, setShowSubmitModal] = useState(false);
  const [githubUrl, setGithubUrl] = useState('');
  const [liveUrl, setLiveUrl] = useState('');
  const [reportNotes, setReportNotes] = useState('');
  const [submitError, setSubmitError] = useState<string | null>(null);

  React.useEffect(() => {
    const deptProj = projects.find((p) => p.departmentId === currentUser?.department);
    if (deptProj) setSelectedProjectId(deptProj.id);
  }, [currentUser, projects]);

  const selectedProject = projects.find((p) => p.id === selectedProjectId) || projects[0];

  // User's submission for this project
  const userSubmission = projectSubmissions.find(
    (s) => s.projectId === selectedProject.id && s.studentId === currentUser?.id
  );

  const getStatusBadge = (status: ProjectStatus) => {
    switch (status) {
      case 'Approved':
      case 'Completed':
        return 'bg-emerald-100 text-emerald-800 border-emerald-300';
      case 'Submitted':
        return 'bg-blue-100 text-blue-800 border-blue-300';
      case 'Needs Revision':
        return 'bg-amber-100 text-amber-800 border-amber-300';
      case 'In Progress':
        return 'bg-indigo-100 text-indigo-800 border-indigo-300';
      default:
        return 'bg-slate-100 text-slate-700 border-slate-300';
    }
  };

  const handleOpenSubmitModal = () => {
    if (userSubmission) {
      setGithubUrl(userSubmission.githubUrl || '');
      setLiveUrl(userSubmission.liveUrl || '');
      setReportNotes(userSubmission.reportNotes || '');
    } else {
      setGithubUrl('');
      setLiveUrl('');
      setReportNotes('');
    }
    setSubmitError(null);
    setShowSubmitModal(true);
  };

  const handleSubmitProof = (e: React.FormEvent) => {
    e.preventDefault();
    if (!githubUrl && !liveUrl) {
      setSubmitError('Please provide at least a GitHub repository URL or a Live Deployed URL.');
      return;
    }
    if (!reportNotes || reportNotes.trim().length < 20) {
      setSubmitError('Please provide detailed engineering report notes (at least 20 characters).');
      return;
    }

    submitProject(selectedProject.id, githubUrl.trim(), liveUrl.trim(), reportNotes.trim());
    setShowSubmitModal(false);

    confetti({
      particleCount: 60,
      spread: 50,
      origin: { y: 0.6 },
    });
  };

  // Filter projects by current department if available
  const deptProjects = projects.filter((p) => p.departmentId === currentUser?.department);
  const displayProjects = deptProjects.length > 0 ? deptProjects : projects;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header Banner */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2">
              <span className="p-2 rounded-xl bg-emerald-50 text-emerald-600">
                <FolderKanban className="w-6 h-6" />
              </span>
              <div>
                <h1 className="text-2xl font-extrabold text-slate-900">
                  Skill-to-Project Bridge
                </h1>
                <p className="text-xs text-slate-500">
                  Practical capstone projects recommended for your department and career path with verified evidence submission
                </p>
              </div>
            </div>
          </div>

          <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-200 text-xs text-slate-600 max-w-sm">
            <strong>Recruiter Standard:</strong> Practical projects with verified faculty evaluations count for{' '}
            <span className="text-blue-700 font-bold">20% of your Placement Readiness Index</span>.
          </div>
        </div>

        {/* Project Selector Pills */}
        <div className="mt-8 border-t border-slate-100 pt-6">
          <p className="text-xs font-semibold text-slate-500 mb-2">Available Department Projects:</p>
          <div className="flex flex-wrap gap-2">
            {displayProjects.map((p) => {
              const isSelected = selectedProjectId === p.id;
              const sub = projectSubmissions.find(
                (s) => s.projectId === p.id && s.studentId === currentUser?.id
              );

              return (
                <button
                  key={p.id}
                  onClick={() => setSelectedProjectId(p.id)}
                  className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all flex items-center gap-2 ${
                    isSelected
                      ? 'bg-emerald-600 text-white shadow-sm shadow-emerald-500/20'
                      : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                  }`}
                >
                  <span>{p.title}</span>
                  {sub && (
                    <span
                      className={`text-[9px] px-1.5 py-0.2 rounded-full font-bold uppercase ${
                        isSelected ? 'bg-white/20 text-white' : 'bg-emerald-100 text-emerald-800'
                      }`}
                    >
                      {sub.status}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Selected Project Full Details */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left 2 Cols: Statement, Milestones, Deliverables */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded">
                    {selectedProject.category}
                  </span>
                  <span className="text-[10px] font-semibold text-slate-500">
                    {selectedProject.difficulty} Level
                  </span>
                </div>
                <h2 className="text-xl sm:text-2xl font-black text-slate-900 mt-1">
                  {selectedProject.title}
                </h2>
              </div>

              {/* Status Badge */}
              <span
                className={`text-xs font-bold px-3 py-1 rounded-full border self-start ${getStatusBadge(
                  userSubmission?.status || 'Not Started'
                )}`}
              >
                {userSubmission?.status || 'Not Started'}
              </span>
            </div>

            {/* Problem Statement */}
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">
                Problem Statement & Context
              </h3>
              <p className="text-xs text-slate-700 leading-relaxed">
                {selectedProject.problemStatement}
              </p>
            </div>

            {/* Tech & Tools */}
            <div>
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">
                Required Technologies & Frameworks
              </h3>
              <div className="flex flex-wrap gap-1.5">
                {selectedProject.toolsAndTech.map((tool, i) => (
                  <span
                    key={i}
                    className="text-xs px-2.5 py-1 rounded-lg bg-blue-50 text-blue-800 font-medium border border-blue-100"
                  >
                    {tool}
                  </span>
                ))}
              </div>
            </div>

            {/* Milestones Checklist */}
            <div className="pt-6 border-t border-slate-100">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-3">
                Project Development Milestones
              </h3>
              <div className="space-y-2.5">
                {selectedProject.milestones.map((m, idx) => (
                  <div
                    key={m.id}
                    className="p-3.5 rounded-xl border border-slate-200 bg-slate-50/50 flex items-start gap-3"
                  >
                    <CheckCircle2
                      className={`w-4 h-4 shrink-0 mt-0.5 ${
                        m.completed ? 'text-emerald-600' : 'text-slate-300'
                      }`}
                    />
                    <div>
                      <p className="text-xs font-bold text-slate-800">
                        Milestone {idx + 1}: {m.title}
                      </p>
                      <p className="text-[11px] text-slate-500 mt-0.5 leading-relaxed">
                        {m.description}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Deliverables & Evaluation Criteria */}
            <div className="pt-6 border-t border-slate-100 grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">
                  Expected Submission Deliverables
                </h3>
                <ul className="text-xs text-slate-700 space-y-1.5">
                  {selectedProject.expectedDeliverables.map((del, i) => (
                    <li key={i} className="flex items-center gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-600"></span>
                      <span>{del}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div>
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">
                  Faculty Evaluation Criteria
                </h3>
                <ul className="text-xs text-slate-700 space-y-1.5">
                  {selectedProject.evaluationCriteria.map((crit, i) => (
                    <li key={i} className="flex items-center gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-purple-600"></span>
                      <span>{crit}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </div>

        {/* Right Col: Submission Status & Faculty Feedback */}
        <div className="space-y-6">
          {/* Submission Action Card */}
          <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-4">
            <h3 className="text-sm font-bold text-slate-900">Your Project Submission Evidence</h3>

            {userSubmission ? (
              <div className="space-y-3">
                <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 text-xs space-y-2">
                  <div>
                    <span className="text-slate-500 block">GitHub Repository:</span>
                    <a
                      href={userSubmission.githubUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-blue-600 font-semibold truncate hover:underline flex items-center gap-1 mt-0.5"
                    >
                      <Github className="w-3.5 h-3.5 shrink-0" />
                      <span className="truncate">{userSubmission.githubUrl}</span>
                    </a>
                  </div>

                  {userSubmission.liveUrl && (
                    <div>
                      <span className="text-slate-500 block">Live Deployed URL:</span>
                      <a
                        href={userSubmission.liveUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-blue-600 font-semibold truncate hover:underline flex items-center gap-1 mt-0.5"
                      >
                        <ExternalLink className="w-3.5 h-3.5 shrink-0" />
                        <span className="truncate">{userSubmission.liveUrl}</span>
                      </a>
                    </div>
                  )}

                  <div>
                    <span className="text-slate-500 block">Report Notes:</span>
                    <p className="text-slate-700 mt-0.5 line-clamp-3 leading-relaxed">
                      {userSubmission.reportNotes}
                    </p>
                  </div>
                </div>

                {/* Faculty Feedback Section if available */}
                {userSubmission.status === 'Approved' && (
                  <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 space-y-2 text-xs">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-emerald-900 flex items-center gap-1">
                        <Award className="w-4 h-4 text-emerald-600" />
                        Faculty Review Score
                      </span>
                      <span className="text-sm font-black text-emerald-800">
                        {userSubmission.gradeScore}/100
                      </span>
                    </div>
                    <p className="text-emerald-800 font-medium leading-relaxed">
                      "{userSubmission.feedback}"
                    </p>
                    <p className="text-[10px] text-emerald-600">
                      Reviewed by: {userSubmission.reviewerName || 'Department Faculty'}
                    </p>
                  </div>
                )}

                {userSubmission.status === 'Needs Revision' && (
                  <div className="p-4 rounded-xl bg-amber-50 border border-amber-200 space-y-2 text-xs">
                    <span className="font-bold text-amber-900">Revision Requested:</span>
                    <p className="text-amber-800 leading-relaxed">"{userSubmission.feedback}"</p>
                  </div>
                )}

                <button
                  onClick={handleOpenSubmitModal}
                  className="w-full py-2.5 rounded-xl border border-slate-300 hover:bg-slate-50 text-slate-700 font-semibold text-xs transition-colors"
                >
                  Update / Re-submit Proof
                </button>
              </div>
            ) : (
              <div className="text-center py-4 space-y-3">
                <p className="text-xs text-slate-500 leading-relaxed">
                  You haven't submitted verifiable evidence for this capstone project yet.
                </p>
                <button
                  onClick={handleOpenSubmitModal}
                  className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs transition-colors flex items-center justify-center gap-2 shadow-xs"
                >
                  <Send className="w-4 h-4" />
                  <span>Submit Project Proof & Links</span>
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Submission Evidence Modal */}
      {showSubmitModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-lg overflow-hidden">
            <div className="p-5 bg-gradient-to-r from-emerald-600 to-teal-600 text-white flex items-center justify-between">
              <div>
                <h3 className="text-base font-bold">Submit Practical Project Evidence</h3>
                <p className="text-emerald-100 text-xs">{selectedProject.title}</p>
              </div>
              <button
                onClick={() => setShowSubmitModal(false)}
                className="text-white/80 hover:text-white"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSubmitProof} className="p-6 space-y-4">
              {submitError && (
                <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{submitError}</span>
                </div>
              )}

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  GitHub Repository URL *
                </label>
                <div className="relative">
                  <Github className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  <input
                    type="url"
                    value={githubUrl}
                    onChange={(e) => setGithubUrl(e.target.value)}
                    placeholder="https://github.com/your-username/repo-name"
                    className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Live Deployed URL (Vercel / Netlify / Render / Power BI)
                </label>
                <div className="relative">
                  <ExternalLink className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  <input
                    type="url"
                    value={liveUrl}
                    onChange={(e) => setLiveUrl(e.target.value)}
                    placeholder="https://your-app.vercel.app"
                    className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Engineering Report Notes & Technical Architecture *
                </label>
                <textarea
                  value={reportNotes}
                  onChange={(e) => setReportNotes(e.target.value)}
                  rows={4}
                  placeholder="Explain database schema design, APIs, security measures implemented, and how you tested edge cases..."
                  className="w-full p-3 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  required
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setShowSubmitModal(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-semibold bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl shadow-xs"
                >
                  Submit for Faculty Review
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
