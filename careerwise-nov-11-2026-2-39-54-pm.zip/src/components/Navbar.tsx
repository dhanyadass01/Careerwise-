import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  GraduationCap,
  Bell,
  LogOut,
  Menu,
  X,
  Compass,
  Map,
  Target,
  GitBranch,
  FolderKanban,
  Mic,
  Award,
  Layers,
  FileText,
  RotateCcw,
  ShieldAlert,
  Users,
  CheckCircle2,
  Sparkles,
  LogIn,
  UserPlus,
  ArrowRight,
} from 'lucide-react';
import { CartoonAvatar } from './CartoonAvatar';

interface NavbarProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  onOpenAuth: () => void;
  onOpenNotifications: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentTab,
  setCurrentTab,
  onOpenAuth,
  onOpenNotifications,
}) => {
  const { currentUser, logout, unreadNotificationCount } = useApp();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [userDropdownOpen, setUserDropdownOpen] = useState(false);

  // Authenticated links for logged-in users
  const loggedInNavLinks = [
    { id: 'dashboard', label: 'Dashboard', icon: GraduationCap },
    { id: 'custom-plan', label: 'My Tailored Plan', icon: Sparkles },
    { id: 'roadmap', label: 'Skill Roadmap', icon: Map },
    { id: 'skill-gap', label: 'Skill Gap Detective', icon: Target },
    { id: 'projects', label: 'Projects Bridge', icon: FolderKanban },
    { id: 'interview-lab', label: 'Interview Lab', icon: Mic },
    { id: 'career-simulator', label: 'Career Simulator', icon: Compass },
    { id: 'placement-zone', label: 'Placement Zone', icon: FileText },
    { id: 'dependency-map', label: 'Dependency Map', icon: GitBranch },
    { id: 'missions', label: 'Missions', icon: CheckCircle2 },
    { id: 'portfolio', label: 'Portfolio', icon: Layers },
    { id: 'certificates', label: 'Certificates', icon: Award },
    { id: 'revision', label: 'Revision', icon: RotateCcw },
  ];

  // Public links for visitors who are not logged in
  const publicNavLinks = [
    { id: 'landing', label: 'Introduction & Overview', icon: GraduationCap },
    { id: 'roadmap', label: 'Skill Curricula', icon: Map },
    { id: 'career-simulator', label: 'Career Paths', icon: Compass },
    { id: 'placement-zone', label: 'Placement Info', icon: FileText },
  ];

  const handleLogout = () => {
    logout();
    setUserDropdownOpen(false);
    setCurrentTab('landing');
  };

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200">
      {/* Main Navbar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div
            className="flex items-center gap-3 cursor-pointer select-none"
            onClick={() => setCurrentTab('landing')}
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-600 via-indigo-600 to-purple-600 flex items-center justify-center text-white shadow-md shadow-blue-500/20">
              <GraduationCap className="w-6 h-6" />
            </div>
            <div>
              <div className="text-xl font-bold bg-gradient-to-r from-blue-700 via-indigo-700 to-purple-700 bg-clip-text text-transparent tracking-tight">
                CareerWise
              </div>
              <div className="text-[10px] text-slate-500 font-medium -mt-1 hidden sm:block">
                Learn • Build • Placement Ready
              </div>
            </div>
          </div>

          {/* Desktop Navigation Links */}
          <nav className="hidden xl:flex items-center gap-1">
            {currentUser ? (
              <>
                {loggedInNavLinks.slice(0, 6).map((link) => {
                  const Icon = link.icon;
                  const isActive = currentTab === link.id;
                  return (
                    <button
                      key={link.id}
                      onClick={() => setCurrentTab(link.id)}
                      className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-medium transition-colors ${
                        isActive
                          ? 'bg-blue-50 text-blue-700 border border-blue-200/60 shadow-xs'
                          : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                      }`}
                    >
                      <Icon className="w-3.5 h-3.5" />
                      <span>{link.label}</span>
                    </button>
                  );
                })}

                {/* More dropdown for extra student tools */}
                <div className="relative group">
                  <button
                    className={`flex items-center gap-1 px-3 py-2 rounded-lg text-xs font-medium ${
                      ['career-simulator', 'placement-zone', 'dependency-map', 'missions', 'portfolio', 'certificates', 'revision'].includes(currentTab)
                        ? 'bg-blue-50 text-blue-700 border border-blue-200'
                        : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                    }`}
                  >
                    <span>More Tools</span>
                    <span className="text-[10px]">▼</span>
                  </button>
                  <div className="absolute right-0 top-full pt-2 hidden group-hover:block z-50">
                    <div className="w-56 bg-white rounded-xl shadow-xl border border-slate-200 py-1.5">
                      {loggedInNavLinks.slice(6).map((link) => {
                        const Icon = link.icon;
                        return (
                          <button
                            key={link.id}
                            onClick={() => setCurrentTab(link.id)}
                            className={`w-full text-left px-4 py-2 text-xs flex items-center gap-2.5 hover:bg-slate-50 ${
                              currentTab === link.id ? 'text-blue-700 font-semibold bg-blue-50/50' : 'text-slate-700'
                            }`}
                          >
                            <Icon className="w-4 h-4 text-slate-500" />
                            <span>{link.label}</span>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                </div>
              </>
            ) : (
              /* Public links when visitor is not logged in */
              publicNavLinks.map((link) => {
                const Icon = link.icon;
                const isActive = currentTab === link.id;
                return (
                  <button
                    key={link.id}
                    onClick={() => setCurrentTab(link.id)}
                    className={`flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-xs font-semibold transition-colors ${
                      isActive
                        ? 'bg-blue-50 text-blue-700 border border-blue-200/60 shadow-xs'
                        : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                    }`}
                  >
                    <Icon className="w-3.5 h-3.5 text-blue-600" />
                    <span>{link.label}</span>
                  </button>
                );
              })
            )}
          </nav>

          {/* Right Action Icons & User Status */}
          <div className="flex items-center gap-2.5">
            {currentUser ? (
              <>
                {/* Notifications Button */}
                <button
                  onClick={onOpenNotifications}
                  className="relative p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors"
                  aria-label="View notifications"
                >
                  <Bell className="w-5 h-5" />
                  {unreadNotificationCount > 0 && (
                    <span className="absolute top-1.5 right-1.5 w-4 h-4 bg-rose-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center animate-bounce">
                      {unreadNotificationCount}
                    </span>
                  )}
                </button>

                {/* My Plan Shortcut */}
                <button
                  onClick={() => setCurrentTab('custom-plan')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                    currentTab === 'custom-plan'
                      ? 'bg-blue-600 text-white shadow-sm'
                      : 'bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200'
                  }`}
                  title="View your customized projects and tasks"
                >
                  <Sparkles className="w-3.5 h-3.5 text-blue-600" />
                  <span className="hidden sm:inline">My Plan</span>
                </button>

                {/* User Dropdown Capsule */}
                <div className="relative">
                  <button
                    onClick={() => setUserDropdownOpen(!userDropdownOpen)}
                    className="flex items-center gap-2 p-1.5 rounded-xl hover:bg-slate-100 transition-colors border border-transparent hover:border-slate-200"
                  >
                    <CartoonAvatar
                      name={currentUser.name}
                      avatarId={currentUser.avatar}
                      size="sm"
                    />
                    <div className="text-left hidden md:block">
                      <div className="text-xs font-bold text-slate-800 leading-tight">
                        {currentUser.name}
                      </div>
                      <div className="text-[10px] text-slate-500 flex items-center gap-1">
                        <span className="uppercase text-blue-600 font-semibold">{currentUser.department || 'STUDENT'}</span>
                        <span>•</span>
                        <span>{currentUser.year || 'College'}</span>
                      </div>
                    </div>
                  </button>

                  {userDropdownOpen && (
                    <div className="absolute right-0 mt-2 w-64 bg-white rounded-2xl shadow-xl border border-slate-200 py-2 z-50 animate-in fade-in slide-in-from-top-1 duration-150">
                      <div className="px-4 py-2.5 border-b border-slate-100 flex items-center gap-3">
                        <CartoonAvatar
                          name={currentUser.name}
                          avatarId={currentUser.avatar}
                          size="md"
                        />
                        <div className="overflow-hidden">
                          <p className="text-xs font-bold text-slate-900 truncate">{currentUser.name}</p>
                          <p className="text-xs text-slate-500 truncate">{currentUser.email}</p>
                          {currentUser.registerNumber && (
                            <p className="text-[11px] text-blue-600 font-semibold mt-0.5">
                              Roll No: {currentUser.registerNumber}
                            </p>
                          )}
                        </div>
                      </div>

                      <div className="py-1">
                        <button
                          onClick={() => {
                            setCurrentTab('custom-plan');
                            setUserDropdownOpen(false);
                          }}
                          className="w-full text-left px-4 py-2 text-xs text-blue-700 font-bold hover:bg-blue-50 flex items-center gap-2"
                        >
                          <Sparkles className="w-4 h-4 text-blue-600" />
                          My Tailored Plan & Tasks
                        </button>
                        <button
                          onClick={() => {
                            setCurrentTab('dashboard');
                            setUserDropdownOpen(false);
                          }}
                          className="w-full text-left px-4 py-2 text-xs text-slate-700 hover:bg-slate-50 flex items-center gap-2"
                        >
                          <GraduationCap className="w-4 h-4 text-slate-400" />
                          Student Dashboard
                        </button>
                        <button
                          onClick={() => {
                            setCurrentTab('portfolio');
                            setUserDropdownOpen(false);
                          }}
                          className="w-full text-left px-4 py-2 text-xs text-slate-700 hover:bg-slate-50 flex items-center gap-2"
                        >
                          <Layers className="w-4 h-4 text-slate-400" />
                          Skill Portfolio
                        </button>
                      </div>

                      <div className="border-t border-slate-100 pt-1 mt-1">
                        <button
                          onClick={handleLogout}
                          className="w-full text-left px-4 py-2 text-xs text-rose-600 hover:bg-rose-50 font-semibold flex items-center gap-2 transition-colors"
                        >
                          <LogOut className="w-4 h-4" />
                          Log Out
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </>
            ) : (
              /* Public State: Log In and Start Learning buttons */
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setCurrentTab('login')}
                  className="px-3.5 py-2 text-xs font-bold rounded-xl text-slate-700 hover:text-slate-900 hover:bg-slate-100 transition-colors flex items-center gap-1.5"
                >
                  <LogIn className="w-3.5 h-3.5 text-slate-500" />
                  <span>Log In</span>
                </button>

                <button
                  onClick={() => setCurrentTab('login')}
                  className="px-4 py-2 text-xs font-bold rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white shadow-md shadow-blue-500/20 transition-all flex items-center gap-1.5"
                >
                  <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                  <span>Start Learning</span>
                </button>
              </div>
            )}

            {/* Mobile menu toggle */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="xl:hidden p-2 text-slate-600 hover:text-slate-900 rounded-lg"
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="xl:hidden border-t border-slate-200 bg-white px-4 pt-3 pb-6 max-h-[80vh] overflow-y-auto space-y-3">
          {currentUser ? (
            <>
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between">
                <div>
                  <p className="text-xs font-bold text-slate-800">{currentUser.name}</p>
                  <p className="text-[11px] text-slate-500">{currentUser.department?.toUpperCase()} • {currentUser.year}</p>
                </div>
                <button
                  onClick={handleLogout}
                  className="px-2.5 py-1 text-xs text-rose-600 hover:bg-rose-50 rounded-md font-semibold flex items-center gap-1"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>Log Out</span>
                </button>
              </div>

              <div className="grid grid-cols-2 gap-1.5">
                {loggedInNavLinks.map((link) => {
                  const Icon = link.icon;
                  const isActive = currentTab === link.id;
                  return (
                    <button
                      key={link.id}
                      onClick={() => {
                        setCurrentTab(link.id);
                        setMobileMenuOpen(false);
                      }}
                      className={`flex items-center gap-2 px-3 py-2.5 rounded-lg text-xs font-medium text-left ${
                        isActive
                          ? 'bg-blue-50 text-blue-700 font-bold border border-blue-200'
                          : 'text-slate-700 hover:bg-slate-100'
                      }`}
                    >
                      <Icon className="w-4 h-4 text-blue-600" />
                      <span>{link.label}</span>
                    </button>
                  );
                })}
              </div>
            </>
          ) : (
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => {
                    setCurrentTab('login');
                    setMobileMenuOpen(false);
                  }}
                  className="w-full py-2.5 rounded-xl bg-blue-600 text-white font-bold text-xs flex items-center justify-center gap-1.5"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>Start Learning</span>
                </button>
                <button
                  onClick={() => {
                    setCurrentTab('login');
                    setMobileMenuOpen(false);
                  }}
                  className="w-full py-2.5 rounded-xl bg-slate-100 text-slate-800 font-semibold text-xs flex items-center justify-center gap-1.5"
                >
                  <LogIn className="w-4 h-4" />
                  <span>Log In</span>
                </button>
              </div>

              <div className="divide-y divide-slate-100">
                {publicNavLinks.map((link) => {
                  const Icon = link.icon;
                  return (
                    <button
                      key={link.id}
                      onClick={() => {
                        setCurrentTab(link.id);
                        setMobileMenuOpen(false);
                      }}
                      className="w-full py-2.5 text-xs text-left text-slate-700 hover:text-blue-600 flex items-center gap-2 font-medium"
                    >
                      <Icon className="w-4 h-4 text-slate-400" />
                      <span>{link.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      )}
    </header>
  );
};
