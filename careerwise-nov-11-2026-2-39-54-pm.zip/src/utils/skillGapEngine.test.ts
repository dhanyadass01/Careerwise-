import test from 'node:test';
import assert from 'node:assert/strict';
import { evaluateProficiency, computeGapLevel, getExpectedProficiency } from './skillGapEngine';

test('evaluateProficiency detects Not Started when no activity', () => {
  const result = evaluateProficiency(undefined);
  assert.equal(result.proficiency, 'Not Started');
  assert.equal(result.hasInsufficientEvidence, true);
  assert.equal(result.score, 0);
});

test('evaluateProficiency flags completed module without quiz as insufficient evidence', () => {
  const result = evaluateProficiency({
    skillId: 's1',
    completedModuleIds: ['m1', 'm2'],
    isCompleted: true,
    quizAttempts: 0,
    lastStudiedAt: '2026-10-23',
  });
  assert.equal(result.hasInsufficientEvidence, true);
  assert.equal(result.proficiency, 'Developing');
});

test('evaluateProficiency recognizes Strong and Mastered with quiz and project evidence', () => {
  const strongResult = evaluateProficiency(
    {
      skillId: 's2',
      completedModuleIds: ['m1'],
      isCompleted: true,
      quizScore: 80,
      quizAttempts: 1,
      lastStudiedAt: '2026-10-23',
    },
    false
  );
  assert.equal(strongResult.proficiency, 'Strong');
  assert.equal(strongResult.hasInsufficientEvidence, false);

  const masteredResult = evaluateProficiency(
    {
      skillId: 's3',
      completedModuleIds: ['m1'],
      isCompleted: true,
      quizScore: 90,
      quizAttempts: 2,
      lastStudiedAt: '2026-10-23',
    },
    true
  );
  assert.equal(masteredResult.proficiency, 'Mastered');
});

test('gap level calculates delta between expected and current proficiency', () => {
  assert.equal(computeGapLevel('Strong', 'Developing'), 'None');
  assert.equal(computeGapLevel('Developing', 'Developing'), 'None');
  assert.equal(computeGapLevel('Needs Improvement', 'Developing'), 'Minor');
  assert.equal(computeGapLevel('Not Started', 'Developing'), 'Moderate');
  assert.equal(computeGapLevel('Not Started', 'Strong'), 'Critical');
});

test('expected proficiency scales with student year vs skill year', () => {
  assert.equal(getExpectedProficiency('1st Year', '3rd Year'), 'Strong');
  assert.equal(getExpectedProficiency('2nd Year', '2nd Year'), 'Developing');
  assert.equal(getExpectedProficiency('3rd Year', '1st Year'), 'Not Started');
});
