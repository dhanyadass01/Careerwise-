import test from 'node:test';
import assert from 'node:assert/strict';
import { generatePersonalizedPlan } from './personalizedRecommendations';

test('generates tailored ML projects and tasks for student with Python and Machine Learning skills', () => {
  const plan = generatePersonalizedPlan('Divya', 'bsc_aiml', '2nd Year', [
    { name: 'Python', proficiency: 'Intermediate' },
    { name: 'Machine Learning', proficiency: 'Beginner' },
  ]);

  assert.ok(plan.projects.length >= 2);
  assert.ok(plan.projects.some((p) => p.title.includes('Predictor') || p.techStack.includes('Scikit-Learn')));
  assert.ok(plan.tasks.some((t) => t.skillTarget === 'Python'));
  assert.ok(plan.suggestions.length > 0);
  assert.ok(plan.projects[0].whyRecommended.includes('Python') || plan.projects[0].whyRecommended.includes('Machine Learning'));
});

test('generates tailored Web projects and custom hooks tasks for student with React and CSS skills', () => {
  const plan = generatePersonalizedPlan('Karthik', 'bsc_cs', '3rd Year', [
    { name: 'React', proficiency: 'Intermediate' },
    { name: 'HTML & CSS', proficiency: 'Advanced' },
  ]);

  assert.ok(plan.projects.some((p) => p.title.includes('Kanban') || p.techStack.includes('React')));
  assert.ok(plan.tasks.some((t) => t.skillTarget === 'React' || t.title.includes('React')));
  assert.ok(plan.suggestions.some((s) => s.type === 'bridge'));
});

test('generates tailored Commerce tax and financial modeling projects for B.Com student with Tally and Excel', () => {
  const plan = generatePersonalizedPlan('Sneha', 'bcom', '2nd Year', [
    { name: 'Advanced Excel', proficiency: 'Intermediate' },
    { name: 'Tally Prime', proficiency: 'Intermediate' },
    { name: 'GST', proficiency: 'Beginner' },
  ]);

  assert.ok(plan.projects.some((p) => p.title.includes('DuPont') || p.title.includes('Reconciliation') || p.techStack.includes('Advanced Excel')));
  assert.ok(plan.tasks.some((t) => t.skillTarget.includes('Excel') || t.skillTarget.includes('GST')));
  assert.ok(plan.suggestions.some((s) => s.skillName.includes('Power BI')));
});

test('generates distinct projects for two students in same department with different skills', () => {
  // Student A: Frontend focused CS student
  const planA = generatePersonalizedPlan('Alice', 'bsc_cs', '2nd Year', [
    { name: 'React', proficiency: 'Intermediate' },
    { name: 'CSS', proficiency: 'Advanced' },
  ]);

  // Student B: Data/ML focused CS student
  const planB = generatePersonalizedPlan('Bob', 'bsc_cs', '2nd Year', [
    { name: 'Python', proficiency: 'Advanced' },
    { name: 'Machine Learning', proficiency: 'Intermediate' },
    { name: 'Pandas', proficiency: 'Intermediate' },
  ]);

  // Make sure project recommendations are different!
  assert.notEqual(planA.projects[0].title, planB.projects[0].title);
  assert.notEqual(planA.tasks[0].title, planB.tasks[0].title);
  assert.ok(planA.projects.some((p) => p.techStack.includes('React')));
  assert.ok(planB.projects.some((p) => p.techStack.includes('Scikit-Learn') || p.techStack.includes('Python')));
});
