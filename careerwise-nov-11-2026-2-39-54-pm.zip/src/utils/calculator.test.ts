import test from 'node:test';
import assert from 'node:assert/strict';
import { calculatePlacementReadiness, getReadinessCategory } from './calculator';

test('placement readiness calculation with perfect scores yields 100% and Highly Placement Ready', () => {
  const result = calculatePlacementReadiness({
    skillCompletion: 100,
    assessmentScore: 100,
    projectScore: 100,
    aptitudeScore: 100,
    communicationScore: 100,
    resumeScore: 100,
    interviewScore: 100,
  });

  assert.equal(result.overallScore, 100);
  assert.equal(result.category, 'Highly Placement Ready');
  assert.equal(result.isFullyAssessed, true);
  assert.equal(result.unassessedComponents.length, 0);
});

test('placement readiness formula calculates weighted components accurately', () => {
  // Skill: 80 * 0.25 = 20
  // Assess: 70 * 0.20 = 14
  // Project: 90 * 0.20 = 18
  // Aptitude: 60 * 0.15 = 9
  // Communication: 80 * 0.10 = 8
  // Resume: 100 * 0.05 = 5
  // Interview: 60 * 0.05 = 3
  // Total = 20 + 14 + 18 + 9 + 8 + 5 + 3 = 77 -> Placement Ready
  const result = calculatePlacementReadiness({
    skillCompletion: 80,
    assessmentScore: 70,
    projectScore: 90,
    aptitudeScore: 60,
    communicationScore: 80,
    resumeScore: 100,
    interviewScore: 60,
  });

  assert.equal(result.overallScore, 77);
  assert.equal(result.category, 'Placement Ready');
});

test('handles missing or unassessed components transparently without silent full marks', () => {
  const result = calculatePlacementReadiness({
    skillCompletion: 40,
    assessmentScore: null,
    projectScore: null,
    aptitudeScore: 50,
    communicationScore: null,
    resumeScore: null,
    interviewScore: null,
  });

  // Skill: 40 * 0.25 = 10
  // Aptitude: 50 * 0.15 = 7.5
  // Total = 17.5 -> 18 -> Beginner
  assert.equal(result.overallScore, 18);
  assert.equal(result.category, 'Beginner');
  assert.equal(result.isFullyAssessed, false);
  assert.equal(result.components.assessmentScore.status, 'Not Assessed');
  assert.equal(result.components.projectScore.status, 'Not Assessed');
  assert.ok(result.unassessedComponents.includes('Assessment Performance (20%)'));
  assert.ok(result.unassessedComponents.includes('Practical Projects (20%)'));
});

test('categories match required threshold boundaries', () => {
  assert.equal(getReadinessCategory(0), 'Beginner');
  assert.equal(getReadinessCategory(39), 'Beginner');
  assert.equal(getReadinessCategory(40), 'Developing');
  assert.equal(getReadinessCategory(59), 'Developing');
  assert.equal(getReadinessCategory(60), 'Placement Ready');
  assert.equal(getReadinessCategory(79), 'Placement Ready');
  assert.equal(getReadinessCategory(80), 'Highly Placement Ready');
  assert.equal(getReadinessCategory(100), 'Highly Placement Ready');
});
