import { PlacementReadinessResult, ReadinessCategory } from '../types';

export interface CalculatorInput {
  skillCompletion?: number | null; // 0-100 or null if not started
  assessmentScore?: number | null; // 0-100 or null if no assessments taken
  projectScore?: number | null; // 0-100 based on completed/approved projects or null
  aptitudeScore?: number | null; // 0-100 or null
  communicationScore?: number | null; // 0-100 or null
  resumeScore?: number | null; // 0-100 or null
  interviewScore?: number | null; // 0-100 or null
}

export function getReadinessCategory(score: number): ReadinessCategory {
  if (score >= 80) return 'Highly Placement Ready';
  if (score >= 60) return 'Placement Ready';
  if (score >= 40) return 'Developing';
  return 'Beginner';
}

export function calculatePlacementReadiness(input: CalculatorInput): PlacementReadinessResult {
  const unassessedComponents: string[] = [];

  const parseComponent = (value: number | null | undefined, name: string) => {
    if (value === null || value === undefined || isNaN(value)) {
      unassessedComponents.push(name);
      return { score: 0, status: 'Not Assessed' };
    }
    const clamped = Math.min(100, Math.max(0, Math.round(value)));
    return { score: clamped, status: `${clamped}%` };
  };

  const skillComp = parseComponent(input.skillCompletion, 'Skill Completion (25%)');
  const assess = parseComponent(input.assessmentScore, 'Assessment Performance (20%)');
  const proj = parseComponent(input.projectScore, 'Practical Projects (20%)');
  const apt = parseComponent(input.aptitudeScore, 'Aptitude Readiness (15%)');
  const comm = parseComponent(input.communicationScore, 'Communication & Soft Skills (10%)');
  const resume = parseComponent(input.resumeScore, 'Resume Completeness (5%)');
  const interview = parseComponent(input.interviewScore, 'Interview Practice (5%)');

  const weightedSkill = skillComp.score * 0.25;
  const weightedAssess = assess.score * 0.20;
  const weightedProj = proj.score * 0.20;
  const weightedApt = apt.score * 0.15;
  const weightedComm = comm.score * 0.10;
  const weightedResume = resume.score * 0.05;
  const weightedInterview = interview.score * 0.05;

  const rawTotal =
    weightedSkill +
    weightedAssess +
    weightedProj +
    weightedApt +
    weightedComm +
    weightedResume +
    weightedInterview;

  const overallScore = Math.min(100, Math.max(0, Math.round(rawTotal)));
  const category = getReadinessCategory(overallScore);

  // Identify biggest improvement areas (ranked by lowest assessed score or unassessed with high weight)
  const breakdownList = [
    { name: 'Skill Completion', score: skillComp.score, status: skillComp.status, weight: 0.25 },
    { name: 'Assessment Score', score: assess.score, status: assess.status, weight: 0.20 },
    { name: 'Project Quality', score: proj.score, status: proj.status, weight: 0.20 },
    { name: 'Aptitude Reasoning', score: apt.score, status: apt.status, weight: 0.15 },
    { name: 'Communication', score: comm.score, status: comm.status, weight: 0.10 },
    { name: 'Resume Completeness', score: resume.score, status: resume.status, weight: 0.05 },
    { name: 'Interview Lab Practice', score: interview.score, status: interview.status, weight: 0.05 },
  ];

  const sortedForImprovement = [...breakdownList].sort((a, b) => {
    // prioritize unassessed or lowest score weighted by impact
    const gapA = (100 - a.score) * a.weight;
    const gapB = (100 - b.score) * b.weight;
    return gapB - gapA;
  });

  const biggestImprovementAreas = sortedForImprovement
    .slice(0, 3)
    .map((item) => `${item.name} (${item.status === 'Not Assessed' ? 'Pending Assessment' : `${item.score}%`})`);

  const recommendedNextActions: string[] = [];
  if (skillComp.score < 60) {
    recommendedNextActions.push('Complete pending modules in your primary roadmap track');
  }
  if (assess.score < 60 || assess.status === 'Not Assessed') {
    recommendedNextActions.push('Attempt skill quizzes to establish verified assessment benchmark');
  }
  if (proj.score < 60 || proj.status === 'Not Assessed') {
    recommendedNextActions.push('Submit a practical capstone project with GitHub evidence');
  }
  if (apt.score < 60 || apt.status === 'Not Assessed') {
    recommendedNextActions.push('Practice quantitative and logical aptitude practice sets in the Placement Zone');
  }
  if (interview.score < 60 || interview.status === 'Not Assessed') {
    recommendedNextActions.push('Complete at least 3 mock interview answers in the Interview Practice Lab');
  }
  if (resume.score < 80) {
    recommendedNextActions.push('Update your resume in Resume Builder to include verified projects and skills');
  }

  return {
    overallScore,
    category,
    isFullyAssessed: unassessedComponents.length === 0,
    unassessedComponents,
    components: {
      skillCompletion: { score: skillComp.score, weighted: Math.round(weightedSkill * 10) / 10, weight: 0.25, status: skillComp.status },
      assessmentScore: { score: assess.score, weighted: Math.round(weightedAssess * 10) / 10, weight: 0.20, status: assess.status },
      projectScore: { score: proj.score, weighted: Math.round(weightedProj * 10) / 10, weight: 0.20, status: proj.status },
      aptitudeScore: { score: apt.score, weighted: Math.round(weightedApt * 10) / 10, weight: 0.15, status: apt.status },
      communicationScore: { score: comm.score, weighted: Math.round(weightedComm * 10) / 10, weight: 0.10, status: comm.status },
      resumeScore: { score: resume.score, weighted: Math.round(weightedResume * 10) / 10, weight: 0.05, status: resume.status },
      interviewScore: { score: interview.score, weighted: Math.round(weightedInterview * 10) / 10, weight: 0.05, status: interview.status },
    },
    biggestImprovementAreas,
    recommendedNextActions: recommendedNextActions.slice(0, 4),
  };
}
