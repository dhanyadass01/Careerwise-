import { ResumeData } from '../types';

export interface ResumeChecklistItem {
  id: string;
  category: string;
  label: string;
  weight: number;
  isComplete: boolean;
  suggestion: string;
}

export function evaluateResume(data: ResumeData): {
  score: number;
  items: ResumeChecklistItem[];
  checklistCompletedCount: number;
  totalChecklistCount: number;
} {
  const items: ResumeChecklistItem[] = [
    {
      id: 'full_name',
      category: 'Contact Info',
      label: 'Full Legal Name',
      weight: 5,
      isComplete: Boolean(data.fullName && data.fullName.trim().length >= 3),
      suggestion: 'Provide your full legal name as it appears on college records.',
    },
    {
      id: 'email_phone',
      category: 'Contact Info',
      label: 'Professional Email & Phone Number',
      weight: 10,
      isComplete: Boolean(data.email?.includes('@') && data.phone?.trim().length >= 8),
      suggestion: 'Include an active phone number and a professional email address.',
    },
    {
      id: 'linkedin',
      category: 'Links',
      label: 'LinkedIn or Professional Profile Link',
      weight: 5,
      isComplete: Boolean(data.linkedin && data.linkedin.trim().startsWith('http')),
      suggestion: 'Add your updated LinkedIn profile link.',
    },
    {
      id: 'github_portfolio',
      category: 'Links',
      label: 'GitHub / Portfolio Link',
      weight: 5,
      isComplete: Boolean(data.githubOrPortfolio && data.githubOrPortfolio.trim().length > 5),
      suggestion: 'Provide a link to your public project repository or portfolio website.',
    },
    {
      id: 'summary',
      category: 'Profile',
      label: 'Professional Summary / Objective (at least 40 words)',
      weight: 10,
      isComplete: Boolean(data.summary && data.summary.trim().split(/\s+/).length >= 15),
      suggestion: 'Write a crisp summary highlighting your technical strengths and career goals.',
    },
    {
      id: 'education',
      category: 'Education',
      label: 'Degree, Department, College & CGPA Details',
      weight: 15,
      isComplete: Boolean(
        data.education?.degree &&
        data.education?.department &&
        data.education?.college &&
        data.education?.cgpa
      ),
      suggestion: 'Detail your current degree, branch, institution name, and latest CGPA/percentage.',
    },
    {
      id: 'skills_count',
      category: 'Skills',
      label: 'At least 5 Relevant Technical or Domain Skills',
      weight: 15,
      isComplete: Boolean(data.skills && data.skills.length >= 5),
      suggestion: 'List at least 5 domain-specific skills (e.g., Python, SQL, Financial Analysis, etc.).',
    },
    {
      id: 'projects_evidence',
      category: 'Projects',
      label: 'At least 2 Practical Projects with Tech & Description',
      weight: 20,
      isComplete: Boolean(
        data.projects &&
        data.projects.length >= 2 &&
        data.projects.every((p) => p.title && p.technologies && p.description?.length > 20)
      ),
      suggestion: 'Include at least 2 practical projects with tools used and measurable impact.',
    },
    {
      id: 'experience_internship',
      category: 'Experience',
      label: 'Internship, Coursework, or Extracurricular Experience',
      weight: 10,
      isComplete: Boolean(data.experienceOrInternships && data.experienceOrInternships.length >= 1),
      suggestion: 'List internships, campus club activities, or academic responsibilities.',
    },
    {
      id: 'certifications',
      category: 'Certifications',
      label: 'Verified Certifications or Course Credentials',
      weight: 5,
      isComplete: Boolean(data.certifications && data.certifications.length >= 1),
      suggestion: 'Add CareerWise or verified external course certifications.',
    },
  ];

  let rawScore = 0;
  let checklistCompletedCount = 0;

  for (const item of items) {
    if (item.isComplete) {
      rawScore += item.weight;
      checklistCompletedCount++;
    }
  }

  const score = Math.min(100, Math.max(0, rawScore));

  return {
    score,
    items,
    checklistCompletedCount,
    totalChecklistCount: items.length,
  };
}
