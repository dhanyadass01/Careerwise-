import { Skill, StudentSkillProgress, AcademicYear } from '../types';

export type ProficiencyLevel = 'Not Started' | 'Needs Improvement' | 'Developing' | 'Strong' | 'Mastered';
export type SkillGapLevel = 'None' | 'Minor' | 'Moderate' | 'Critical';

export interface SkillGapAnalysisItem {
  skillId: string;
  skillTitle: string;
  category: string;
  importance: 'High' | 'Medium' | 'Critical';
  currentProficiency: ProficiencyLevel;
  expectedProficiency: ProficiencyLevel;
  gapLevel: SkillGapLevel;
  scorePercentage: number;
  prerequisites: string[];
  suggestedResources: { title: string; url: string }[];
  recommendedPracticeTasks: string[];
  estimatedLearningEffort: string;
  nextRecommendedAction: string;
  hasInsufficientEvidence: boolean;
}

export function evaluateProficiency(
  progress?: StudentSkillProgress,
  hasProjectEvidence = false
): { proficiency: ProficiencyLevel; hasInsufficientEvidence: boolean; score: number } {
  if (!progress || (progress.completedModuleIds.length === 0 && progress.quizAttempts === 0)) {
    return { proficiency: 'Not Started', hasInsufficientEvidence: true, score: 0 };
  }

  const quizScore = progress.quizScore ?? 0;
  const isModuleDone = progress.isCompleted;

  if (progress.quizAttempts === 0) {
    // Only module clicks without assessment evidence
    return {
      proficiency: isModuleDone ? 'Developing' : 'Needs Improvement',
      hasInsufficientEvidence: true,
      score: isModuleDone ? 40 : 20,
    };
  }

  // Combined assessment and project evidence
  let effectiveScore = quizScore;
  if (hasProjectEvidence) {
    effectiveScore = Math.min(100, effectiveScore + 10);
  }

  if (effectiveScore >= 85 && hasProjectEvidence) {
    return { proficiency: 'Mastered', hasInsufficientEvidence: false, score: effectiveScore };
  }
  if (effectiveScore >= 75) {
    return { proficiency: 'Strong', hasInsufficientEvidence: false, score: effectiveScore };
  }
  if (effectiveScore >= 50) {
    return { proficiency: 'Developing', hasInsufficientEvidence: false, score: effectiveScore };
  }
  return { proficiency: 'Needs Improvement', hasInsufficientEvidence: false, score: effectiveScore };
}

export function getExpectedProficiency(skillYear: AcademicYear, studentYear: AcademicYear): ProficiencyLevel {
  const yearRank = (y: AcademicYear) => (y === '1st Year' ? 1 : y === '2nd Year' ? 2 : 3);
  const diff = yearRank(studentYear) - yearRank(skillYear);

  if (diff > 0) return 'Strong'; // A 3rd year student evaluating 1st/2nd year skills should be Strong
  if (diff === 0) return 'Developing'; // Current year skills expected to be at least Developing
  return 'Not Started'; // Future year skills
}

export function computeGapLevel(current: ProficiencyLevel, expected: ProficiencyLevel): SkillGapLevel {
  const levels: Record<ProficiencyLevel, number> = {
    'Not Started': 0,
    'Needs Improvement': 1,
    'Developing': 2,
    'Strong': 3,
    'Mastered': 4,
  };

  const currentVal = levels[current];
  const expectedVal = levels[expected];
  const delta = expectedVal - currentVal;

  if (delta <= 0) return 'None';
  if (delta === 1) return 'Minor';
  if (delta === 2) return 'Moderate';
  return 'Critical';
}

export function generateSkillGapReport(
  skills: Skill[],
  progressMap: Record<string, StudentSkillProgress>,
  studentYear: AcademicYear,
  projectSkillIds: Set<string> = new Set()
): {
  items: SkillGapAnalysisItem[];
  criticalGapsCount: number;
  overallSummary: string;
} {
  const items: SkillGapAnalysisItem[] = skills.map((skill) => {
    const progress = progressMap[skill.id];
    const hasProjectEvidence = projectSkillIds.has(skill.id) || projectSkillIds.has(skill.title);
    const { proficiency, hasInsufficientEvidence, score } = evaluateProficiency(progress, hasProjectEvidence);
    const expectedProficiency = getExpectedProficiency(skill.year, studentYear);
    const gapLevel = computeGapLevel(proficiency, expectedProficiency);

    let nextRecommendedAction = '';
    let practiceTasks: string[] = [];

    if (proficiency === 'Not Started') {
      nextRecommendedAction = `Start foundational module 1 of ${skill.title} and review prerequisites.`;
      practiceTasks = [
        `Complete beginner introductory lessons for ${skill.title}`,
        `Attempt practice question set #1`,
      ];
    } else if (proficiency === 'Needs Improvement') {
      nextRecommendedAction = `Revise core concepts and retake ${skill.title} quiz to score at least 70%.`;
      practiceTasks = [
        `Review weak topics in revision engine`,
        `Complete 5 targeted practice problems`,
        `Retake skill assessment quiz`,
      ];
    } else if (proficiency === 'Developing') {
      nextRecommendedAction = `Reinforce with practical exercises and build the mini-project: "${skill.miniProjectIdea}".`;
      practiceTasks = [
        `Implement mini-project: ${skill.miniProjectIdea}`,
        `Solve intermediate practice challenge`,
      ];
    } else {
      nextRecommendedAction = `Skill is on track! Apply in major capstone project or assist cohort peers.`;
      practiceTasks = [`Integrate into placement portfolio evidence`];
    }

    return {
      skillId: skill.id,
      skillTitle: skill.title,
      category: skill.category,
      importance: skill.importance,
      currentProficiency: proficiency,
      expectedProficiency,
      gapLevel,
      scorePercentage: score,
      prerequisites: skill.prerequisites,
      suggestedResources: skill.resources.slice(0, 2).map((r) => ({ title: r.title, url: r.url })),
      recommendedPracticeTasks: practiceTasks,
      estimatedLearningEffort: `${skill.estimatedHours} hours`,
      nextRecommendedAction,
      hasInsufficientEvidence,
    };
  });

  const criticalGapsCount = items.filter((i) => i.gapLevel === 'Critical' || i.gapLevel === 'Moderate').length;

  let overallSummary = '';
  if (criticalGapsCount === 0) {
    overallSummary = 'Excellent! You are meeting or exceeding roadmap expectations for your academic year.';
  } else {
    const topGaps = items.filter((i) => i.gapLevel === 'Critical' || i.gapLevel === 'Moderate').slice(0, 3);
    const names = topGaps.map((g) => g.skillTitle).join(', ');
    overallSummary = `Attention needed on ${criticalGapsCount} skill areas (${names}). Focus on recommended practice tasks to close these gaps before campus recruitment drives.`;
  }

  return { items, criticalGapsCount, overallSummary };
}
