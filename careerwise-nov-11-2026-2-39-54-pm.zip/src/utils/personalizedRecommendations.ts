import {
  DepartmentId,
  AcademicYear,
  StudentSkillEntry,
  PersonalizedSkillPlan,
  CustomProjectIdea,
  CustomTask,
  CustomSuggestion,
} from '../types';

export function generatePersonalizedPlan(
  studentName: string,
  department: DepartmentId,
  year: AcademicYear,
  enteredSkills: StudentSkillEntry[]
): PersonalizedSkillPlan {
  const normSkills = (enteredSkills || [])
    .map((s) => {
      const rawName = s.name || s.skillName || '';
      const rawProf = s.proficiency || s.level || 'Intermediate';
      return {
        name: rawName.trim(),
        lower: rawName.trim().toLowerCase(),
        proficiency: rawProf,
      };
    })
    .filter((s) => s.name.length > 0);

  const hasSkill = (keyword: string) =>
    normSkills.some((s) => s.lower.includes(keyword.toLowerCase()));

  const getSkillProficiency = (keyword: string) => {
    const found = normSkills.find((s) => s.lower.includes(keyword.toLowerCase()));
    return found ? found.proficiency : null;
  };

  const skillNamesList = normSkills.map((s) => s.name);
  const primarySkillsStr = skillNamesList.slice(0, 3).join(', ') || 'your core department competencies';

  const projects: CustomProjectIdea[] = [];
  const tasks: CustomTask[] = [];
  const suggestions: CustomSuggestion[] = [];

  // ----------------------------------------------------
  // DOMAIN SPECIFIC LOGIC: SCIENCE (CS, IT, AI/ML)
  // ----------------------------------------------------
  if (department === 'bsc_cs' || department === 'bsc_it' || department === 'bsc_aiml') {
    const hasPython = hasSkill('python');
    const hasReact = hasSkill('react') || hasSkill('javascript') || hasSkill('web');
    const hasSQL = hasSkill('sql') || hasSkill('database') || hasSkill('dbms');
    const hasML = hasSkill('machine learning') || hasSkill('ml') || hasSkill('data') || hasSkill('pandas') || hasSkill('numpy');
    const hasJava = hasSkill('java') || hasSkill('c++') || hasSkill('c');

    if (hasML || department === 'bsc_aiml') {
      projects.push({
        id: `proj_custom_ml_1`,
        title: `Intelligent Customer Churn & Lifetime Value Predictor`,
        difficulty: year === '1st Year' ? 'Beginner' : 'Intermediate',
        techStack: ['Python', 'Pandas', 'Scikit-Learn', 'Streamlit', 'SQL'],
        description: `Construct an end-to-end data pipeline cleaning 10,000+ customer transaction rows, engineering behavioral recency/frequency features, and deploying a predictive classification model.`,
        whyRecommended: `Tailored specifically because you entered ${hasML ? 'Machine Learning/Data skills' : 'Python'}. This establishes a verified predictive modeling project for placement portfolios.`,
        steps: [
          'Perform Exploratory Data Analysis (EDA) with Seaborn to identify high-risk customer attributes',
          'Encode categorical variables and apply StandardScaler to normalize numerical features',
          'Train and evaluate Random Forest vs Logistic Regression using ROC-AUC and F1 scores',
          'Build an interactive Streamlit UI allowing recruiters to input hypothetical customer profiles',
        ],
      });
    }

    if (hasReact || hasSkill('html') || hasSkill('frontend') || hasSkill('web')) {
      projects.push({
        id: `proj_custom_web_1`,
        title: `Enterprise Agile Task Management Board (Kanban SaaS)`,
        difficulty: year === '3rd Year' ? 'Advanced' : 'Intermediate',
        techStack: ['React', 'TypeScript', 'Tailwind CSS', 'Node.js', 'REST APIs'],
        description: `Build a responsive multi-column project board with drag-and-drop task movement, priority tagging, markdown card descriptions, and local state persistence.`,
        whyRecommended: `Tailored because you listed ${hasReact ? 'React/Web Development' : 'Frontend skills'}. Tech recruiters heavily favor candidates with clean component state architecture.`,
        steps: [
          'Design modular card, column, and modal components with Tailwind CSS',
          'Implement optimistic state updates for immediate drag-and-drop task reordering',
          'Add search filtering by assignee, priority tag, and due date',
          'Integrate mock REST API endpoints handling asynchronous saving and error rollbacks',
        ],
      });
    }

    if (hasSQL || hasPython || hasJava || projects.length < 2) {
      projects.push({
        id: `proj_custom_backend_1`,
        title: `Secure Multi-Tenant Campus Placement & Internship Portal`,
        difficulty: year === '1st Year' ? 'Beginner' : 'Advanced',
        techStack: hasPython ? ['Python (FastAPI)', 'PostgreSQL', 'JWT', 'Docker'] : ['Node.js', 'Express', 'SQL', 'JWT'],
        description: `Develop a backend REST service featuring role-based authorization (Student, Faculty, Recruiter), transactional application audits, and PDF resume parsing.`,
        whyRecommended: `Synthesizes your knowledge of ${primarySkillsStr}. Demonstrates relational integrity, password security, and scalable API design.`,
        steps: [
          'Design 3NF relational database schema with foreign keys and index constraints',
          'Implement secure password hashing (Argon2/bcrypt) and HttpOnly JWT cookie authentication',
          'Create pagination and filtering endpoints for 500+ student records',
          'Write unit tests for authentication middleware and business calculation logic',
        ],
      });
    }

    // Fallback if needed to ensure 3 unique projects
    if (projects.length < 3) {
      projects.push({
        id: `proj_custom_alg_1`,
        title: `Algorithmic Network Packet & Shortest Path Visualizer`,
        difficulty: 'Intermediate',
        techStack: ['JavaScript / Python', 'Data Structures', 'Graph Algorithms', 'HTML Canvas'],
        description: `Interactive simulator visualizing Dijkstra, Breadth-First Search (BFS), and A* pathfinding on custom weighted grid topologies.`,
        whyRecommended: `Directly bridges your core programming fundamentals into placement coding round mastery.`,
        steps: [
          'Implement Priority Queue and Adjacency List graph representations from scratch',
          'Build an interactive 30x30 grid allowing users to draw walls and set start/end nodes',
          'Animate node expansion step-by-step with real-time runtime complexity counters',
        ],
      });
    }

    // Tailored Tasks for Science/Tech
    if (hasReact) {
      tasks.push({
        id: `task_react_1`,
        title: 'Build 3 Reusable Custom React Hooks',
        skillTarget: 'React',
        category: 'Frontend Engineering',
        description: 'Construct useDebounce, useLocalStorage, and useFetch custom hooks with clean TypeScript generics and cleanup logic.',
        estimatedHours: 4,
        completed: false,
      });
    }

    if (hasPython) {
      tasks.push({
        id: `task_py_1`,
        title: 'Python Data Structures & List Comprehensions Drill',
        skillTarget: 'Python',
        category: 'Language Proficiency',
        description: 'Solve 8 intermediate coding exercises utilizing dictionaries, sets, tuple unpacking, and zip iteration.',
        estimatedHours: 3,
        completed: false,
      });
    }

    if (hasSQL) {
      tasks.push({
        id: `task_sql_1`,
        title: 'Master Multi-Table SQL Joins & Subqueries',
        skillTarget: 'SQL',
        category: 'Database Mastery',
        description: 'Write 5 non-trivial queries using INNER JOIN, LEFT JOIN, and GROUP BY with HAVING filters on a mock e-commerce database.',
        estimatedHours: 4,
        completed: false,
      });
    } else {
      tasks.push({
        id: `task_sql_bridge`,
        title: 'Learn SQL Relational Fundamentals',
        skillTarget: 'SQL',
        category: 'Skill Gap Bridge',
        description: 'Complete 10 introductory SQL exercises covering SELECT, WHERE, INSERT, and primary key constraints.',
        estimatedHours: 5,
        completed: false,
      });
    }

    tasks.push({
      id: `task_dsa_1`,
      title: 'Placement Coding: Two-Pointers & Sliding Window Patterns',
      skillTarget: 'Problem Solving',
      category: 'Placement Readiness',
      description: 'Solve 5 classic array and string algorithmic interview problems on LeetCode/HackerRank under timed conditions.',
      estimatedHours: 6,
      completed: false,
    });

    tasks.push({
      id: `task_git_1`,
      title: 'Initialize Git Repository with Feature Branching',
      skillTarget: 'Git & GitHub',
      category: 'Evidence Building',
      description: 'Create a clean repository with README documentation, commit conventions, and push your latest code to GitHub.',
      estimatedHours: 2,
      completed: false,
    });

    // Suggestions
    suggestions.push({
      skillName: hasReact ? 'Full Stack Integration' : hasPython ? 'FastAPI / Django Backend' : 'Modern Web Stack',
      type: 'bridge',
      reason: `You have entered strong fundamentals in ${primarySkillsStr}. Connecting frontend components to persistent databases is the #1 criterion recruiters assess for Junior Developers.`,
      actionableAdvice: `Connect your frontend interface to a real database using Prisma or Express. Avoid static mock arrays.`,
      suggestedPractice: `Build a 3-tier CRUD app with authentication and live PostgreSQL deployment.`,
    });

    suggestions.push({
      skillName: 'Algorithmic Problem Solving (DSA)',
      type: 'strengthen',
      reason: `Regardless of framework preferences, campus technical screening rounds test Array manipulation, Hash Maps, and Binary Search.`,
      actionableAdvice: `Practice 1 algorithmic problem daily focusing on explaining time and space complexity out loud.`,
      suggestedPractice: `Review the Top 50 LeetCode patterns in the CareerWise Placement Zone.`,
    });
  }

  // ----------------------------------------------------
  // DOMAIN SPECIFIC LOGIC: COMMERCE (B.COM)
  // ----------------------------------------------------
  else if (department === 'bcom') {
    const hasExcel = hasSkill('excel') || hasSkill('spreadsheet');
    const hasTally = hasSkill('tally') || hasSkill('accounting');
    const hasGST = hasSkill('gst') || hasSkill('tax') || hasSkill('taxation');
    const hasFin = hasSkill('finance') || hasSkill('financial') || hasSkill('analysis') || hasSkill('power bi');

    projects.push({
      id: `proj_custom_bcom_1`,
      title: `Automated 12-Month Financial Statement & DuPont Analysis Model`,
      difficulty: year === '1st Year' ? 'Beginner' : 'Intermediate',
      techStack: ['Advanced Excel', 'XLOOKUP', 'Pivot Tables', 'Financial Modeling'],
      description: `Create an integrated 3-statement financial model (Income Statement, Balance Sheet, Cash Flow) with dynamic scenario selectors and DuPont ROE breakdown.`,
      whyRecommended: `Tailored because you listed ${primarySkillsStr}. Demonstrates corporate financial acumen and spreadsheet modeling to accounting and banking recruiters.`,
      steps: [
        'Synthesize and balance 3-statement historical figures ensuring Assets = Liabilities + Equity',
        'Use XLOOKUP and dynamic INDEX/MATCH arrays to power a multi-year scenario switcher',
        'Decompose Return on Equity (ROE) into Net Profit Margin, Asset Turnover, and Financial Leverage',
        'Build sensitivity data tables analyzing loan interest rates vs operating profit margins',
      ],
    });

    projects.push({
      id: `proj_custom_bcom_2`,
      title: `Corporate GSTR-2B vs Purchase Register Automated Reconciliation`,
      difficulty: 'Intermediate',
      techStack: ['Tally Prime XML', 'Power Query', 'GST Compliance', 'Excel SUMIFS'],
      description: `Build an audit reconciliation engine comparing raw vendor invoices against government GSTR-2B reports to spot uncredited Input Tax Credits (ITC).`,
      whyRecommended: `Directly applies your knowledge in ${hasTally ? 'Tally' : 'Accounting'} and ${hasGST ? 'GST' : 'Corporate Tax'}. This is one of the highest-value competencies for corporate tax firms.`,
      steps: [
        'Ingest raw purchase vouchers and monthly GSTR-2B portal CSV exports',
        'Apply Power Query transformations to normalize supplier GSTINs and invoice numbers',
        'Formulate reconciliation flags (Exact Match, Missing in Books, Missing in Portal, Tax Mismatch)',
        'Generate an executive summary quantifying recoverable Input Tax Credit amounts',
      ],
    });

    projects.push({
      id: `proj_custom_bcom_3`,
      title: `Executive Retail Banking & Working Capital Liquidity Dashboard`,
      difficulty: year === '3rd Year' ? 'Advanced' : 'Intermediate',
      techStack: ['Power BI', 'DAX Measures', 'Cash Flow Analysis', 'Financial Ratios'],
      description: `Build an executive dashboard tracking Cash Conversion Cycle (CCC), Days Sales Outstanding (DSO), Quick Ratios, and working capital trends for commercial banking.`,
      whyRecommended: `Positions you for Corporate Banking, Credit Analyst, and Business Analyst campus recruitment drives.`,
      steps: [
        'Model Star schema connecting Daily Transactions, Customer Accounts, and Calendar dimensions',
        'Write DAX measures for Current Ratio, Acid-Test Ratio, and Cash Conversion Cycle',
        'Design interactive visual slicers for branch performance and credit delinquency aging',
      ],
    });

    // Tasks for B.Com
    tasks.push({
      id: `task_bcom_1`,
      title: 'Master Financial Modeling Functions in Excel (NPV, IRR, PMT)',
      skillTarget: 'Advanced Excel',
      category: 'Financial Modeling',
      description: 'Build a 5-year capital budgeting schedule comparing 2 expansion projects using Net Present Value and Internal Rate of Return.',
      estimatedHours: 4,
      completed: false,
    });

    tasks.push({
      id: `task_bcom_2`,
      title: 'GST Slabs & Inter-State vs Intra-State Invoicing Drill',
      skillTarget: 'GST & Taxation',
      category: 'Corporate Compliance',
      description: 'Prepare 10 practice invoice entries applying correct CGST, SGST, IGST tax ledgers and HSN/SAC codes.',
      estimatedHours: 3,
      completed: false,
    });

    tasks.push({
      id: `task_bcom_3`,
      title: 'Balance Sheet Ratio Interpretation Challenge',
      skillTarget: 'Financial Analysis',
      category: 'Analytical Proficiency',
      description: 'Calculate Debt-to-Equity, Interest Coverage, and Gross Margin for a real listed company and write a 1-page financial health memo.',
      estimatedHours: 4,
      completed: false,
    });

    // Suggestions for B.Com
    suggestions.push({
      skillName: 'Power BI & DAX Dashboards',
      type: 'bridge',
      reason: `You have strong foundations in ${primarySkillsStr}. Modern Big 4 and financial consulting firms expect commerce graduates to present findings in interactive BI dashboards rather than raw spreadsheets.`,
      actionableAdvice: `Export your Excel reconciliations into Power BI desktop and create visual KPI cards with DAX formulas.`,
      suggestedPractice: `Complete the Power BI Financial Analysis module in the CareerWise roadmap.`,
    });
  }

  // ----------------------------------------------------
  // DOMAIN SPECIFIC LOGIC: BUSINESS (BBA)
  // ----------------------------------------------------
  else {
    const hasMktg = hasSkill('marketing') || hasSkill('digital') || hasSkill('seo') || hasSkill('ads');
    const hasSales = hasSkill('sales') || hasSkill('business development') || hasSkill('crm');
    const hasHR = hasSkill('hr') || hasSkill('human resource') || hasSkill('recruitment');

    projects.push({
      id: `proj_custom_bba_1`,
      title: `Omnichannel D2C Brand Launch & Performance Marketing Funnel`,
      difficulty: year === '1st Year' ? 'Beginner' : 'Intermediate',
      techStack: ['Digital Marketing', 'Google Analytics 4', 'Meta Ads Simulator', 'Consumer Psychology'],
      description: `Formulate a complete go-to-market campaign strategy for a direct-to-consumer startup, modeling CAC, ROAS, and conversion funnels across Meta, Google, and email.`,
      whyRecommended: `Tailored because you entered ${primarySkillsStr}. Demonstrates both creative strategy and quantifiable commercial acumen to marketing agencies and FMCG recruiters.`,
      steps: [
        'Construct 2 detailed buyer personas detailing psychographics, pain points, and objections',
        'Draft 6 distinct ad copy variants testing loss-aversion vs social-proof hooks',
        'Allocate a simulated $10,000 monthly budget across Top, Middle, and Bottom-of-Funnel channels',
        'Model Customer Acquisition Cost (CAC) and customer Lifetime Value (LTV) projections',
      ],
    });

    projects.push({
      id: `proj_custom_bba_2`,
      title: `B2B Consultative Sales Playbook & Pipeline CRM Simulator`,
      difficulty: 'Intermediate',
      techStack: ['SPIN Selling', 'HubSpot CRM', 'Outbound Prospecting', 'Objection Handling'],
      description: `Build an enterprise outbound sales playbook using the SPIN questioning technique, cold email cadences, and lead scoring pipeline stages in CRM.`,
      whyRecommended: `Directly builds upon your ${hasSales ? 'Sales & BizDev skills' : 'Management background'}, preparing you for high-paying Business Development Associate campus drives.`,
      steps: [
        'Formulate 12 SPIN discovery questions targeting B2B operational bottlenecks',
        'Write a 3-touch cold outreach email and LinkedIn sequence with tailored value propositions',
        'Develop a structured objection handling matrix for price, timing, and competitor comparisons',
        'Configure lead stages (Prospect, Qualified, Demo, Negotiation, Closed-Won) in CRM',
      ],
    });

    projects.push({
      id: `proj_custom_bba_3`,
      title: `Startup Strategic SWOT & Porter's Five Forces Business Plan`,
      difficulty: 'Beginner',
      techStack: ['Strategic Management', 'Market Research', 'Competitive Benchmarking', 'Financial Feasibility'],
      description: `Analyze an emerging disruptive industry (e.g. Electric Vehicles or EdTech) and produce an investor pitch deck with SWOT, Porter Five Forces, and unit economics.`,
      whyRecommended: `Combines your management principles into a strategic business proposal suitable for consulting and management trainee roles.`,
      steps: [
        'Perform environmental PESTLE and competitive Five Forces threat analysis',
        'Map internal strengths and external market opportunities into a 2x2 SWOT matrix',
        'Draft a 15-slide executive presentation covering business model, marketing, and revenue streams',
      ],
    });

    // Tasks for BBA
    tasks.push({
      id: `task_bba_1`,
      title: 'Digital Marketing CAC to LTV Ratio Analysis',
      skillTarget: 'Digital Marketing',
      category: 'Marketing Metrics',
      description: 'Calculate and evaluate Customer Acquisition Cost (CAC) and Lifetime Value (LTV) for 3 sample subscription businesses.',
      estimatedHours: 3,
      completed: false,
    });

    tasks.push({
      id: `task_bba_2`,
      title: 'Roleplay: SPIN Selling Discovery Call Practice',
      skillTarget: 'Sales & BizDev',
      category: 'Interview & Practical Prep',
      description: 'Practice the SPIN selling methodology in the Interview Practice Lab to handle customer objections with data.',
      estimatedHours: 4,
      completed: false,
    });

    tasks.push({
      id: `task_bba_3`,
      title: 'Conduct an On-Page SEO & Competitor Keyword Audit',
      skillTarget: 'Marketing Strategy',
      category: 'Digital Execution',
      description: 'Audit 2 competitor websites for keyword density, title tags, page speed, and backlink authority.',
      estimatedHours: 4,
      completed: false,
    });

    // Suggestions for BBA
    suggestions.push({
      skillName: 'Data-Driven Business Analytics',
      type: 'bridge',
      reason: `You have demonstrated management competencies in ${primarySkillsStr}. Top employers prioritize business graduates who support intuitive decisions with spreadsheet analytics and KPI metrics.`,
      actionableAdvice: `Incorporate data-driven ROAS, CAC, and conversion ratios into every case presentation.`,
      suggestedPractice: `Complete the Business Analytics module in the CareerWise Placement Zone.`,
    });
  }

  // Enrich items with uniform aliases for components and backward-compatible tests
  const enrichedProjects: CustomProjectIdea[] = projects.map((p, idx) => ({
    ...p,
    targetSkills: p.techStack,
    whyThisProject: p.whyRecommended,
    domain:
      department === 'bcom'
        ? 'Commerce & Accounting'
        : department === 'bba'
        ? 'Business & Marketing'
        : (department as string) === 'btech_ece'
        ? 'Embedded & IoT Systems'
        : 'Software & Data Engineering',
    estimatedTime: p.steps.length > 4 ? '3-4 Weeks' : '2-3 Weeks',
  }));

  const enrichedTasks: CustomTask[] = tasks.map((t) => ({
    ...t,
    actionableOutcome: t.description,
    priority: t.estimatedHours >= 4 ? 'High' : 'Medium',
  }));

  const enrichedSuggestions: CustomSuggestion[] = suggestions.map((s, idx) => ({
    ...s,
    id: `sugg_${idx + 1}`,
    recommendedSkill: s.skillName,
    rationale: s.reason,
    practiceAction: s.actionableAdvice,
    targetCategory: s.type === 'bridge' ? 'Strategic Bridge' : 'Core Deepening',
    expectedTimeline: '2-3 weeks',
  }));

  const summary = `Based on your ${normSkills.length} evaluated skills (${primarySkillsStr}), CareerWise calibrated ${enrichedProjects.length} custom project ideas, ${enrichedTasks.length} priority tasks, and key skill bridge recommendations.`;

  return {
    summary,
    projects: enrichedProjects,
    projectIdeas: enrichedProjects,
    tasks: enrichedTasks,
    customTasks: enrichedTasks,
    suggestions: enrichedSuggestions,
  };
}
