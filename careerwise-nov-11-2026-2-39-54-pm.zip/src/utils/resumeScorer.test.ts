import test from 'node:test';
import assert from 'node:assert/strict';
import { evaluateResume } from './resumeScorer';

test('empty resume yields 0 score and incomplete checklist', () => {
  const result = evaluateResume({
    fullName: '',
    email: '',
    phone: '',
    linkedin: '',
    githubOrPortfolio: '',
    summary: '',
    education: { degree: '', department: '', college: '', year: '', cgpa: '' },
    skills: [],
    projects: [],
    experienceOrInternships: [],
    certifications: [],
  });

  assert.equal(result.score, 0);
  assert.equal(result.checklistCompletedCount, 0);
  assert.equal(result.totalChecklistCount, 10);
});

test('comprehensive resume yields 100 score and all checklist items satisfied', () => {
  const result = evaluateResume({
    fullName: 'Aarav Sharma',
    email: 'aarav.sharma@example.edu',
    phone: '+91 98765 43210',
    linkedin: 'https://linkedin.com/in/aarav-sharma',
    githubOrPortfolio: 'https://github.com/aarav-sharma',
    summary: 'Results-driven computer science student with a strong foundation in full-stack web development and cloud architectures. Passionate about building robust systems and scalable APIs.',
    education: {
      degree: 'B.Sc Computer Science',
      department: 'Computer Science',
      college: 'National College of Engineering and Technology',
      year: '3rd Year',
      cgpa: '8.9 / 10',
    },
    skills: ['Python', 'Java', 'React', 'TypeScript', 'PostgreSQL', 'Git', 'Docker'],
    projects: [
      {
        title: 'Student Placement Prediction Portal',
        technologies: 'React, Node.js, PostgreSQL, Tailwind',
        description: 'Engineered a full-stack campus readiness analyzer tracking 500+ student milestone submissions with automated analytics.',
        link: 'https://github.com/aarav/placement-prep',
      },
      {
        title: 'Distributed File Storage Service',
        technologies: 'Go, Docker, AWS S3',
        description: 'Built a resilient multi-node file synchronization tool handling concurrent multipart uploads with SHA256 integrity verification.',
      },
    ],
    experienceOrInternships: [
      {
        role: 'Full Stack Engineering Intern',
        company: 'CloudCraft Solutions',
        duration: 'June 2025 - August 2025',
        details: 'Designed REST endpoints and optimized database queries reducing API latency by 35%.',
      },
    ],
    certifications: ['CareerWise Full Stack Web Development Specialization'],
  });

  assert.equal(result.score, 100);
  assert.equal(result.checklistCompletedCount, 10);
});
