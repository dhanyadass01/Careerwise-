export type UserRole = 'student' | 'faculty' | 'admin';

export type DepartmentId =
  | 'bsc_cs'
  | 'bsc_it'
  | 'bsc_aiml'
  | 'bcom'
  | 'bba';

export type AcademicYear = '1st Year' | '2nd Year' | '3rd Year';

export type ReadinessCategory = 'Beginner' | 'Developing' | 'Placement Ready' | 'Highly Placement Ready';

export type ProjectStatus = 'Not Started' | 'In Progress' | 'Submitted' | 'Needs Revision' | 'Approved' | 'Completed';

export type SkillLevel = 'Beginner' | 'Intermediate' | 'Advanced';

export interface StudentSkillEntry {
  name: string;
  proficiency: SkillLevel;
  skillName?: string;
  level?: SkillLevel;
  category?: string;
}

export interface CustomProjectIdea {
  id: string;
  title: string;
  difficulty: SkillLevel;
  techStack: string[];
  targetSkills?: string[];
  description: string;
  whyRecommended: string;
  whyThisProject?: string;
  steps: string[];
  domain?: string;
  estimatedTime?: string;
}

export interface CustomTask {
  id: string;
  title: string;
  skillTarget: string;
  category: string;
  description: string;
  actionableOutcome?: string;
  estimatedHours: number;
  completed: boolean;
  priority?: 'High' | 'Medium' | 'Normal';
}

export interface CustomSuggestion {
  id?: string;
  skillName: string;
  recommendedSkill?: string;
  type: 'strengthen' | 'bridge' | 'next_level';
  targetCategory?: string;
  reason: string;
  rationale?: string;
  actionableAdvice: string;
  practiceAction?: string;
  suggestedPractice: string;
  expectedTimeline?: string;
}

export interface PersonalizedSkillPlan {
  summary?: string;
  projects: CustomProjectIdea[];
  projectIdeas: CustomProjectIdea[];
  tasks: CustomTask[];
  customTasks: CustomTask[];
  suggestions: CustomSuggestion[];
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  registerNumber?: string;
  phone?: string;
  department?: DepartmentId;
  year?: AcademicYear;
  careerInterests?: string[];
  targetCareerPathId?: string;
  avatar?: string;
  isDemo?: boolean;
  enteredSkills?: StudentSkillEntry[];
}

export interface DepartmentInfo {
  id: DepartmentId;
  name: string;
  shortName: string;
  category: 'Science' | 'Commerce' | 'Business';
  description: string;
  years: AcademicYear[];
}

export interface SkillModule {
  id: string;
  title: string;
  duration: string;
  description: string;
  content: string;
}

export interface ResourceLink {
  title: string;
  type: 'video' | 'documentation' | 'article' | 'cheatsheet';
  url: string;
  duration?: string;
}

export interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctAnswerIndex: number;
  explanation: string;
  topic: string;
}

export interface Skill {
  id: string;
  title: string;
  departmentId: DepartmentId;
  year: AcademicYear;
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced';
  category: 'Technical' | 'Core' | 'Analytical' | 'Soft Skills' | 'Placement';
  estimatedHours: number;
  description: string;
  learningObjectives: string[];
  modules: SkillModule[];
  resources: ResourceLink[];
  prerequisites: string[];
  unlocksSkills: string[];
  quiz: QuizQuestion[];
  miniProjectIdea: string;
  importance: 'High' | 'Medium' | 'Critical';
}

export interface RoadmapLevel {
  year: AcademicYear;
  stageName: string;
  description: string;
  skills: Skill[];
}

export interface CareerPath {
  id: string;
  title: string;
  departments: DepartmentId[];
  description: string;
  requiredSkillIds: string[];
  recommendedProjects: string[];
  assessmentRequirement: string;
  portfolioRequirements: string[];
  interviewTopics: string[];
  avgPackageLPA: string;
  demandLevel: 'High' | 'Very High' | 'High Growth';
}

export interface ProjectMilestone {
  id: string;
  title: string;
  description: string;
  completed: boolean;
}

export interface Project {
  id: string;
  title: string;
  departmentId: DepartmentId;
  year: AcademicYear;
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced';
  category: string;
  problemStatement: string;
  requiredSkills: string[];
  toolsAndTech: string[];
  learningObjectives: string[];
  milestones: ProjectMilestone[];
  expectedDeliverables: string[];
  evaluationCriteria: string[];
  careerPathIds: string[];
}

export interface ProjectSubmission {
  id: string;
  projectId: string;
  studentId: string;
  studentName: string;
  departmentId: DepartmentId;
  githubUrl: string;
  liveUrl?: string;
  reportNotes: string;
  status: ProjectStatus;
  submittedAt: string;
  reviewedAt?: string;
  reviewerName?: string;
  feedback?: string;
  gradeScore?: number; // 0-100
}

export interface MissionTask {
  id: string;
  title: string;
  completed: boolean;
}

export interface CareerMission {
  id: string;
  title: string;
  departmentId: DepartmentId;
  year: AcademicYear;
  weekNumber: number;
  badgeName: string;
  badgeIcon: string;
  description: string;
  tasks: MissionTask[];
  deliverableDescription: string;
  points: number;
  deadlineDays: number;
}

export interface MissionSubmission {
  id: string;
  missionId: string;
  studentId: string;
  completedTaskIds: string[];
  evidenceText: string;
  evidenceUrl?: string;
  status: 'Completed' | 'In Progress';
  submittedAt: string;
}

export interface StudentSkillProgress {
  skillId: string;
  completedModuleIds: string[];
  isCompleted: boolean;
  quizScore?: number; // percentage 0-100
  quizAttempts: number;
  lastStudiedAt: string;
}

export interface QuizAttempt {
  id: string;
  quizId: string;
  skillId: string;
  studentId: string;
  score: number; // percentage
  correctCount: number;
  totalQuestions: number;
  answers: { questionIndex: number; selectedOption: number; isCorrect: boolean }[];
  weakTopics: string[];
  strongTopics: string[];
  completedAt: string;
}

export interface InterviewQuestion {
  id: string;
  category: 'HR' | 'Technical' | 'Aptitude' | 'Communication' | 'Project Explanation';
  departmentId?: DepartmentId | 'all';
  question: string;
  sampleAnswerGuide: string;
  evaluationRubric: {
    keyPoints: string[];
    suggestedStructure: string;
  };
}

export interface InterviewPracticeRecord {
  id: string;
  studentId: string;
  questionId: string;
  questionText: string;
  category: string;
  submittedAnswer: string;
  timeSpentSeconds: number;
  score: number; // 0-100
  feedback: {
    strongAreas: string[];
    missingConcepts: string[];
    revisionRecommendation: string;
  };
  practicedAt: string;
}

export interface RevisionItem {
  id: string;
  skillId: string;
  skillName: string;
  topic: string;
  conceptSummary: string;
  sampleQuestion: string;
  sampleAnswer: string;
  lastScore: number;
  recommendedReviewDate: string;
  masteryLevel: 'Needs Review' | 'Reinforcing' | 'Mastered';
}

export interface ResumeData {
  fullName: string;
  email: string;
  phone: string;
  linkedin: string;
  githubOrPortfolio: string;
  summary: string;
  education: {
    degree: string;
    college: string;
    department: string;
    year: string;
    cgpa: string;
  };
  skills: string[];
  projects: {
    title: string;
    technologies: string;
    description: string;
    link?: string;
  }[];
  experienceOrInternships: {
    role: string;
    company: string;
    duration: string;
    details: string;
  }[];
  certifications: string[];
}

export interface Certificate {
  id: string;
  certificateNumber: string;
  studentId: string;
  studentName: string;
  department: string;
  skillOrCourseTitle: string;
  issueDate: string;
  verificationUrl: string;
  criteriaMet: string[];
  signatureSigner: string;
}

export interface AppNotification {
  id: string;
  userId: string;
  title: string;
  message: string;
  type: 'assessment' | 'project' | 'mission' | 'certificate' | 'training' | 'reminder';
  link?: string;
  read: boolean;
  createdAt: string;
}

export interface TrainingSession {
  id: string;
  title: string;
  departmentId: DepartmentId;
  year: AcademicYear;
  trainer: string;
  date: string;
  time: string;
  locationOrUrl: string;
  targetSkill: string;
  description: string;
  preTrainingAvgScore?: number;
  postTrainingAvgScore?: number;
  attendeesCount: number;
}

export interface PlacementReadinessResult {
  overallScore: number;
  category: ReadinessCategory;
  isFullyAssessed: boolean;
  unassessedComponents: string[];
  components: {
    skillCompletion: { score: number; weighted: number; weight: 0.25; status: string };
    assessmentScore: { score: number; weighted: number; weight: 0.20; status: string };
    projectScore: { score: number; weighted: number; weight: 0.20; status: string };
    aptitudeScore: { score: number; weighted: number; weight: 0.15; status: string };
    communicationScore: { score: number; weighted: number; weight: 0.10; status: string };
    resumeScore: { score: number; weighted: number; weight: 0.05; status: string };
    interviewScore: { score: number; weighted: number; weight: 0.05; status: string };
  };
  biggestImprovementAreas: string[];
  recommendedNextActions: string[];
}
