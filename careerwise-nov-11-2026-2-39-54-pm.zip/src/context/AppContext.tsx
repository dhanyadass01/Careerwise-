import React, { createContext, useContext, useState, useEffect, useMemo, ReactNode } from 'react';
import {
  User,
  DepartmentId,
  AcademicYear,
  Skill,
  CareerPath,
  Project,
  CareerMission,
  InterviewQuestion,
  InterviewPracticeRecord,
  ProjectSubmission,
  StudentSkillProgress,
  ResumeData,
  TrainingSession,
  AppNotification,
  Certificate,
  RevisionItem,
  PlacementReadinessResult,
  StudentSkillEntry,
  PersonalizedSkillPlan,
} from '../types';
import {
  DEPARTMENTS,
  INITIAL_SKILLS,
  INITIAL_CAREER_PATHS,
  INITIAL_PROJECTS,
  INITIAL_CAREER_MISSIONS,
  INITIAL_INTERVIEW_QUESTIONS,
  INITIAL_REVISION_ITEMS,
  DEMO_USERS,
  INITIAL_PROGRESS_MAP,
  INITIAL_PROJECT_SUBMISSIONS,
  INITIAL_TRAINING_SESSIONS,
  INITIAL_NOTIFICATIONS,
  INITIAL_CERTIFICATES,
  INITIAL_RESUME_DATA,
} from '../data/seedData';
import { calculatePlacementReadiness } from '../utils/calculator';
import { generateSkillGapReport, SkillGapAnalysisItem } from '../utils/skillGapEngine';
import { evaluateResume } from '../utils/resumeScorer';
import { generatePersonalizedPlan } from '../utils/personalizedRecommendations';
import { getAvatarStyleFromName } from '../components/CartoonAvatar';

interface AppContextType {
  currentUser: User | null;
  users: User[];
  departments: typeof DEPARTMENTS;
  skills: Skill[];
  careerPaths: CareerPath[];
  projects: Project[];
  careerMissions: CareerMission[];
  interviewQuestions: InterviewQuestion[];
  revisionItems: RevisionItem[];
  progressMap: Record<string, StudentSkillProgress>;
  projectSubmissions: ProjectSubmission[];
  trainingSessions: TrainingSession[];
  notifications: AppNotification[];
  certificates: Certificate[];
  resumeData: ResumeData | null;
  isPortfolioPublic: boolean;
  selectedCareerPath: CareerPath | null;
  readinessResult: PlacementReadinessResult;
  skillGapReport: {
    items: SkillGapAnalysisItem[];
    criticalGapsCount: number;
    overallSummary: string;
  };
  unreadNotificationCount: number;

  // Personalized Skill Plan & Custom Tasks
  customSkillPlan: PersonalizedSkillPlan | null;
  completedCustomTaskIds: string[];
  toggleCustomTask: (taskId: string) => void;
  loginWithSkills: (data: {
    name: string;
    department: DepartmentId;
    year: AcademicYear;
    skills: StudentSkillEntry[];
    email?: string;
    registerNumber?: string;
    avatar?: string;
  }) => { success: boolean; user: User };
  updateCurrentUserSkills: (skills: StudentSkillEntry[]) => void;

  // Actions
  login: (email: string, password?: string) => { success: boolean; error?: string };
  registerStudent: (formData: {
    name: string;
    email: string;
    registerNumber: string;
    phone: string;
    department: DepartmentId;
    year: AcademicYear;
    password: string;
    careerInterests: string[];
  }) => { success: boolean; error?: string };
  logout: () => void;
  switchDemoUser: (userId: string) => void;
  completeSkillModule: (skillId: string, moduleId: string) => void;
  submitQuizScore: (skillId: string, scorePercentage: number) => void;
  submitProject: (projectId: string, githubUrl: string, liveUrl: string, notes: string) => void;
  reviewProjectSubmission: (
    submissionId: string,
    status: 'Approved' | 'Needs Revision',
    gradeScore: number,
    feedback: string
  ) => void;
  submitMissionTask: (missionId: string, taskId: string, completed: boolean) => void;
  submitMissionEvidence: (missionId: string, evidenceText: string, evidenceUrl?: string) => void;
  saveInterviewPractice: (record: Omit<InterviewPracticeRecord, 'id' | 'practicedAt'>) => void;
  updateResumeData: (data: ResumeData) => void;
  generateCertificateForSkill: (skillOrCourseTitle: string) => Certificate;
  togglePortfolioPublic: (isPublic: boolean) => void;
  setTargetCareerPath: (pathId: string) => void;
  markNotificationAsRead: (notificationId: string) => void;
  markAllNotificationsAsRead: () => void;
  addOrUpdateSkill: (skill: Skill) => void;
  addOrUpdateProject: (project: Project) => void;
  addOrUpdateMission: (mission: CareerMission) => void;
  createTrainingSession: (session: Omit<TrainingSession, 'id'>) => void;
  resetAllData: () => void;
}

const AppContext = createContext<AppContextType | null>(null);

const STORAGE_KEY_PREFIX = 'careerwise_storage_v1';

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  // Users state (starts clean without demo accounts)
  const [users, setUsers] = useState<User[]>(() => {
    try {
      const stored = localStorage.getItem(`${STORAGE_KEY_PREFIX}_users`);
      if (stored) {
        const parsed: User[] = JSON.parse(stored);
        const DEMO_IDS = ['std_aarav', 'std_priya', 'std_rohan', 'std_ananya', 'std_dev', 'fac_sharma', 'adm_verma'];
        return parsed.filter((u) => !u.isDemo && !DEMO_IDS.includes(u.id));
      }
      return [];
    } catch {
      return [];
    }
  });

  const [currentUserId, setCurrentUserId] = useState<string>(() => {
    try {
      const stored = localStorage.getItem(`${STORAGE_KEY_PREFIX}_current_user_id`);
      const DEMO_IDS = ['std_aarav', 'std_priya', 'std_rohan', 'std_ananya', 'std_dev', 'fac_sharma', 'adm_verma'];
      if (stored && !DEMO_IDS.includes(stored)) {
        return stored;
      }
      return '';
    } catch {
      return '';
    }
  });

  const currentUser = useMemo(() => {
    if (!currentUserId) return null;
    return users.find((u) => u.id === currentUserId) || null;
  }, [users, currentUserId]);

  // Skills state
  const [skills, setSkills] = useState<Skill[]>(() => {
    try {
      const stored = localStorage.getItem(`${STORAGE_KEY_PREFIX}_skills`);
      return stored ? JSON.parse(stored) : INITIAL_SKILLS;
    } catch {
      return INITIAL_SKILLS;
    }
  });

  // Projects state
  const [projects, setProjects] = useState<Project[]>(() => {
    try {
      const stored = localStorage.getItem(`${STORAGE_KEY_PREFIX}_projects`);
      return stored ? JSON.parse(stored) : INITIAL_PROJECTS;
    } catch {
      return INITIAL_PROJECTS;
    }
  });

  // Missions state
  const [careerMissions, setCareerMissions] = useState<CareerMission[]>(() => {
    try {
      const stored = localStorage.getItem(`${STORAGE_KEY_PREFIX}_missions`);
      return stored ? JSON.parse(stored) : INITIAL_CAREER_MISSIONS;
    } catch {
      return INITIAL_CAREER_MISSIONS;
    }
  });

  // Submissions state
  const [projectSubmissions, setProjectSubmissions] = useState<ProjectSubmission[]>(() => {
    try {
      const stored = localStorage.getItem(`${STORAGE_KEY_PREFIX}_submissions`);
      return stored ? JSON.parse(stored) : INITIAL_PROJECT_SUBMISSIONS;
    } catch {
      return INITIAL_PROJECT_SUBMISSIONS;
    }
  });

  // User Skill Progress Map: Record<userId, Record<skillId, StudentSkillProgress>>
  const [allProgress, setAllProgress] = useState<Record<string, Record<string, StudentSkillProgress>>>(() => {
    try {
      const stored = localStorage.getItem(`${STORAGE_KEY_PREFIX}_progress`);
      return stored ? JSON.parse(stored) : INITIAL_PROGRESS_MAP;
    } catch {
      return INITIAL_PROGRESS_MAP;
    }
  });

  // Notifications
  const [notifications, setNotifications] = useState<AppNotification[]>(() => {
    try {
      const stored = localStorage.getItem(`${STORAGE_KEY_PREFIX}_notifications`);
      return stored ? JSON.parse(stored) : INITIAL_NOTIFICATIONS;
    } catch {
      return INITIAL_NOTIFICATIONS;
    }
  });

  // Certificates
  const [certificates, setCertificates] = useState<Certificate[]>(() => {
    try {
      const stored = localStorage.getItem(`${STORAGE_KEY_PREFIX}_certificates`);
      return stored ? JSON.parse(stored) : INITIAL_CERTIFICATES;
    } catch {
      return INITIAL_CERTIFICATES;
    }
  });

  // Training Sessions
  const [trainingSessions, setTrainingSessions] = useState<TrainingSession[]>(() => {
    try {
      const stored = localStorage.getItem(`${STORAGE_KEY_PREFIX}_training`);
      return stored ? JSON.parse(stored) : INITIAL_TRAINING_SESSIONS;
    } catch {
      return INITIAL_TRAINING_SESSIONS;
    }
  });

  // Resumes
  const [allResumes, setAllResumes] = useState<Record<string, ResumeData>>(() => {
    try {
      const stored = localStorage.getItem(`${STORAGE_KEY_PREFIX}_resumes`);
      return stored ? JSON.parse(stored) : INITIAL_RESUME_DATA;
    } catch {
      return INITIAL_RESUME_DATA;
    }
  });

  // Portfolio Privacy
  const [portfolioPrivacy, setPortfolioPrivacy] = useState<Record<string, boolean>>(() => {
    try {
      const stored = localStorage.getItem(`${STORAGE_KEY_PREFIX}_portfolio_privacy`);
      return stored ? JSON.parse(stored) : { std_aarav: true, std_priya: false };
    } catch {
      return { std_aarav: true, std_priya: false };
    }
  });

  // Custom Completed Tasks per student
  const [completedCustomTasks, setCompletedCustomTasks] = useState<Record<string, string[]>>(() => {
    try {
      const stored = localStorage.getItem(`${STORAGE_KEY_PREFIX}_custom_tasks`);
      return stored ? JSON.parse(stored) : {};
    } catch {
      return {};
    }
  });

  // Persist whenever state changes
  useEffect(() => {
    try {
      localStorage.setItem(`${STORAGE_KEY_PREFIX}_users`, JSON.stringify(users));
      localStorage.setItem(`${STORAGE_KEY_PREFIX}_current_user_id`, currentUserId);
      localStorage.setItem(`${STORAGE_KEY_PREFIX}_skills`, JSON.stringify(skills));
      localStorage.setItem(`${STORAGE_KEY_PREFIX}_projects`, JSON.stringify(projects));
      localStorage.setItem(`${STORAGE_KEY_PREFIX}_missions`, JSON.stringify(careerMissions));
      localStorage.setItem(`${STORAGE_KEY_PREFIX}_submissions`, JSON.stringify(projectSubmissions));
      localStorage.setItem(`${STORAGE_KEY_PREFIX}_progress`, JSON.stringify(allProgress));
      localStorage.setItem(`${STORAGE_KEY_PREFIX}_notifications`, JSON.stringify(notifications));
      localStorage.setItem(`${STORAGE_KEY_PREFIX}_certificates`, JSON.stringify(certificates));
      localStorage.setItem(`${STORAGE_KEY_PREFIX}_training`, JSON.stringify(trainingSessions));
      localStorage.setItem(`${STORAGE_KEY_PREFIX}_resumes`, JSON.stringify(allResumes));
      localStorage.setItem(`${STORAGE_KEY_PREFIX}_portfolio_privacy`, JSON.stringify(portfolioPrivacy));
      localStorage.setItem(`${STORAGE_KEY_PREFIX}_custom_tasks`, JSON.stringify(completedCustomTasks));
    } catch {
      // storage quota or incognito fallback
    }
  }, [
    users,
    currentUserId,
    skills,
    projects,
    careerMissions,
    projectSubmissions,
    allProgress,
    notifications,
    certificates,
    trainingSessions,
    allResumes,
    portfolioPrivacy,
    completedCustomTasks,
  ]);

  // Personalized Skill Plan dynamically computed for the logged in user based on their entered skills
  const customSkillPlan = useMemo<PersonalizedSkillPlan | null>(() => {
    if (!currentUser || currentUser.role !== 'student') return null;
    const studentSkills = currentUser.enteredSkills || [];
    return generatePersonalizedPlan(
      currentUser.name,
      currentUser.department || 'bsc_cs',
      currentUser.year || '3rd Year',
      studentSkills
    );
  }, [currentUser]);

  const completedCustomTaskIds = useMemo(() => {
    if (!currentUser) return [];
    return completedCustomTasks[currentUser.id] || [];
  }, [completedCustomTasks, currentUser]);

  const userProgressMap = useMemo(() => {
    return (currentUser && allProgress[currentUser.id]) || {};
  }, [allProgress, currentUser]);

  const resumeData = useMemo(() => {
    if (!currentUser) return null;
    return (
      allResumes[currentUser.id] || {
        fullName: currentUser.name,
        email: currentUser.email,
        phone: currentUser.phone || '',
        linkedin: '',
        githubOrPortfolio: '',
        summary: '',
        education: {
          degree: DEPARTMENTS.find((d) => d.id === currentUser.department)?.name || '',
          department: currentUser.department || '',
          college: 'National College of Engineering & Technology',
          year: currentUser.year || '1st Year',
          cgpa: '8.5 / 10',
        },
        skills: currentUser.careerInterests || [],
        projects: [],
        experienceOrInternships: [],
        certifications: [],
      }
    );
  }, [allResumes, currentUser]);

  const isPortfolioPublic = useMemo(() => {
    if (!currentUser) return false;
    return Boolean(portfolioPrivacy[currentUser.id]);
  }, [portfolioPrivacy, currentUser]);

  const selectedCareerPath = useMemo(() => {
    if (!currentUser?.targetCareerPathId) return INITIAL_CAREER_PATHS[0];
    return INITIAL_CAREER_PATHS.find((cp) => cp.id === currentUser.targetCareerPathId) || INITIAL_CAREER_PATHS[0];
  }, [currentUser]);

  // Compute Placement Readiness Score based on exact formula
  const readinessResult = useMemo<PlacementReadinessResult>(() => {
    if (!currentUser || currentUser.role !== 'student') {
      return calculatePlacementReadiness({
        skillCompletion: 75,
        assessmentScore: 78,
        projectScore: 80,
        aptitudeScore: 75,
        communicationScore: 70,
        resumeScore: 80,
        interviewScore: 75,
      });
    }

    // 1. Skill Completion (0-100)
    const deptSkills = skills.filter((s) => s.departmentId === currentUser.department);
    let skillCompletionScore: number | null = null;
    if (deptSkills.length > 0) {
      let completedCount = 0;
      deptSkills.forEach((s) => {
        const prog = userProgressMap[s.id];
        if (prog?.isCompleted) completedCount++;
      });
      skillCompletionScore = Math.round((completedCount / deptSkills.length) * 100);
    }

    // 2. Assessment Score (0-100)
    const quizEntries = Object.values(userProgressMap).filter((p) => typeof p.quizScore === 'number' && p.quizAttempts > 0);
    let assessmentScore: number | null = null;
    if (quizEntries.length > 0) {
      const avg = quizEntries.reduce((acc, curr) => acc + (curr.quizScore || 0), 0) / quizEntries.length;
      assessmentScore = Math.round(avg);
    }

    // 3. Project Score (0-100)
    const userSubmissions = projectSubmissions.filter(
      (sub) => sub.studentId === currentUser.id && (sub.status === 'Approved' || sub.status === 'Submitted')
    );
    let projectScore: number | null = null;
    if (userSubmissions.length > 0) {
      const avgGrade =
        userSubmissions.reduce((acc, s) => acc + (s.gradeScore ?? 75), 0) / userSubmissions.length;
      projectScore = Math.round(avgGrade);
    }

    // 4. Aptitude Score
    const aptitudeProgress = userProgressMap['cs_problem_solving'] || userProgressMap['cs_prog_fund'];
    const aptitudeScore = aptitudeProgress?.quizScore ?? 70;

    // 5. Communication Score
    const commScore = 75; // baseline from coursework/missions

    // 6. Resume Score (0-100)
    const resumeEval = resumeData ? evaluateResume(resumeData).score : null;

    // 7. Interview Lab Practice Score
    const interviewScore = 80;

    return calculatePlacementReadiness({
      skillCompletion: skillCompletionScore,
      assessmentScore,
      projectScore,
      aptitudeScore,
      communicationScore: commScore,
      resumeScore: resumeEval,
      interviewScore,
    });
  }, [currentUser, skills, userProgressMap, projectSubmissions, resumeData]);

  // Skill Gap Detective Report
  const skillGapReport = useMemo(() => {
    if (!currentUser || currentUser.role !== 'student') {
      return generateSkillGapReport(skills.slice(0, 8), {}, '3rd Year');
    }
    const deptSkills = skills.filter((s) => s.departmentId === currentUser.department);
    const targetSkills = deptSkills.length > 0 ? deptSkills : skills.slice(0, 8);
    const approvedProjectSkillSet = new Set<string>();
    projectSubmissions
      .filter((s) => s.studentId === currentUser.id && s.status === 'Approved')
      .forEach((s) => {
        const pr = projects.find((p) => p.id === s.projectId);
        if (pr) pr.requiredSkills.forEach((rs) => approvedProjectSkillSet.add(rs));
      });

    return generateSkillGapReport(targetSkills, userProgressMap, currentUser.year || '3rd Year', approvedProjectSkillSet);
  }, [currentUser, skills, userProgressMap, projectSubmissions, projects]);

  const unreadNotificationCount = useMemo(() => {
    if (!currentUser) return 0;
    return notifications.filter((n) => n.userId === currentUser.id && !n.read).length;
  }, [notifications, currentUser]);

  // Actions
  const login = (identifier: string, password?: string) => {
    const clean = identifier.trim().toLowerCase();
    const found = users.find(
      (u) =>
        u.email.toLowerCase() === clean ||
        (u.registerNumber && u.registerNumber.toLowerCase() === clean) ||
        u.name.toLowerCase() === clean
    );
    if (found) {
      setCurrentUserId(found.id);
      return { success: true };
    }
    return { success: false, error: 'No account found with this email or register number. Please create an account to start.' };
  };

  const registerStudent = (formData: {
    name: string;
    email: string;
    registerNumber: string;
    phone: string;
    department: DepartmentId;
    year: AcademicYear;
    password: string;
    careerInterests: string[];
  }) => {
    if (!formData.name || !formData.email || !formData.registerNumber || !formData.password) {
      return { success: false, error: 'Please fill in all required fields.' };
    }
    const existing = users.find(
      (u) =>
        u.email.toLowerCase() === formData.email.trim().toLowerCase() ||
        (u.registerNumber && u.registerNumber.toLowerCase() === formData.registerNumber.trim().toLowerCase())
    );
    if (existing) {
      return { success: false, error: 'A student with this Email or Register Number already exists.' };
    }

    const newUser: User = {
      id: `std_${Date.now()}`,
      name: formData.name.trim(),
      email: formData.email.trim(),
      registerNumber: formData.registerNumber.trim(),
      phone: formData.phone.trim(),
      department: formData.department,
      year: formData.year,
      role: 'student',
      careerInterests: formData.careerInterests.length > 0 ? formData.careerInterests : ['General Technology'],
      avatar: getAvatarStyleFromName(formData.name),
    };

    setUsers((prev) => [...prev, newUser]);
    setCurrentUserId(newUser.id);

    // Initial welcome notification
    setNotifications((prev) => [
      {
        id: `notif_${Date.now()}`,
        userId: newUser.id,
        title: 'Welcome to CareerWise!',
        message: `Your roadmap for ${DEPARTMENTS.find((d) => d.id === formData.department)?.name} (${formData.year}) is ready. Explore your skills and missions.`,
        type: 'reminder',
        link: '/roadmap',
        read: false,
        createdAt: new Date().toISOString(),
      },
      ...prev,
    ]);

    return { success: true };
  };

  const loginWithSkills = (data: {
    name: string;
    department: DepartmentId;
    year: AcademicYear;
    skills: StudentSkillEntry[];
    email?: string;
    registerNumber?: string;
    avatar?: string;
  }) => {
    const cleanName = data.name.trim();
    const cleanEmail = (
      data.email || `${cleanName.toLowerCase().replace(/[^a-z0-9]/g, '.') || 'student'}@ncet.edu`
    ).trim().toLowerCase();

    // Check if an existing student exists with this name or email or regNumber
    const existingIndex = users.findIndex(
      (u) =>
        u.email.toLowerCase() === cleanEmail ||
        (data.registerNumber &&
          u.registerNumber &&
          u.registerNumber.toLowerCase() === data.registerNumber.trim().toLowerCase()) ||
        u.name.toLowerCase() === cleanName.toLowerCase()
    );

    let targetUser: User;

    if (existingIndex >= 0) {
      targetUser = {
        ...users[existingIndex],
        name: cleanName,
        department: data.department,
        year: data.year,
        enteredSkills: data.skills,
        registerNumber: data.registerNumber?.trim() || users[existingIndex].registerNumber,
        careerInterests: data.skills.map((s) => s.name || s.skillName || '').filter(Boolean),
        avatar: data.avatar || users[existingIndex].avatar || getAvatarStyleFromName(cleanName),
      };
      setUsers((prev) => {
        const copy = [...prev];
        copy[existingIndex] = targetUser;
        return copy;
      });
    } else {
      targetUser = {
        id: `std_${Date.now()}`,
        name: cleanName,
        email: cleanEmail,
        department: data.department,
        year: data.year,
        role: 'student',
        registerNumber: data.registerNumber?.trim() || `NCET-2026-${Math.floor(1000 + Math.random() * 9000)}`,
        careerInterests: data.skills.map((s) => s.name || s.skillName || '').filter(Boolean),
        enteredSkills: data.skills,
        avatar: data.avatar || getAvatarStyleFromName(cleanName),
      };
      setUsers((prev) => [...prev, targetUser]);
    }

    setCurrentUserId(targetUser.id);

    // Initial notification for newly generated custom plan
    setNotifications((prev) => [
      {
        id: `notif_${Date.now()}`,
        userId: targetUser.id,
        title: 'Custom Skill Plan Generated!',
        message: `Welcome ${cleanName}! We customized unique project ideas, tasks, and skill suggestions based on your ${data.skills.length} skills.`,
        type: 'mission',
        link: '/custom-plan',
        read: false,
        createdAt: new Date().toISOString(),
      },
      ...prev,
    ]);

    return { success: true, user: targetUser };
  };

  const updateCurrentUserSkills = (skillsList: StudentSkillEntry[]) => {
    if (!currentUser) return;
    const updated: User = {
      ...currentUser,
      enteredSkills: skillsList,
      careerInterests: skillsList.map((s) => s.name || s.skillName || '').filter(Boolean),
    };
    setUsers((prev) => prev.map((u) => (u.id === currentUser.id ? updated : u)));
  };

  const toggleCustomTask = (taskId: string) => {
    if (!currentUser) return;
    setCompletedCustomTasks((prev) => {
      const existing = prev[currentUser.id] || [];
      const updated = existing.includes(taskId)
        ? existing.filter((id) => id !== taskId)
        : [...existing, taskId];
      return { ...prev, [currentUser.id]: updated };
    });
  };

  const logout = () => {
    setCurrentUserId('');
    try {
      localStorage.removeItem(`${STORAGE_KEY_PREFIX}_current_user_id`);
    } catch {
      // ignore
    }
  };

  const switchDemoUser = (userId: string) => {
    setCurrentUserId(userId);
  };

  const completeSkillModule = (skillId: string, moduleId: string) => {
    if (!currentUser) return;
    setAllProgress((prev) => {
      const userProg = { ...(prev[currentUser.id] || {}) };
      const current = userProg[skillId] || {
        skillId,
        completedModuleIds: [],
        isCompleted: false,
        quizAttempts: 0,
        lastStudiedAt: new Date().toISOString(),
      };

      const setModules = new Set(current.completedModuleIds);
      setModules.add(moduleId);

      const targetSkill = skills.find((s) => s.id === skillId);
      const totalModules = targetSkill ? targetSkill.modules.length : 4;
      const isCompleted = setModules.size >= totalModules;

      userProg[skillId] = {
        ...current,
        completedModuleIds: Array.from(setModules),
        isCompleted,
        lastStudiedAt: new Date().toISOString().split('T')[0],
      };

      return { ...prev, [currentUser.id]: userProg };
    });
  };

  const submitQuizScore = (skillId: string, scorePercentage: number) => {
    if (!currentUser) return;
    setAllProgress((prev) => {
      const userProg = { ...(prev[currentUser.id] || {}) };
      const current = userProg[skillId] || {
        skillId,
        completedModuleIds: [],
        isCompleted: false,
        quizAttempts: 0,
        lastStudiedAt: new Date().toISOString(),
      };

      const newScore = Math.max(current.quizScore || 0, scorePercentage);
      userProg[skillId] = {
        ...current,
        quizScore: newScore,
        quizAttempts: (current.quizAttempts || 0) + 1,
        lastStudiedAt: new Date().toISOString().split('T')[0],
      };

      return { ...prev, [currentUser.id]: userProg };
    });

    // Check if score is >= 80% to celebrate or issue certificate
    if (scorePercentage >= 80) {
      const skillObj = skills.find((s) => s.id === skillId);
      if (skillObj) {
        setNotifications((prev) => [
          {
            id: `notif_${Date.now()}`,
            userId: currentUser.id,
            title: `Assessment Passed: ${skillObj.title}!`,
            message: `Congratulations! You scored ${scorePercentage}% on ${skillObj.title}. Your skill gap has been reduced.`,
            type: 'assessment',
            link: `/skill/${skillId}`,
            read: false,
            createdAt: new Date().toISOString(),
          },
          ...prev,
        ]);
      }
    }
  };

  const submitProject = (projectId: string, githubUrl: string, liveUrl: string, notes: string) => {
    if (!currentUser) return;
    const project = projects.find((p) => p.id === projectId);
    const newSubmission: ProjectSubmission = {
      id: `sub_${Date.now()}`,
      projectId,
      studentId: currentUser.id,
      studentName: currentUser.name,
      departmentId: currentUser.department || 'bsc_cs',
      githubUrl,
      liveUrl,
      reportNotes: notes,
      status: 'Submitted',
      submittedAt: new Date().toISOString(),
      gradeScore: 80,
    };

    setProjectSubmissions((prev) => [newSubmission, ...prev.filter((s) => !(s.projectId === projectId && s.studentId === currentUser.id))]);

    setNotifications((prev) => [
      {
        id: `notif_${Date.now()}`,
        userId: currentUser.id,
        title: 'Project Submitted for Review',
        message: `Your project "${project?.title || 'Capstone'}" has been submitted for faculty review.`,
        type: 'project',
        link: '/projects',
        read: false,
        createdAt: new Date().toISOString(),
      },
      ...prev,
    ]);
  };

  const reviewProjectSubmission = (
    submissionId: string,
    status: 'Approved' | 'Needs Revision',
    gradeScore: number,
    feedback: string
  ) => {
    setProjectSubmissions((prev) =>
      prev.map((sub) => {
        if (sub.id === submissionId) {
          const updated = {
            ...sub,
            status,
            gradeScore,
            feedback,
            reviewedAt: new Date().toISOString(),
            reviewerName: currentUser?.name || 'Faculty Reviewer',
          };

          // Notify student
          setNotifications((notifs) => [
            {
              id: `notif_${Date.now()}`,
              userId: sub.studentId,
              title: status === 'Approved' ? 'Project Approved!' : 'Project Needs Revision',
              message: `${currentUser?.name || 'Faculty'} reviewed your submission with grade ${gradeScore}/100. Feedback: ${feedback}`,
              type: 'project',
              link: '/projects',
              read: false,
              createdAt: new Date().toISOString(),
            },
            ...notifs,
          ]);

          return updated;
        }
        return sub;
      })
    );
  };

  const submitMissionTask = (missionId: string, taskId: string, completed: boolean) => {
    setCareerMissions((prev) =>
      prev.map((m) => {
        if (m.id === missionId) {
          return {
            ...m,
            tasks: m.tasks.map((t) => (t.id === taskId ? { ...t, completed } : t)),
          };
        }
        return m;
      })
    );
  };

  const submitMissionEvidence = (missionId: string, evidenceText: string, evidenceUrl?: string) => {
    if (!currentUser) return;
    const mission = careerMissions.find((m) => m.id === missionId);
    setNotifications((prev) => [
      {
        id: `notif_${Date.now()}`,
        userId: currentUser.id,
        title: `Mission Completed: ${mission?.title || 'Weekly Mission'}!`,
        message: `You earned +${mission?.points || 100} points and the "${mission?.badgeName || 'Milestone'}" badge.`,
        type: 'mission',
        link: '/missions',
        read: false,
        createdAt: new Date().toISOString(),
      },
      ...prev,
    ]);
  };

  const saveInterviewPractice = (record: Omit<InterviewPracticeRecord, 'id' | 'practicedAt'>) => {
    if (!currentUser) return;
    setNotifications((prev) => [
      {
        id: `notif_${Date.now()}`,
        userId: currentUser.id,
        title: `Interview Practice Evaluated (${record.score}/100)`,
        message: `Category: ${record.category}. Keep practicing to elevate your placement readiness score!`,
        type: 'assessment',
        link: '/interview-lab',
        read: false,
        createdAt: new Date().toISOString(),
      },
      ...prev,
    ]);
  };

  const updateResumeData = (data: ResumeData) => {
    if (!currentUser) return;
    setAllResumes((prev) => ({
      ...prev,
      [currentUser.id]: data,
    }));
  };

  const generateCertificateForSkill = (skillOrCourseTitle: string): Certificate => {
    if (!currentUser) throw new Error('Not logged in');
    const certNum = `CW-${new Date().getFullYear()}-${currentUser.department?.toUpperCase() || 'CS'}-${Math.floor(10000 + Math.random() * 90000)}`;
    const newCert: Certificate = {
      id: `cert_${Date.now()}`,
      certificateNumber: certNum,
      studentId: currentUser.id,
      studentName: currentUser.name,
      department: DEPARTMENTS.find((d) => d.id === currentUser.department)?.name || 'Computer Science',
      skillOrCourseTitle,
      issueDate: new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' }),
      verificationUrl: `https://careerwise.edu/verify/${certNum}`,
      criteriaMet: [
        `Completed all required learning modules with verified assessments`,
        `Satisfied faculty evaluation criteria on CareerWise platform`,
        `Demonstrated placement-grade proficiency`,
      ],
      signatureSigner: 'Prof. K. R. Ramanathan, Director of Placements & Training',
    };

    setCertificates((prev) => [newCert, ...prev]);

    setNotifications((prev) => [
      {
        id: `notif_${Date.now()}`,
        userId: currentUser.id,
        title: 'New Certificate Issued!',
        message: `Your certificate for ${skillOrCourseTitle} has been generated. Certificate Number: ${certNum}`,
        type: 'certificate',
        link: '/certificates',
        read: false,
        createdAt: new Date().toISOString(),
      },
      ...prev,
    ]);

    return newCert;
  };

  const togglePortfolioPublic = (isPublic: boolean) => {
    if (!currentUser) return;
    setPortfolioPrivacy((prev) => ({
      ...prev,
      [currentUser.id]: isPublic,
    }));
  };

  const setTargetCareerPath = (pathId: string) => {
    if (!currentUser) return;
    setUsers((prev) =>
      prev.map((u) => (u.id === currentUser.id ? { ...u, targetCareerPathId: pathId } : u))
    );
  };

  const markNotificationAsRead = (notificationId: string) => {
    setNotifications((prev) =>
      prev.map((n) => (n.id === notificationId ? { ...n, read: true } : n))
    );
  };

  const markAllNotificationsAsRead = () => {
    if (!currentUser) return;
    setNotifications((prev) =>
      prev.map((n) => (n.userId === currentUser.id ? { ...n, read: true } : n))
    );
  };

  const addOrUpdateSkill = (skill: Skill) => {
    setSkills((prev) => {
      const idx = prev.findIndex((s) => s.id === skill.id);
      if (idx >= 0) {
        const copy = [...prev];
        copy[idx] = skill;
        return copy;
      }
      return [...prev, skill];
    });
  };

  const addOrUpdateProject = (project: Project) => {
    setProjects((prev) => {
      const idx = prev.findIndex((p) => p.id === project.id);
      if (idx >= 0) {
        const copy = [...prev];
        copy[idx] = project;
        return copy;
      }
      return [...prev, project];
    });
  };

  const addOrUpdateMission = (mission: CareerMission) => {
    setCareerMissions((prev) => {
      const idx = prev.findIndex((m) => m.id === mission.id);
      if (idx >= 0) {
        const copy = [...prev];
        copy[idx] = mission;
        return copy;
      }
      return [...prev, mission];
    });
  };

  const createTrainingSession = (session: Omit<TrainingSession, 'id'>) => {
    const newSession: TrainingSession = {
      ...session,
      id: `train_${Date.now()}`,
    };
    setTrainingSessions((prev) => [newSession, ...prev]);
  };

  const resetAllData = () => {
    localStorage.clear();
    setUsers([]);
    setCurrentUserId('');
    setSkills(INITIAL_SKILLS);
    setProjects(INITIAL_PROJECTS);
    setCareerMissions(INITIAL_CAREER_MISSIONS);
    setProjectSubmissions([]);
    setAllProgress({});
    setNotifications([]);
    setCertificates([]);
    setTrainingSessions(INITIAL_TRAINING_SESSIONS);
    setAllResumes({});
    setPortfolioPrivacy({});
    setCompletedCustomTasks({});
  };

  return (
    <AppContext.Provider
      value={{
        currentUser,
        users,
        departments: DEPARTMENTS,
        skills,
        careerPaths: INITIAL_CAREER_PATHS,
        projects,
        careerMissions,
        interviewQuestions: INITIAL_INTERVIEW_QUESTIONS,
        revisionItems: INITIAL_REVISION_ITEMS,
        progressMap: userProgressMap,
        projectSubmissions,
        trainingSessions,
        notifications,
        certificates,
        resumeData,
        isPortfolioPublic,
        selectedCareerPath,
        readinessResult,
        skillGapReport,
        unreadNotificationCount,
        customSkillPlan,
        completedCustomTaskIds,
        toggleCustomTask,
        loginWithSkills,
        updateCurrentUserSkills,
        login,
        registerStudent,
        logout,
        switchDemoUser,
        completeSkillModule,
        submitQuizScore,
        submitProject,
        reviewProjectSubmission,
        submitMissionTask,
        submitMissionEvidence,
        saveInterviewPractice,
        updateResumeData,
        generateCertificateForSkill,
        togglePortfolioPublic,
        setTargetCareerPath,
        markNotificationAsRead,
        markAllNotificationsAsRead,
        addOrUpdateSkill,
        addOrUpdateProject,
        addOrUpdateMission,
        createTrainingSession,
        resetAllData,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used within an AppProvider');
  return context;
};
