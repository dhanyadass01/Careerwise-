import React, { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Navbar } from './components/Navbar';
import { LandingPage } from './components/LandingPage';
import { StudentDashboard } from './components/StudentDashboard';
import { RoadmapView } from './components/RoadmapView';
import { SkillLearningView } from './components/SkillLearningView';
import { SkillGapDetectiveView } from './components/SkillGapDetectiveView';
import { CareerPathSimulatorView } from './components/CareerPathSimulatorView';
import { SkillDependencyMapView } from './components/SkillDependencyMapView';
import { ProjectsView } from './components/ProjectsView';
import { WeeklyMissionsView } from './components/WeeklyMissionsView';
import { InterviewLabView } from './components/InterviewLabView';
import { PortfolioView } from './components/PortfolioView';
import { PlacementZoneView } from './components/PlacementZoneView';
import { SmartRevisionView } from './components/SmartRevisionView';
import { CertificatesView } from './components/CertificatesView';
import { FacultyDashboard } from './components/FacultyDashboard';
import { AdminDashboard } from './components/AdminDashboard';
import { AuthModal } from './components/AuthModal';
import { NotificationDrawer } from './components/NotificationDrawer';
import { LoginPage } from './components/LoginPage';
import { PersonalizedSkillPlanView } from './components/PersonalizedSkillPlanView';

function AppContent() {
  const [currentTab, setCurrentTab] = useState<string>('landing');
  const [selectedSkillId, setSelectedSkillId] = useState<string>('cs_prog_fund');
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [notificationsOpen, setNotificationsOpen] = useState(false);

  const handleSelectSkill = (skillId: string) => {
    setSelectedSkillId(skillId);
    setCurrentTab('skill-learning');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleNavigate = (tab: string, contextId?: string) => {
    if (tab === 'skill-learning' && contextId) {
      setSelectedSkillId(contextId);
    }
    setCurrentTab(tab);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col font-sans antialiased selection:bg-blue-600 selection:text-white">
      {/* Top Navbar */}
      <Navbar
        currentTab={currentTab}
        setCurrentTab={(tab) => handleNavigate(tab)}
        onOpenAuth={() => setAuthModalOpen(true)}
        onOpenNotifications={() => setNotificationsOpen(true)}
      />

      {/* Main View Body */}
      <main className="flex-1 pb-16">
        {currentTab === 'landing' && (
          <LandingPage
            onNavigate={(tab) => handleNavigate(tab)}
            onOpenAuth={() => setAuthModalOpen(true)}
          />
        )}

        {currentTab === 'login' && (
          <LoginPage onSuccessNavigate={(tab) => handleNavigate(tab)} />
        )}

        {currentTab === 'custom-plan' && (
          <PersonalizedSkillPlanView
            onNavigateToProjects={() => handleNavigate('projects')}
            onNavigateToSkills={() => handleNavigate('roadmap')}
            onNavigateToRoadmap={() => handleNavigate('roadmap')}
            onNavigateToLogin={() => handleNavigate('login')}
          />
        )}

        {currentTab === 'dashboard' && (
          <StudentDashboard onNavigate={handleNavigate} />
        )}

        {currentTab === 'roadmap' && (
          <RoadmapView onSelectSkill={handleSelectSkill} />
        )}

        {currentTab === 'skill-learning' && (
          <SkillLearningView
            skillId={selectedSkillId}
            onBack={() => handleNavigate('roadmap')}
            onNavigateToProjects={() => handleNavigate('projects')}
          />
        )}

        {currentTab === 'skill-gap' && (
          <SkillGapDetectiveView
            onSelectSkill={handleSelectSkill}
            onNavigateToProjects={() => handleNavigate('projects')}
          />
        )}

        {currentTab === 'career-simulator' && (
          <CareerPathSimulatorView
            onNavigateToRoadmap={() => handleNavigate('roadmap')}
          />
        )}

        {currentTab === 'dependency-map' && (
          <SkillDependencyMapView />
        )}

        {currentTab === 'projects' && (
          <ProjectsView />
        )}

        {currentTab === 'missions' && (
          <WeeklyMissionsView />
        )}

        {currentTab === 'interview-lab' && (
          <InterviewLabView />
        )}

        {currentTab === 'placement-zone' && (
          <PlacementZoneView />
        )}

        {currentTab === 'portfolio' && (
          <PortfolioView />
        )}

        {currentTab === 'certificates' && (
          <CertificatesView onNavigate={handleNavigate} />
        )}

        {currentTab === 'revision' && (
          <SmartRevisionView />
        )}

        {currentTab === 'faculty' && (
          <FacultyDashboard />
        )}

        {currentTab === 'admin' && (
          <AdminDashboard />
        )}
      </main>

      {/* Auth Modal */}
      <AuthModal
        isOpen={authModalOpen}
        onClose={() => setAuthModalOpen(false)}
        onSuccess={() => {
          setAuthModalOpen(false);
          setCurrentTab('dashboard');
        }}
        onNavigateToSkillLogin={() => {
          setAuthModalOpen(false);
          handleNavigate('login');
        }}
      />

      {/* Notifications Drawer */}
      <NotificationDrawer
        isOpen={notificationsOpen}
        onClose={() => setNotificationsOpen(false)}
        onNavigate={(tab) => handleNavigate(tab)}
      />
    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
